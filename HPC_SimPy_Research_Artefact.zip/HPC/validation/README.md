# Independent validation scope

Install the optional ns-3 C++ distribution and compile with g++:

```bash
python3 -m pip install --user --no-deps ns3==3.44.post0
python3 validation/run_ns3.py
```

The `--no-deps` option deliberately avoids cppyy: the diagnostic uses the
wheel's C++ headers/libraries directly. Python bindings are not used. The build
expects Linux and the compatible ns-3 3.44 wheel; no binary is included in the
archive. Preserve existing results before an intentional rerun.

The diagnostic compares saturated AP downlink application goodput across six
distances and three station counts, with five RNG runs each. Thirty separate
echo runs test unloaded RTT. Fit single-station RSSI/goodput knots using runs
1--3 and compare predictions against runs 4--5 for all station counts. RSSI
counts only AP data frames, avoiding nearby-station ACK contamination. Echo
delay does not include a concurrent saturated workload. See report.json for
all PHY, loss, rate-manager and traffic settings. There is no measured fading,
mobility or interference. Holdout seeds at training distances test stochastic
repeatability and concurrency generalization, not unseen-distance accuracy.

This is an independent network-simulator diagnostic. It does not establish
external validity of mobile task scheduling, nor turn assumed SimPy results
into measurements. The original fluid-channel datasets are preserved. The
ns-3 fitted curve is not silently substituted into those experiments.

For physical validation, record synchronized time, pseudonymous device ID,
stationary/mobile designation, position or departure labels, RSSI, probe RTT,
sent/received bytes, transfer start/end and task compute start/end. Use separate
calibration and evaluation sessions; retain failed and disconnected runs.
At minimum, use one coordinator and four workers, repeated stationary,
weak-link, departure/return and combined trials, with the same workloads for
Proposed, tuned fixed-size, compute-only shrinking and prefetch ablations.
Report MAC/PHY, driver, power, topology, instrument overhead and uncertainty.
Use only real recorded values; no supplied trace is available in this artefact.
