// Independent ns-3 3.44 radio diagnostic, not an end-to-end scheduler test.
#include "ns3/core-module.h"
#include "ns3/network-module.h"
#include "ns3/internet-module.h"
#include "ns3/wifi-module.h"
#include "ns3/mobility-module.h"
#include "ns3/applications-module.h"
#include <iostream>
#include <iomanip>
using namespace ns3;
double signalSum=0, rttSum=0; uint64_t signalN=0, rttN=0; Mac48Address apMac;
void Sniff(Ptr<const Packet> p, uint16_t, WifiTxVector, MpduInfo, SignalNoiseDbm s, uint16_t) {
  WifiMacHeader h; p->PeekHeader(h);
  if (Simulator::Now().GetSeconds()>=2 && h.IsData() && h.GetAddr2()==apMac) {signalSum+=s.signal; signalN++;}
}
void Echo(Ptr<Socket> s) {Address a; while(auto p=s->RecvFrom(a)) s->SendTo(p,0,a);}
void Reply(Ptr<Socket> s) {while(auto p=s->Recv()) {SeqTsHeader h;p->RemoveHeader(h);rttSum+=(Simulator::Now()-h.GetTs()).GetSeconds()*1000;rttN++;}}
void SendProbe(Ptr<Socket> s, uint32_t k) {auto p=Create<Packet>(40);SeqTsHeader h;h.SetSeq(k);p->AddHeader(h);s->Send(p);if(k<99)Simulator::Schedule(Seconds(.05),&SendProbe,s,k+1);}
int main(int argc,char** argv) {
  double distance=5;uint32_t stations=1,seed=1;bool traffic=true;
  CommandLine cmd;cmd.AddValue("distance","Distance in metres",distance);cmd.AddValue("stations","Number of stations",stations);cmd.AddValue("seed","RNG run",seed);cmd.AddValue("traffic","Saturated UDP instead of echo",traffic);cmd.Parse(argc,argv);
  RngSeedManager::SetSeed(12345);RngSeedManager::SetRun(seed);
  NodeContainer ap,sta;ap.Create(1);sta.Create(stations);
  MobilityHelper mobility;mobility.SetMobilityModel("ns3::ConstantPositionMobilityModel");mobility.Install(ap);mobility.Install(sta);
  ap.Get(0)->GetObject<MobilityModel>()->SetPosition(Vector(0,0,0));
  for(uint32_t i=0;i<stations;i++)sta.Get(i)->GetObject<MobilityModel>()->SetPosition(Vector(distance,0.1*i,0));
  YansWifiChannelHelper channel;channel.SetPropagationDelay("ns3::ConstantSpeedPropagationDelayModel");channel.AddPropagationLoss("ns3::LogDistancePropagationLossModel","Exponent",DoubleValue(3),"ReferenceLoss",DoubleValue(56));
  YansWifiPhyHelper phy;phy.SetChannel(channel.Create());phy.Set("TxPowerStart",DoubleValue(16));phy.Set("TxPowerEnd",DoubleValue(16));phy.Set("ChannelSettings",StringValue("{36, 20, BAND_5GHZ, 0}"));
  WifiHelper wifi;wifi.SetStandard(WIFI_STANDARD_80211a);wifi.SetRemoteStationManager("ns3::IdealWifiManager");
  WifiMacHelper mac;Ssid ssid=Ssid("validation");mac.SetType("ns3::StaWifiMac","Ssid",SsidValue(ssid),"ActiveProbing",BooleanValue(false));auto sd=wifi.Install(phy,mac,sta);mac.SetType("ns3::ApWifiMac","Ssid",SsidValue(ssid));auto ad=wifi.Install(phy,mac,ap);
  apMac=Mac48Address::ConvertFrom(ad.Get(0)->GetAddress());
  for(uint32_t i=0;i<stations;i++)DynamicCast<WifiNetDevice>(sd.Get(i))->GetPhy()->TraceConnectWithoutContext("MonitorSnifferRx",MakeCallback(&Sniff));
  InternetStackHelper stack;stack.Install(ap);stack.Install(sta);Ipv4AddressHelper addr;addr.SetBase("10.1.0.0","255.255.255.0");auto ai=addr.Assign(ad);auto si=addr.Assign(sd);
  std::vector<Ptr<PacketSink>> sinks;
  if(traffic)for(uint32_t i=0;i<stations;i++){
    PacketSinkHelper sink("ns3::UdpSocketFactory",InetSocketAddress(Ipv4Address::GetAny(),9000));auto apps=sink.Install(sta.Get(i));apps.Start(Seconds(1));apps.Stop(Seconds(8));sinks.push_back(DynamicCast<PacketSink>(apps.Get(0)));
    OnOffHelper send("ns3::UdpSocketFactory",InetSocketAddress(si.GetAddress(i),9000));send.SetConstantRate(DataRate("60Mbps"),1200);auto sa=send.Install(ap.Get(0));sa.Start(Seconds(2));sa.Stop(Seconds(7));
  } else {
    auto server=Socket::CreateSocket(sta.Get(0),UdpSocketFactory::GetTypeId());server->Bind(InetSocketAddress(Ipv4Address::GetAny(),9001));server->SetRecvCallback(MakeCallback(&Echo));
    auto client=Socket::CreateSocket(ap.Get(0),UdpSocketFactory::GetTypeId());client->Connect(InetSocketAddress(si.GetAddress(0),9001));client->SetRecvCallback(MakeCallback(&Reply));Simulator::Schedule(Seconds(2),&SendProbe,client,0);
  }
  Simulator::Stop(Seconds(7));Simulator::Run();double bytes=0;for(auto s:sinks)bytes+=s->GetTotalRx();
  std::cout<<std::setprecision(12)<<distance<<","<<stations<<","<<seed<<","<<traffic<<","<<(signalN?signalSum/signalN:0)<<","<<bytes*8/5e6<<","<<(rttN?rttSum/rttN:0)<<","<<rttN<<","<<signalN<<"\n";Simulator::Destroy();
}
