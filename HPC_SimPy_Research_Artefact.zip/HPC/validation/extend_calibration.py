"""Extend receive-power support; preserve original calibration measurements."""
import sys,csv,json,subprocess,hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from validation.run_ns3 import run
if __name__=='__main__':
 out=root/'results/ns3_extended';out.mkdir(parents=True,exist_ok=True)
 if (out/'raw.csv').exists():raise SystemExit('Refuse overwrite')
 subprocess.run(['bash',str(root/'validation/build_ns3.sh')],check=True)
 settings=[(d,1,s,t) for d in [1,30,40,60,100,200,1000] for s in range(1,6) for t in [0,1]]
 rows=[]
 with ProcessPoolExecutor(max_workers=4) as pool:
  for i,r in enumerate(pool.map(run,settings)):
   rows.append(r)
   if (i+1)%10==0:print(i+1,'/70 calibration extension runs',flush=True)
 with (out/'raw.csv').open('w') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
 old=[{k:float(v) for k,v in r.items()} for r in csv.DictReader((root/'results/ns3/raw.csv').open()) if float(r['stations'])==1];allrows=old+rows;knots=[]
 for d in sorted(set(r['distance_m'] for r in allrows),reverse=True):
  data=[r for r in allrows if r['distance_m']==d and r['seed']<=3 and r['traffic']==1];echo=[r for r in allrows if r['distance_m']==d and r['seed']<=3 and r['traffic']==0]
  knots.append(dict(rssi=float(np.mean([r['rssi_dbm'] for r in data])),goodput=float(np.mean([r['aggregate_mbps'] for r in data])),rtt_ms=float(np.mean([r['rtt_ms'] for r in echo if r['echo_received']>0])) if any(r['echo_received']>0 for r in echo) else 400.,echo_delivery=float(np.mean([r['echo_received']/100 for r in echo])),distance=d,decoded_data_frames=sum(r['sniffer_samples'] for r in data)))
 test=[r for r in allrows if r['traffic']==1 and r['seed']>=4];x=[k['rssi'] for k in knots];y=[k['goodput'] for k in knots];err=[abs(r['aggregate_mbps']-np.interp(r['rssi_dbm'],x,y)) for r in test]
 report=dict(knots=knots,training_seeds=[1,2,3],holdout_seeds=[4,5],holdout_goodput_mae_mbps=float(np.mean(err)),radio_runs_total=190,source_sha256=hashlib.sha256((root/'validation/ns3_wifi.cc').read_bytes()).hexdigest(),scope='Stationary single-link lookup projected onto changing signals; no measured devices, mobile packet-level scheduler, or loaded-RTT calibration',absent_echo_timeout_ms=400,rssi_note='At zero decoded frames, RSSI coordinate is configured log-distance receive power, not an observation')
 (out/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(knots,indent=2),flush=True)
