"""Retain independent packet-level Wi-Fi diagnostics and holdout errors.

Training RNG runs 1--3; untouched diagnostic runs 4--5. This is simulator
cross-validation, not measurement or validation of end-to-end scheduler gains.
"""
import csv, json, subprocess, sys, hashlib
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import table_rate, round_trip_ms
ROOT=Path(__file__).resolve().parents[1]
def run(setting):
    distance,n,seed,traffic=setting
    cmd=[str(ROOT/'validation/build/ns3_wifi'),f'--distance={distance}',f'--stations={n}',f'--seed={seed}',f'--traffic={traffic}']
    values=subprocess.check_output(cmd,text=True).strip().split(',')
    keys=['distance_m','stations','seed','traffic','rssi_dbm','aggregate_mbps','rtt_ms','echo_received','sniffer_samples']
    return dict(zip(keys,map(float,values)))
if __name__=='__main__':
    out=ROOT/'results/ns3';out.mkdir(parents=True,exist_ok=True)
    if (out/'raw.csv').exists():raise SystemExit('Refuse to overwrite retained ns-3 data')
    subprocess.run(['bash',str(ROOT/'validation/build_ns3.sh')],check=True)
    settings=[(d,n,s,1) for d in [2,5,10,15,20,25] for n in [1,2,4] for s in range(1,6)]
    settings += [(d,1,s,0) for d in [2,5,10,15,20,25] for s in range(1,6)]
    rows=[]
    with ProcessPoolExecutor(max_workers=4) as pool:
        for i,r in enumerate(pool.map(run,settings)):
            rows.append(r)
            if (i+1)%20==0:print(i+1,'/',len(settings),'ns-3 runs',flush=True)
    with (out/'raw.csv').open('w') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    # Fit the single-transfer application goodput only; holdout n=2,4 tests
    # whether equal-airtime generalization actually matches packet contention.
    knots=[]
    for d in [25,20,15,10,5,2]:
        subset=[r for r in rows if r['traffic']==1 and r['stations']==1 and r['seed']<=3 and r['distance_m']==d]
        knots.append([float(np.mean([r['rssi_dbm'] for r in subset])),float(np.mean([r['aggregate_mbps'] for r in subset]))])
    def errors(n):
        test=[r for r in rows if r['traffic']==1 and r['stations']==n and r['seed']>=4]
        actual=np.array([r['aggregate_mbps'] for r in test]);legacy=np.array([table_rate(r['rssi_dbm']) for r in test]);fit=np.interp([r['rssi_dbm'] for r in test],*np.array(knots).T)
        return dict(n=len(test),legacy_mae_mbps=float(np.abs(actual-legacy).mean()),calibrated_mae_mbps=float(np.abs(actual-fit).mean()),observed_mean_mbps=float(actual.mean()))
    report=dict(version='ns-3 3.44.post0 C++ libraries',training_seeds=[1,2,3],holdout_seeds=[4,5],knots=knots,holdout_by_station_count={str(n):errors(n) for n in [1,2,4]},settings=dict(standard='802.11a',frequency_mhz=5180,width_mhz=20,rate_manager='IdealWifiManager',tx_power_dbm=16,path_loss_exponent=3,reference_loss_db=56,packet_bytes=1200,offered_mbps_per_station=60,traffic_start_s=2,stop_s=7,topology='one AP downlink to co-located stationary receivers',mobility='none',fading='none',echo_probes=100,echo_payload_bytes=40),limitations=['No physical measurement','No mobility, TCP, or realistic interference','AP downlink saturation differs from independent fluid transfers','Not a coupled scheduler execution','Calibration covers only the retained RSSI range'],source_sha256=hashlib.sha256((ROOT/'validation/ns3_wifi.cc').read_bytes()).hexdigest())
    echo=[r for r in rows if r['traffic']==0 and r['seed']>=4]
    report['unloaded_echo_holdout']=dict(n=len(echo),mean_rtt_ms=float(np.mean([r['rtt_ms'] for r in echo])),assumed_rtt_mae_ms=float(np.mean([abs(r['rtt_ms']-round_trip_ms(r['rssi_dbm'])) for r in echo])),received=sum(r['echo_received'] for r in echo),sent=100*len(echo))
    (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report['holdout_by_station_count'],indent=2),flush=True)
