#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
ns3_root=$(python3 -c 'import site; print(site.getusersitepackages()+"/ns3")')
mkdir -p validation/build
g++ -std=c++20 -O2 -I"$ns3_root/include" validation/ns3_wifi.cc -L"$ns3_root/lib64" -Wl,-rpath,"$ns3_root/lib64" -Wl,-rpath-link,"$ns3_root/lib64" -lns3.44-wifi -lns3.44-mobility -lns3.44-propagation -lns3.44-applications -lns3.44-internet -lns3.44-network -lns3.44-core -o validation/build/ns3_wifi
