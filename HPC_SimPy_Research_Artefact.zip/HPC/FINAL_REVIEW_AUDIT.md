# Critical review of the current mechanism manuscript

Primary manuscript: paper/manuscript_ieee.pdf.
Primary source: paper/mechanism_study_ieee.tex.
Primary supplementary material: paper/mechanism_supplement.pdf.
Earlier papers and comparative families are historical diagnostics.

## Evidence and framing corrected

- Main conclusions now use all four recalibrated core scenarios: 2,000 runs,
  50 paired evaluation seeds per scenario, all completing. The earlier large
  assumed-channel gains are not the primary superiority evidence.
- Fixed-size tuning uses 280 separate runs with sizes 1,2,3,4,8,16,32. One
  indivisible task is a valid feasible boundary. No fractional baseline is
  invented and no strong fixed-size comparison is suppressed.
- Full-policy fixed-comparator gains are negative in weak links, churn and
  combined, and practically negligible in uniform links. The paper is a
  mechanism-analysis study, not a universally superior scheduler claim.
- Runtime recovery is common across policies. Cancellation of expired
  transfers has separately matched interventions, including compute-only
  comparisons. The recovery effect is not credited to RSSI or prefetch.
- All 40 core/recovery tests share one Holm family. Pointwise bootstrap
  intervals, multiplicity adjustment, exchangeability and analysis conventions
  are explained; "prespecified" does not imply preregistration.
- Results are tables and selective interpretation. Five multi-panel figures
  include paired-seed ECDFs and descriptive resource audits. Losses, ties and
  metric directions are visible. Each heatmap has declared units and scales.
- Fourteen reference metadata records were obtained from Crossref. Unverified
  LATE/Dolly performance claims were removed. No claim of superiority over a
  faithful mobile-framework reproduction is made.
- Workflow and draft-process language is removed from the primary manuscript.
  IEEEtran provides journal layout; venue-specific compliance remains separate.
- Forty implementation checks, raw-based claim recomputation, world/policy
  pairing, common recovery, disjoint tuning seeds and macro consistency pass.

## Reasons a critical reviewer may still reject it

1. Scientific scope and novelty: negative/mechanism studies require a journal
   that values simulation methodology and reproducibility. This study does not
   establish a new general scheduling algorithm or full novelty over systems.
2. External validity: the mapping is stationary ns-3 UDP goodput and conditional
   unloaded echo, projected onto synthetic signals. Equal-airtime sharing,
   loaded delays, interference, fading, control cost, physical motion and task
   progress are not fully calibrated. No real testbed was conducted.
3. Mechanism dependence: the RSSI cutoff and task-cost observability are model
   assumptions. RSSI effects may arise from expiry risk rather than throughput;
   RTT weighting is inactive in these calibrated core cells. Prefetch and
   cutoff superiority remain unsupported.
4. Comparator scope: matched rules establish narrow mechanism contrasts;
   they are not reproductions of MAESTRO, Honeybee, CROWDio or other full systems.
5. Submission metadata: authors, corresponding email, funding, conflicts,
   contribution roles, consent, licensing and archival DOI remain unconfirmed.
   No missing declaration was fabricated in the manuscript.

These are material scientific and submission limitations, not defects that
formatting or denser graphics can eliminate. The manuscript cannot honestly be
called flawless, guaranteed acceptable, or physically validated.
