# Critical audit: current manuscript

Primary source: paper/mechanism_study_ieee.tex; output: paper/manuscript_ieee.pdf.
Supplement: paper/overhead_supplement.pdf. Earlier reports are historical.

## Addressed in the current protocol

- Coordinator service is explicit, serialized, swept over 0–20,000 ms and
  accompanied by 64 kB control traffic. The comparison retunes fixed size at
  every cost on separate seeds. Millisecond settings are interpreted alongside
  the disclosed one-second dispatch polling. Upper costs are unmeasured stress
  assumptions, not typical overhead measurements.
- Independent delay, eligible continuous-link variation and compute-heavy
  departures exercise previously inactive formula/prefetch regimes. Allocation
  hashes and dynamic-prefetch counters check activation independently of gains.
- The continuous-link cell remains above the eligibility cutoff, distinguishing
  continuous weighting from threshold rejection. A mobility/testbed claim does
  not follow from this intervention.
- Primary tables lead with the independently tuned comparator. Advantages over
  compute-only shrinking do not establish superiority over tuned dispatch.
- Obsolete transfers are canceled in every current policy. Retaining them is a
  runtime-correctness diagnostic, not a straw-man published-system comparator.
- 300 paired seeds per core/activation cell and 200 per cost point, with no
  significance-based stopping. One Student framework produces intervals,
  difference tests and TOST with a ±1 percentage-point equivalence margin.
  All 77 differences and 77 equivalence hypotheses share one Bonferroni family.
  Seed pairs, not individual tasks, are statistical replicates.
- Dense ECDFs, every contrast, settings and resources are supplementary;
  main figures focus on cost crossover and mechanism patterns. Earlier
  unreported numerical comparisons and draft-process claims are removed.
- Related work covers shrinking, trapezoid/adaptive scheduling, work stealing,
  straggler mitigation and mobile offloading. Direct system superiority is not
  claimed without a faithful implementation. Unconfirmed 2025/2026 entries
  are omitted from current citations; USENIX verification limits are explicit.

## Observed findings

All 22,400 evaluation runs complete. Full versus tuned gains in zero-service
core cells are +0.08% (uniform), -3.67% (weak links), -1.52% (churn), and
-4.65% (combined). Uniform meets the ±1 point equivalence criterion.
At 5,000 ms, full gains 3.81% over single-task dispatch and 1.26% over tuned
fixed chunks (simultaneous interval 1.01–1.52%). At 20,000 ms, full gains
64.94% over single-task dispatch but loses 32.10% to retuned fixed chunks.
Tuned fixed chunks first achieve a practical win over single-task dispatch
at 5,000 ms, gaining 2.58%. The tested crossover bracket is 1,000–5,000 ms.

RTT/RSSI activation interventions change allocations in all 300 worlds of
their targeted cells, but the corresponding effects meet the ±1 point
within-model equivalence criterion. In compute-heavy departures, prefetch
hurts against no prefetch (-3.11%), the cutoff helps (+1.33%), and the
stationary-only restriction remains inconclusive. These mixed results are
retained; they do not validate all proposed design choices.

## Remaining reviewer risks

This is still a conditional simulation study. Stationary UDP/echo calibration
is not mobile packet-scheduler or hardware validation. Independent delays,
control sizes and service costs are assumptions. Equal airtime, instantaneous
probe/progress updates, known task costs, synthetic participation and supplied
stationary labels limit external validity. More seeds reduce Monte Carlo
uncertainty, not modeling error. No faithful MAESTRO/CROWDio/Honeybee comparison
is claimed. These are substantive limits; formatting cannot remove them.

IEEEtran layout and a factual minimal biography are provided. Confirm final
author details, actual funding/conflicts, contribution roles and license before
submission. No declarations are fabricated. GitHub is not an archival DOI;
Zenodo publication requires authenticated access and confirmed metadata.
See AUTHOR_AND_ARCHIVE_STATUS.md and ARCHIVAL_DEPOSIT_README.md.

No flawless-paper or journal-acceptance guarantee is made. The defensible scope
is a reproducible dispatch-cost and mechanism-activation analysis. Journal fit
and need for measured validation remain editorial decisions.
