import unittest
from dataclasses import replace
from hpcsim.model import Scenario,generate_world,Simulation,POLICIES
class DispatchCostTests(unittest.TestCase):
 def test_positive_cost_charged_and_zero_cost_free(self):
  w=generate_world(Scenario(tasks=8,workers=2,horizon=1000,rho=0,uniform_links=True,dynamic_fraction=0),1)
  p=replace(POLICIES['B2-F'],fixed=1,cancel_expired_transfers=True)
  free=Simulation(w,p).run();cost=Simulation(w,p,dispatch_ms=10000,control_kb=10).run()
  self.assertEqual(free['dispatch_service_seconds'],0)
  self.assertEqual(cost['dispatch_service_seconds'],80)
  self.assertGreaterEqual(cost['makespan'],80)
  self.assertAlmostEqual(cost['control_requested_mb'],.08)
  self.assertGreater(cost['makespan'],free['makespan'])
 def test_negative_cost_rejected(self):
  with self.assertRaises(ValueError):Simulation(generate_world(Scenario(tasks=2),1),POLICIES['Proposed'],dispatch_ms=-1)
