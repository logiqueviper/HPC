import unittest
import numpy as np
from hpcsim.coherent_inference import paired_relative
from scripts.overhead_study import make_world
from hpcsim.model import Scenario,generate_world
class CoherentInferenceTests(unittest.TestCase):
 def test_difference_test_matches_adjusted_interval(self):
  r=paired_relative(np.arange(300)+90,np.arange(300)+100,10)
  self.assertTrue(r['difference_significant']);self.assertGreater(r['simultaneous_ci_low'],0)
 def test_equivalence_and_inconclusive_are_distinct(self):
  b=np.full(300,100.)
  tight=paired_relative(b+np.linspace(-.1,.1,300),b,10)
  wide=paired_relative(b+np.linspace(-20,20,300),b,10)
  self.assertTrue(tight['equivalent']);self.assertFalse(wide['equivalent'])
  self.assertFalse(wide['difference_significant'])
 def test_exact_sample_identity_flag(self):
  r=paired_relative(np.ones(300),np.ones(300),10)
  self.assertTrue(r['exact_sample_identity']);self.assertTrue(r['equivalent']);self.assertEqual(r['p_adjusted'],1)
 def test_constant_world_optimization_matches_full_trace(self):
  s=Scenario(tasks=20,workers=4,horizon=50,uniform_links=True,dynamic_fraction=0)
  a=generate_world(s,12);b=make_world(s,12,'standard')
  for field in ['costs','inputs_mb','base_speed','rssi','speed','reachable','permanent','positions']:np.testing.assert_array_equal(getattr(a,field),getattr(b,field))
