import unittest
import numpy as np
from hpcsim.analysis import holm, paired_statistics


class AnalysisValidation(unittest.TestCase):
    def test_improvement_sign(self):
        r = paired_statistics([90, 90, 90], [100, 100, 100], np.random.default_rng(1))
        self.assertEqual(r['improvement_pct'], 10)
        self.assertEqual(r['difference_s'], 10)

    def test_exact_floor(self):
        r = paired_statistics([90]*10, [100]*10, np.random.default_rng(1))
        self.assertEqual(r['permutation_count'], 1024)
        self.assertEqual(r['p_raw'], 2/1024)

    def test_holm_known_family(self):
        np.testing.assert_allclose(holm([.01, .04, .03]), [.03, .06, .06])

    def test_null(self):
        r = paired_statistics([100]*10, [100]*10, np.random.default_rng(1))
        self.assertEqual(r['p_raw'], 1)
        self.assertEqual(r['difference_s'], 0)

    def test_missing_completed_pairs_is_unavailable(self):
        r = paired_statistics([], [], np.random.default_rng(1))
        self.assertIsNone(r['improvement_pct'])
        self.assertEqual(r['n'], 0)


if __name__=='__main__':
    unittest.main()
