import unittest
from hpcsim.heft import independent_heft
from hpcsim.model import Scenario,generate_world,Simulation,POLICIES
class HEFTTests(unittest.TestCase):
    def test_independent_rank_and_eft(self):
        # CPU-only HEFT: highest upward rank first, then smallest EFT.
        a,o,f=independent_heft([10,6,2],[1,2])
        self.assertEqual(o,[0,1,2]);self.assertEqual(a,{0:1,1:0,2:1});self.assertEqual(f,{0:5.,1:6.,2:6.})
    def test_integration_completes_unique_tasks(self):
        r=Simulation(generate_world(Scenario(tasks=12,workers=3,horizon=1000,uniform_links=True,dynamic_fraction=0),11),POLICIES['HEFT-independent']).run()
        self.assertTrue(r['completed']);self.assertEqual(r['duplicate_acceptances'],0)
    def test_offline_comparator_rejects_mobility(self):
        with self.assertRaises(ValueError):Simulation(generate_world(Scenario(tasks=10,workers=4),1),POLICIES['HEFT-independent'])
