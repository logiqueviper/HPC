import unittest
import numpy as np
from hpcsim.paper_analysis import interaction_contrast


class InteractionValidation(unittest.TestCase):
    def test_additive_mechanisms_have_zero_interaction(self):
        np.testing.assert_equal(interaction_contrast([100],[90],[95],[85]),[0])

    def test_positive_means_superadditive_saving(self):
        np.testing.assert_equal(interaction_contrast([100],[90],[95],[80]),[5])
