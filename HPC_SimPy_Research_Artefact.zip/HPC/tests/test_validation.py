import unittest
from dataclasses import replace
import numpy as np
from hpcsim.model import (Scenario, generate_world, table_rate, round_trip_ms,
                          channel_rates, POLICIES, Policy, Simulation, World)


class Validation(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.s = Scenario(name='validation', tasks=24, workers=3, horizon=500,
                         uniform_links=True, dynamic_fraction=0, shadow_sd=0)
        cls.w = generate_world(cls.s, 2000)

    def test_V01_world_reproducible(self):
        self.assertEqual(self.w.fingerprint, generate_world(self.s, 2000).fingerprint)

    def test_V02_seeds_differ(self):
        self.assertNotEqual(self.w.fingerprint, generate_world(self.s, 2001).fingerprint)

    def test_V03_rate_monotone_and_cap(self):
        r = table_rate(np.arange(-100, -29))
        self.assertTrue(np.all(np.diff(r)>=0))
        self.assertEqual(r[0], 0)
        self.assertEqual(r[-1], 40)

    def test_V04_delay(self):
        self.assertAlmostEqual(float(round_trip_ms(-80)), 131.999, delta=.2)
        self.assertGreater(round_trip_ms(-85), 150)

    def test_V05_path_loss_sweep_changes_world(self):
        a = generate_world(replace(self.s, uniform_links=False, path_loss_exponent=2.5), 2000)
        b = generate_world(replace(self.s, uniform_links=False, path_loss_exponent=3.5), 2000)
        self.assertFalse(np.array_equal(a.rssi, b.rssi))

    def test_V06_legacy_capacity(self):
        np.testing.assert_allclose(channel_rates([40, 10], 'legacy'), [20, 5])

    def test_V07_throughput_fair(self):
        np.testing.assert_allclose(channel_rates([40, 10], 'throughput_fair'), [8, 8])
        np.testing.assert_allclose(channel_rates([40, 0], 'throughput_fair'), [40, 0])

    def test_V08_efficiency_overhead(self):
        self.assertTrue(np.all(channel_rates([40, 2], 'efficiency')<=channel_rates([40, 2], 'legacy')))

    def test_V09_complete_and_no_loss(self):
        for name in ['B2', 'P-full', 'P-noLink']:
            r = Simulation(self.w, POLICIES[name]).run()
            self.assertTrue(r['completed'])
            self.assertEqual(r['accepted'], self.s.tasks)
            self.assertEqual(r['duplicate_acceptances'], 0)

    def test_V10_deterministic_algorithm(self):
        self.assertEqual(Simulation(self.w, POLICIES['P-full']).run(),
                         Simulation(self.w, POLICIES['P-full']).run())

    def test_V11_world_readonly_and_unchanged(self):
        before = self.w.fingerprint
        Simulation(self.w, POLICIES['P-full']).run()
        self.assertEqual(before, self.w.fingerprint)
        with self.assertRaises(ValueError):
            self.w.rssi[0, 0] = 0

    def test_V12_censoring(self):
        w = generate_world(replace(self.s, horizon=1), 2000)
        r = Simulation(w, POLICIES['P-full']).run()
        self.assertFalse(r['completed'])
        self.assertEqual(r['makespan'], 1)
        self.assertLess(r['accepted'], r['tasks'])

    def test_V13_clipping_example(self):
        self.assertAlmostEqual(float(np.clip((-80+85)/25, .25, 1)*
                                    np.clip(20/round_trip_ms(-80), .25, 1)), .0625)

    def test_V14_prefetch_permanent_only(self):
        w = generate_world(replace(self.s, dynamic_fraction=1), 2000)
        a = Simulation(w, POLICIES['P-full']).run()
        b = Simulation(w, POLICIES['P-noPF']).run()
        self.assertEqual(a['makespan'], b['makespan'])

    def test_V15_transfer_accounting(self):
        r = Simulation(self.w, POLICIES['P-full']).run()
        self.assertAlmostEqual(r['transferred_mb'], self.w.inputs_mb.sum()*1.1, places=5)
        self.assertLessEqual(r['airtime_busy_seconds'], r['makespan']+1e-6)

    def late_world(self):
        s = Scenario(name='late-results-fixture', tasks=60, workers=2, horizon=1200,
                     uniform_links=True, dynamic_fraction=0)
        w = generate_world(s, 2000)
        reach = np.ones_like(w.reachable)
        reach[5:40, 0] = False
        return replace(w, costs=np.full(60, 10.), inputs_mb=np.full(60, .01),
                       speed=np.ones_like(w.speed), base_speed=np.ones(2), reachable=reach)

    def test_V16_naive_can_double_accept_end_to_end(self):
        p = Policy('fixture-naive', chunk='fixed', fixed=10, link=False, prefetch='none',
                   recovery='timeout', timeout=8, dedup=False, detector='none')
        r = Simulation(self.late_world(), p).run()
        self.assertTrue(r['completed'])
        self.assertGreater(r['duplicate_acceptances'], 0)
        self.assertGreater(r['duplicate_compute'], 0)

    def test_V17_idempotent_does_not_double_accept(self):
        p = Policy('fixture-idempotent', chunk='fixed', fixed=10, link=False, prefetch='none',
                   recovery='timeout', timeout=8, detector='none')
        r = Simulation(self.late_world(), p).run()
        self.assertTrue(r['completed'])
        self.assertEqual(r['duplicate_acceptances'], 0)
        self.assertGreater(r['duplicate_compute'], 0)

    def test_V18_fence_rejects_old_session(self):
        p = Policy('fixture-fenced', chunk='fixed', fixed=10, link=False, prefetch='none',
                   recovery='fenced', grace=0, detector='none')
        r = Simulation(self.late_world(), p).run()
        self.assertTrue(r['completed'])
        self.assertEqual(r['duplicate_acceptances'], 0)
        self.assertGreater(r['rejected_results'], 0)

    def test_V19_cpu_has_one_slot(self):
        sim = Simulation(self.w, POLICIES['P-full'])
        self.assertTrue(all(cpu.capacity==1 for cpu in sim.cpu))

    def test_V20_adwin_synthetic_step(self):
        from river.drift import ADWIN
        detector = ADWIN(delta=.002)
        changes = 0
        for x in [0.]*300+[1.]*300:
            detector.update(x)
            changes += detector.drift_detected
        self.assertGreater(changes, 0)

    def test_V21_bad_scenario_rejected(self):
        with self.assertRaises(ValueError):
            generate_world(replace(self.s, weak_fraction=2), 2000)

    def test_V22_stationary_nodes_do_not_move(self):
        w = generate_world(replace(self.s, dynamic_fraction=.5), 2000)
        self.assertTrue(np.all(w.positions[:, w.permanent]==w.positions[0, w.permanent]))
        self.assertFalse(np.all(w.positions[:, ~w.permanent]==w.positions[0, ~w.permanent]))

    def test_V23_prefetch_cutoff(self):
        sim = Simulation(self.w, POLICIES['Proposed'])
        r = sim.run()
        self.assertGreater(r['prefetch_chunks'], 0)
        self.assertEqual(r['dynamic_prefetch_chunks'], 0)
        self.assertTrue(all(progress<.75 for _, progress in sim.prefetch_records))

    def test_V24_disable_prefetch(self):
        p = replace(POLICIES['Proposed'], prefetch_cutoff=0)
        r = Simulation(self.w, p).run()
        self.assertEqual(r['prefetch_chunks'], 0)

    def test_V25_horizon_does_not_change_physical_world(self):
        longer = generate_world(replace(self.s, horizon=1000), 2000)
        np.testing.assert_array_equal(self.w.costs, longer.costs)
        np.testing.assert_array_equal(self.w.rssi, longer.rssi[:len(self.w.rssi)])

    def test_V26_independent_rtt_factor(self):
        sim = Simulation(self.w, POLICIES['Proposed'])
        sim.healthy[:] = True
        sim.link_observation[:] = -50
        sim.rtt_observation[:] = 10
        k_fast = sim.chunk_size(0)
        sim.rtt_observation[:] = 120
        self.assertLess(sim.chunk_size(0), k_fast)

    def test_V27_tail_and_utilization_bounds(self):
        r = Simulation(self.w, POLICIES['Proposed']).run()
        self.assertTrue(0<=r['compute_utilization']<=1)
        self.assertGreaterEqual(r['tail_idle_worker_seconds'], 0)


if __name__ == '__main__':
    unittest.main()
