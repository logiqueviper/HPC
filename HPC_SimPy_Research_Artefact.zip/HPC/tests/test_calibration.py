import unittest
from unittest.mock import patch
import numpy as np
from hpcsim.model import calibrated_ns3_rate
class CalibrationTests(unittest.TestCase):
    def test_no_silent_extrapolation(self):
        with patch('hpcsim.model.ns3_knots',return_value=np.array([[-80.,5.],[-50.,25.]])):
            for rssi in [-81.,-49.]:
                with self.assertRaises(ValueError):calibrated_ns3_rate(rssi)
    def test_supported_boundary_and_vector_rates(self):
        with patch('hpcsim.model.ns3_knots',return_value=np.array([[-80.,5.],[-50.,25.]])):
            np.testing.assert_allclose(calibrated_ns3_rate(np.array([-80.,-65.,-50.])),[5.,15.,25.])
