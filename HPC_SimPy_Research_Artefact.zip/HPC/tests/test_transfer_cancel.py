import unittest
import simpy
from hpcsim.model import Scenario,generate_world,Radio
class ExpiredTransferTests(unittest.TestCase):
 def test_expired_transfer_releases_waiter_and_stops_bytes(self):
  env=simpy.Environment();w=generate_world(Scenario(tasks=4,workers=2,horizon=100,uniform_links=True,dynamic_fraction=0),1);r=Radio(env,w,'legacy')
  obsolete=r.submit(0,100,assignment_id=10);valid=r.submit(1,100,assignment_id=11)
  env.run(until=.5);r.cancel_assignment(10)
  self.assertTrue(obsolete.triggered);self.assertFalse(obsolete.value)
  self.assertEqual([t.assignment_id for t in r.active],[11]);self.assertFalse(valid.triggered)
  env.run(until=25);self.assertTrue(valid.triggered);self.assertLess(r.mb,105)
