# Subsequent evidence revision

The original implementation remains unrecovered. PUBLICATION_REVISION.md records
subsequent ns-3, HEFT, censoring, reference and IEEE-format improvements. Historical
statuses below describe the earlier reconstruction, not a recovered original study.

# Item-by-item revision status

This is a new exploratory SimPy artefact, not a claim that the missing original study was reproduced. See REMAINING_WORK.md for submission blockers.

| Item | Status and evidence |
| --- | --- |
| A1 | New reconstruction: single positive-is-faster convention in hpcsim/analysis.py and generated macros. Original study cannot be recomputed without its data. |
| A2 | New reconstruction uses 10*n*log10(d/d0), parameterized exponent, P0 and d0; path-loss test V05. Original Fig. 1 is not regenerated. |
| A3 | New per-cell comparisons generated from paired raw files. Original inconsistent cells/values cannot be resolved without original results. |
| A4 | New policy ablations evaluated; original X9_rho03 Table IV cannot be reconstructed from PDF means. |
| A5 | Original scorecard preserved in the supplied PDF/audit; no invented replacement count. New statistical scorecard is explicitly exploratory. |
| A6 | Executable Policy dataclass and paper/policies.json define reconstruction switches. Original variant semantics remain unverified. |
| A7 | Classical and same-sigma Compute-shrink baselines included. A calibration-only baseline grid and untouched-seed tuned comparisons are included; original-study sigma sensitivity remains unavailable. |
| A8 | All observed losses retained. New no-cutoff and policy ablations reported without composition-wins claims; original noGrace result not revalidated. |
| A9 | New manuscript uses defined reference-cost units and consistent chunk equations; original LaTeX unavailable. |
| A10 | Reference-check requests blocked by proxy 403; evidence/references.json records the attempts. Verification incomplete. |
| B1 | All seeds retained in primary common-horizon restricted-time paired analysis; completion and survival plots included; completed-pair sensitivity retained. Independent log-rank test deliberately not misapplied to paired worlds. |
| B2 | Physical-world prefix invariant added (V25); reconstruction 1x/2x/4x horizon diagnostics run on fresh seeds. This is not a rerun of the unavailable original X3 study. |
| B3 | One globally corrected family combines all core and robustness comparisons in paper/analysis.json. |
| B4 | Paired d, paired intervals and consistent practical-win rule generated. Not a recalculation of original d. |
| B5 | Main and tuned cells use 50 fresh paired seeds; precision appendix includes approximate paired detectable differences. No false assertion of adequate post-correction power. |
| B6 | All new work labelled exploratory; no independent preregistration or public DOI claimed. Archive deposition pending. |
| B7 | Original H14 cannot be diagnosed without original raw data. New model dependence and censoring are reported. |
| C1 | Naive assignment acceptance, deduplicated acceptance and stale-session rejection implemented. End-to-end V16–V18 pass; return-time diagnostics in results/recovery_examples.json. |
| C2 | ADWIN synthetic test exists; detector removed from new main Proposed policy and explicitly not claimed effective. |
| C3 | Optional hysteresis/backoff policy evaluated in fresh two-fraction horizon diagnostics; exhaustive original X3 sweep remains unavailable. The cycle counter counts fencing declarations, not independently measured physical flaps. |
| C4 | Optional hybrid threshold rule implemented; calibration sweep not performed and no benefit claimed. |
| D1 | Three fluid channel rules evaluated. Overhead/loss model is explicitly uncalibrated, not falsely labelled a calibrated Bianchi model. |
| D2 | External ns-3/trace validation absent; main limitation in manuscript and REMAINING_WORK.md. |
| D3 | No physical cluster is available; no testbed measurements invented. Minimum measurement/testbed protocol in BENCHMARK_DESIGN.md. |
| D4 | Heavy-tailed costs, independent inputs and larger results evaluated in robustness cells. Pareto/bimodal options exist; alternative mobility and 64-worker sweep unrun. |
| D5 | Adapted speculative-copy baseline evaluated; close published wireless-policy reimplementation unavailable. No adaptation is called faithful LATE/MAESTRO/etc. |
| D6 | Matched remove-one ablations and a paired link/prefetch add-one-in factorial/interaction analysis included. Full interactions among every original mechanism remain unavailable. |
| E1 | New draft framed as empirical mechanism study with losses and limitations, not universal dominance. |
| E2 | Abstract populated with generated counts and paired effect macros; simulation-only status explicit. |
| E3 | Discussion includes channel dependence, incomplete runs, heuristic cutoff, nominal tuning and reconstruction limits. |
| E4 | Vector paired differences, completion/tail panels, survival curves, ablation heatmap and resource/model sensitivity figures generated from raw files. |
| E5 | Complete cell/policy completion and resource summaries generated as appendices; no original safety-counter reconstruction claimed. |
| E6 | Anand Kanade and institution taken from supplied synopsis; final author consent/contact, public DOI and official journal template remain pending. One-command reproduction script supplied. |
| E7 | New numerical text flows through generated macros and raw-data checker; original manuscript remains unchanged. |
