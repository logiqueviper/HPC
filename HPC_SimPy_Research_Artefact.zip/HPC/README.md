# Participation-aware wireless scheduling: SimPy artefact

This repository contains a **new exploratory reconstruction**, not the original simulator or a reproduction of the original paper's numerical results. The implementation follows the latest requested mechanisms and records the remaining scientific limitations.

## Implemented policy

- Shrinking chunks weighted by compute-only EWMA capability, observed RSSI and RTT, and unassigned work.
- Physically stationary workers only may prefetch one next chunk. Dynamic workers never prefetch under Proposed.
- Prefetch stops at 75% **accepted unique task completion**. Already reserved chunks finish normally. Idle workers have dispatch priority.
- Three unhealthy probes followed by bounded grace, session expiry, requeue of unaccepted IDs, and rejection of stale-session results.
- Task-ID deduplication, realistic survival of local computation during temporary disconnection, and counters for duplicate transfers requested, compute and acceptances.
- SimPy processes for probes, dispatch, fluid transfers and exclusive worker CPU resources; immutable shared seeded worlds.

## Install and reproduce

Python 3.12 and the pinned packages in requirements.txt were used. LaTeX with pdflatex, bibtex, longtable and pdflscape is required to build the PDF.

```bash
cd /workspace/HPC
python3 -m pip install --user -r requirements.txt
bash scripts/reproduce.sh
```

That command gates validation, regenerates joint paired analysis and vector figures from retained raw files, checks numerical macro consistency, and builds paper/manuscript.pdf.

For a complete deterministic simulation rerun:

```bash
bash scripts/reproduce.sh --fresh
```

Fresh outputs go into a separate timestamped directory and are compared with retained raw simulations. Running the default command does not rerun expensive simulations. The full fresh option reruns the main, robustness, calibration and horizon batches and can take tens of minutes. The default regeneration uses retained data and is much faster. Representative exact repeatability is recorded in paper/repeatability.json; the complete --fresh branch has not itself been rerun end to end.

Individual new batches:

```bash
python3 -m hpcsim.run --config configs/core.yaml --output results/another-core
python3 -m hpcsim.run --config configs/sensitivity.yaml --output results/another-sensitivity
python3 scripts/recovery_examples.py
python3 scripts/calibrate_baselines.py --output results/another-calibration
python3 scripts/horizon_diagnostics.py --output results/another-horizon
```

The runner refuses to overwrite an existing raw.json. Recovery examples regenerate their explicitly constructed diagnostic output. No service needs to remain running.

## Experiment design

configs/core.yaml uses fresh paired seeds 2000–2049 and four cells, with nominated classical policies and matched mechanism ablations. configs/sensitivity.yaml uses seeds 2100–2119 and three physical/workload cells under three contention rules. The nominal batches are not claimed independently preregistered. A separate calibration uses seeds 1000–1019 to choose fixed-size and weighted-shrinking baseline parameters, followed by evaluation on untouched seeds 2400–2449. Horizon/hysteresis diagnostics use seeds 2500–2509 and physical-world-preserving horizon extensions. The older pilot config is a smaller optional configuration, not a completed original-study evaluation.

Every batch starts with the validation gate. World randomness depends only on scenario and seed; policy execution draws no random numbers. Administrative horizon changes preserve world prefixes. Analysis resampling uses its own documented seed. Raw files, config copies, dependency versions and source hashes are retained with each batch.

The globally adjusted paper analysis combines all evaluation comparisons and post-hoc link-by-prefetch interactions in one family. Per-batch analysis files retain their batch-specific adjustment; paper/analysis.json is the authoritative complete-family inference for the manuscript. Primary times are restricted to each cell's common horizon; completion fractions are separate. Completed-pair analysis is explicitly a sensitivity. Paired effect size and approximate precision diagnostics are retained; undefined standardized effects are NA rather than fabricated.

## Outputs

- results/core and results/sensitivity: per-run JSON/CSV, summary and comparison CSV, config and provenance.
- results/calibration: baseline grid, selection rule, calibration data and untouched-seed evaluation.
- results/horizon: matched-world longer-horizon and hysteresis diagnostics.
- results/recovery_examples.json: constructed late-return diagnostics, not a physical experiment.
- paper/manuscript.tex and manuscript.pdf: research draft, not submission-ready.
- paper/supplement.tex and supplement.pdf: full scenario, policy, completion, safety, resource and inference tables.
- paper/numbers.tex and check_numbers.py: generated numerical macros and raw-data consistency check.
- paper/*.pdf and *.svg: vector figures.
- paper/CLAIM_SOURCES.json: comparison-to-source provenance.
- BENCHMARK_DESIGN.md: competitors, scenarios, metrics and minimum external validation route.
- CHANGELOG.md, RESPONSE_TO_REVIEWERS.md and REMAINING_WORK.md: status against the original requested revisions.

## Limits

The throughput knots and overhead/loss rule are assumed, not measured. Channel allocation is per active positive-rate transfer, not per physical Wi-Fi station. Control probes are observed instantaneously and counted, not transmitted through the data-channel model. Permanent coordinates are fixed but shadowing and signal quality can vary. Task outputs are committed per completed chunk; task-ID correctness models identity, not malicious or numerically incorrect worker results.

Prefetch assumes instrumented worker progress reports after simulated compute intervals; these reports are instantaneous and have no modelled telemetry cost. Nominal task costs are known benchmark metadata. This assumption requires explicit instrumentation and overhead measurement in a physical prototype.

Compute cost executed but not represented in accepted tasks is an overhead metric at stopping time; it includes unfinished/reserved computation and is not solely duplicate work. Tail idle begins at 75% accepted completion and includes nominal slots for unavailable workers. Duplicate input volume counts repeated input requests, whereas transferred_mb records bytes actually transmitted. No counter should be presented as measured energy or physical airtime.

An independent ns-3 diagnostic and stationary curve sensitivity are now included; no measured testbed, published trace or end-to-end packet-level scheduler validation is claimed. HEFT's independent-task core is compared, but a faithful close wireless scheduler remains outstanding. Standard IEEEtran journal formatting and Crossref metadata verification are included; author declarations, venue-specific checks and archival deposition remain outstanding. Anand Kanade's name and institution were taken from the supplied synopsis; coauthors and publication consent were not inferred. The ZIP has been uploaded to the research-deliverables GitHub branch. No journal submission or publication has occurred.

## Publication revision and IEEE version

See PUBLICATION_REVISION.md for completed evidence and remaining gaps. The revised
main deliverable is paper/manuscript_ieee.pdf, built with IEEEtran journal layout.
The generic article and supplementary PDF are retained. New raw data are in
results/ns3, results/ns3_sensitivity, results/heft and results/combined_horizon.
The expanded joint analysis includes all scheduler comparisons and interactions.

The default reproduction command rebuilds the IEEE and generic papers from
retained data. The fresh option now repeats all scheduler batches, including
revision diagnostics, using the retained ns-3 training curve. It does not rerun
ns-3 itself; validation/run_ns3.py is its separate optional pipeline. Preserve
the existing ns-3 output directory before a deliberate rerun.
