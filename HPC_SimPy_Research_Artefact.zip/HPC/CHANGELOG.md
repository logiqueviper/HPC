# Changelog — exploratory reconstruction

Original files and PDF were not overwritten. The original 15-hypothesis record is not re-labelled as new confirmatory evidence.

- A1, B1, B3–B5, E2, E7: paired common-horizon analysis, positive improvement convention, all-seed completion reporting, global Holm correction, effect sizes, precision diagnostics and generated numerical macro checks.
- A2, A6, A9: parameterized path loss, explicit throughput knots/units, immutable physical worlds and executable variant definitions. Reconstruction assumptions recorded rather than inferred as original code.
- A7–A8, E1–E3: classical and matched compute-only comparisons, equal prominence of losses, no claim of universal composition dominance or optimized cutoff.
- C1: naive double acceptance, task-ID deduplication and stale-session rejection; constructed end-to-end tests and late-return diagnostic outputs.
- C2: ADWIN included diagnostically but excluded from the main contribution.
- C3–C4: optional hysteresis/backoff and hybrid rules implemented but not promoted as validated experimental gains.
- D1, D4–D5: three explicitly defined fluid contention rules, heavy-tailed independent-input robustness, delay independent of RSSI, and a labelled speculative-copy adaptation.
- E4–E6: vector figures, full completion/resource tables, comparison-source ledger, manuscript source/PDF generation and one-command reproduction.
- Latest user clarification: permanent means physically stationary; no Proposed prefetch to dynamic nodes; stop new prefetch at 75% unique accepted completion; idle workers precede look-ahead reservations. Separate no-prefetch, unrestricted-prefetch and no-cutoff benchmarks.
- A10, B6, D2–D3, E6: external bibliography/template requests blocked by network policy; no external validation, physical data, preregistration DOI or archive DOI fabricated. Concrete remaining work listed separately.

See RESPONSE_TO_REVIEWERS.md for all 34 requested item statuses. This changelog does not represent unfinished original-paper corrections as completed.

- A7, B2, B3, C3, D6: calibration-only grid and fresh tuned-baseline evaluation, matched-world horizon/hysteresis diagnostics, link/prefetch interaction contrasts and expanded common Holm family. Strong tuned comparisons replace weak-baseline emphasis in the abstract.
- Reproduction: final analysis gate extended with two interaction-sign tests; simulation batches passed the original reconstruction gate before execution. Representative exact repeatability covers every evaluated scenario/model.
