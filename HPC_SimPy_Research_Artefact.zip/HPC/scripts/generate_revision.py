"""Generate revision claims/graphics directly from joint analysis and ns-3 data."""
from pathlib import Path
import json,csv,sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root));p=root/'paper'
a=json.loads((p/'analysis.json').read_text());radio=json.loads((root/'results/ns3/report.json').read_text())
def comparison(cell,baseline):
    j,r=next((j,r) for j,r in enumerate(a['comparisons']) if r['scenario']==cell and r['comparator']==baseline)
    return 'C'+chr(65+j//26)+chr(65+j%26),r
def summary(cell,policy):
    j,r=next((j,r) for j,r in enumerate(a['summary']) if r['scenario']==cell and r['algorithm']==policy)
    return 'S'+chr(65+j//26)+chr(65+j%26),r
values={'NsThreeRuns':str(sum(1 for _ in (root/'results/ns3/raw.csv').open())-1),'NsThreeEchoRTT':f"{radio['unloaded_echo_holdout']['mean_rtt_ms']:.3f}",'NsThreeEchoError':f"{radio['unloaded_echo_holdout']['assumed_rtt_mae_ms']:.2f}"}
for n,t in [('1','Single'),('2','Two'),('4','Four')]:
    r=radio['holdout_by_station_count'][n]
    for k,suffix in [('legacy_mae_mbps','Assumed'),('calibrated_mae_mbps','Fitted')]:values['NsThree'+t+suffix]=f'{r[k]:.3f}'
(p/'revision_numbers.tex').write_text(''.join('\\newcommand{\\'+k+'}{'+v+'}\n' for k,v in values.items()))
lines=[r'\section{Independent radio checks and post-hoc diagnostics}',r'\input{revision_numbers.tex}',r'\subsection{Packet-level radio diagnostic}',r'An independent ns-3 diagnostic contains \NsThreeRuns{} runs of stationary IEEE 802.11a downlink saturation and separate unloaded UDP echo trials. The model uses a single AP, ideal rate adaptation, log-distance loss without fading, co-located receivers at each distance, and no mobile scheduler execution. Single-station application-goodput knots use RNG runs 1--3; holdout runs 4--5 test the same distances and additional receiver counts. This tests repeatability and concurrency generalization, not unseen-distance or physical-device accuracy.',r'Assumed-curve versus fitted-curve holdout aggregate-goodput MAE is \NsThreeSingleAssumed{} versus \NsThreeSingleFitted{} Mbps for one receiver, \NsThreeTwoAssumed{} versus \NsThreeTwoFitted{} Mbps for two, and \NsThreeFourAssumed{} versus \NsThreeFourFitted{} Mbps for four. The very small fitted errors arise in a deliberately simple, unfaded topology and should not be generalized to real Wi-Fi. Unloaded echo averages \NsThreeEchoRTT{} ms; the assumed RSSI/RTT function has MAE \NsThreeEchoError{} ms. Unloaded echo does not calibrate RTT under saturation.',r'\begin{figure}[htbp]\centering\includegraphics[width=\linewidth]{ns3_radio_check.pdf}\caption{Independent ns-3 goodput and unloaded-echo diagnostics. The fitted curve uses training seeds only; scheduler evaluations using it remain fluid-channel simulations.}\end{figure}',r'\subsection{Sensitivity to the ns-3-derived curve}',r'Two additional stationary cells use fresh paired seeds, fixed strong or mixed RSSI values within the calibration support, and no fading or departures. SimPy uses the training goodput knots and unloaded-echo RTT knots; no extrapolation is permitted. All original assumed-channel results remain retained. These experiments probe whether mechanism conclusions survive one alternative mapping, not whether complete scheduling gains reproduce in ns-3. Their comparisons join the expanded global Holm family.']
for cell in ['ns3_stationary_strong','ns3_stationary_mixed']:
    for base in ['Tuned-fixed','Compute-shrink','HEFT-independent','Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-noCutoff']:
        t,r=comparison(cell,base);verdict='meets' if r['practical_win'] else 'does not meet'
        lines.append(cell.replace('_',' ').capitalize()+' versus '+base+f': signed gain \\{t}Percent\\% (paired difference interval [\\{t}Low, \\{t}High] s; global Holm $p=\\{t}P$), which '+verdict+' the prespecified practical-win threshold. The new cells and comparator are exploratory additions.')
lines.append(r'The mixed-cell gain over the tuned fixed-size baseline fails the practical-win rule. RSSI and RTT removals give identical times in both calibrated cells. Thus, these stationary calibrated experiments do not support an incremental benefit from the link factors. Their high-throughput, low-unloaded-delay regime differs from the assumed weak-link/churn scenarios; it does not disprove benefits under other conditions.')
lines += [r'\subsection{Combined-cell censoring sensitivity}',r'A post-hoc extension retains all original combined-cell seeds and the physical trace prefixes while increasing the horizon. These repeated worlds are not independent new evidence. The extended comparisons join the global family; the original horizon comparisons are retained once rather than duplicated.']
for base in ['B2','B4-F','Compute-shrink','Proposed-noRSSI','Proposed-noRTT','Proposed-allPrefetch','Proposed-noCutoff']:
    t,r=comparison('combined_extended_h16000',base);s,_=summary('combined_extended_h16000',base);q,_=summary('combined_extended_h16000','Proposed')
    lines.append(base+f': completion \\{s}Completion{{}} versus Proposed \\{q}Completion{{}}; signed restricted-time gain \\{t}Percent\\% (interval [\\{t}Low, \\{t}High] s). Remaining censored runs still prevent an unrestricted mean-completion claim.')
lines += [r'\subsection{Published scheduling core comparator}',r'HEFT is evaluated on independent tasks with stationary workers. Upward rank reduces to mean CPU duration across workers; descending ranks are assigned to the worker with earliest predicted CPU finish. Nominal task costs and initial worker speeds are known to this comparator. There are no DAG edges, so communication-edge costs and insertion gaps disappear. Input/output traffic is executed by the shared fluid model after mapping. This is the published CPU-scheduling core for a restricted problem, not a reproduction of LATE, MAESTRO, CROWDio or Honeybee. A hand-calculated ranking/EFT case and end-to-end task-ID test accompany the implementation.']
for cell in ['uniform','weak_links']:
    t,r=comparison(cell,'HEFT-independent');s,_=summary(cell,'HEFT-independent')
    lines.append(cell.replace('_',' ').capitalize()+f': HEFT completion \\{s}Completion{{}}; Proposed signed restricted-time gain \\{t}Percent\\% (interval [\\{t}Low, \\{t}High] s). A censored comparison is not an unrestricted speedup claim.')
(p/'revision_diagnostics.tex').write_text('\n\n'.join(lines)+'\n')
# Lead with the separately tuned comparator, then disclose the weaker mechanisms.
t,_=comparison('tuned_combined','Tuned-fixed');u,_=comparison('combined','Proposed-allPrefetch')
v,_=comparison('ns3_stationary_mixed','Tuned-fixed')
(p/'revision_abstract.tex').write_text(f'Against the calibration-selected fixed-size baseline on untouched combined-cell seeds, signed improvement is \\{t}Percent\\% (paired restricted-time difference interval [\\{t}Low, \\{t}High] s). Stationary-only prefetch underperforms unrestricted prefetch in the nominal combined cell by a signed \\{u}Percent\\%. With the independent ns-3-derived mapping in a stationary mixed-link cell, improvement over the fixed-size comparator is \\{v}Percent\\% (interval [\\{v}Low, \\{v}High] s). All comparative inference uses the expanded global family; the ns-3 diagnostic does not validate end-to-end mobile scheduling.\n')
rows=list(csv.DictReader((root/'results/ns3/raw.csv').open()));fig,axes=plt.subplots(1,2,figsize=(10,3.8),layout='constrained')
for n in [1,2,4]:
    rs=[r for r in rows if float(r['traffic'])==1 and float(r['stations'])==n and float(r['seed'])>=4]
    x=[];y=[]
    for d in [25,20,15,10,5,2]:
        z=[r for r in rs if float(r['distance_m'])==d];x.append(np.mean([float(r['rssi_dbm']) for r in z]));y.append(np.mean([float(r['aggregate_mbps']) for r in z]))
    axes[0].plot(x,y,'o-',label=f'ns-3 holdout, {n} receivers')
from hpcsim.model import table_rate,round_trip_ms
x=np.linspace(-82,-49,200);axes[0].plot(x,table_rate(x),'--',label='Original assumption');kn=np.array(radio['knots']);axes[0].plot(kn[:,0],kn[:,1],':',label='Single-receiver fit');axes[0].set_ylabel('Aggregate goodput (Mbps)');axes[0].set_xlabel('AP data-frame RSSI (dBm)');axes[0].legend(fontsize=7)
echo=[r for r in rows if float(r['traffic'])==0 and float(r['seed'])>=4];axes[1].scatter([float(r['rssi_dbm']) for r in echo],[float(r['rtt_ms']) for r in echo],label='ns-3 unloaded echo');axes[1].plot(x,round_trip_ms(x),'--',label='Original assumption');axes[1].set_yscale('log');axes[1].set_xlabel('AP data-frame RSSI (dBm)');axes[1].set_ylabel('Unloaded RTT (ms, log scale)');axes[1].legend(fontsize=7)
for fmt in ['pdf','svg']:fig.savefig(p/('ns3_radio_check.'+fmt))
plt.close(fig)
# The current manifest always derives from current source data, never from prose.
(p/'REVISION_CLAIM_SOURCES.json').write_text(json.dumps({'radio':'results/ns3/report.json','scheduler':'paper/analysis.json','raw':['results/heft/raw.json','results/combined_horizon/raw.json','results/ns3_sensitivity/raw.json'],'family_count':a['family_count'],'numeric_macros':values},indent=2)+'\n')
print('Generated revision diagnostics, abstract, radio figure and claim ledger')
