"""New primary: dispatch-cost sweeps, 300 core seeds, and activation cells."""
import sys,json,hashlib,argparse
from pathlib import Path
from dataclasses import replace,asdict
from concurrent.futures import ProcessPoolExecutor
import numpy as np
import yaml
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from hpcsim.model import Scenario,World,generate_world,extended_ns3_knots,POLICIES,Simulation
def make_world(s,seed,profile):
 # Exact constant trace optimization for the strong stationary cell. Task and
 # worker randomness is unchanged because administrative horizon is excluded.
 if s.uniform_links and s.dynamic_fraction==0 and s.weak_fraction==0 and s.slowdown_probability==0:
  short=generate_world(replace(s,horizon=1),seed);nt=int(np.ceil(s.horizon))+2;n=s.workers
  def constant(a):
   z=np.broadcast_to(a,(nt,)+a.shape).copy();z.setflags(write=False);return z
  w=replace(short,scenario=s,rssi=constant(short.rssi[0]),speed=constant(short.speed[0]),reachable=constant(short.reachable[0]),positions=constant(short.positions[0]),rtt_ms=constant(short.rtt_ms[0]))
 else:w=generate_world(s,seed)
 if profile=='continuous':
  r=w.rssi.copy();t=np.arange(len(r))[:,None];r[:,s.workers//2:]=-75+3*np.sin(t/45+np.arange(s.workers//2)[None,:]);r.setflags(write=False);w=replace(w,rssi=r)
 k=extended_ns3_knots();x=np.array([a['rssi'] for a in k])
 if w.rssi.min()<x.min() or w.rssi.max()>x.max():raise ValueError('Out of calibration support')
 rtt=np.interp(w.rssi,x,[a['rtt_ms'] for a in k])+s.extra_rtt_ms
 rate=np.interp(w.rssi,x,[a['goodput'] for a in k]);delivery=np.interp(w.rssi,x,[a['echo_delivery'] for a in k]);reach=w.reachable&(rate>0)&(delivery>0)
 rtt.setflags(write=False);reach.setflags(write=False);return replace(w,rtt_ms=rtt,reachable=reach)
def job(item):
 entry,seed,policies=item;s=Scenario(**entry['scenario']);w=make_world(s,seed,entry['profile']);rows=[]
 for p in policies:
  r=Simulation(w,p,'ns3_extended',dispatch_ms=entry['dispatch_ms'],control_kb=entry['control_kb']).run();r['scenario']=entry['name'];rows.append(r)
 return rows
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(root/'results/overhead_study'));args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 if (out/'raw.json').exists():raise SystemExit('Preserve existing raw data')
 entries=[];core=yaml.safe_load((root/'configs/core.yaml').read_text())['scenarios']
 for e in core:entries.append(dict(name='core_'+e['name'],scenario=e,profile='standard',dispatch_ms=0.,control_kb=0.,seeds=list(range(6000,6300)),kind='core'))
 base=dict(name='dispatch_physics',tasks=240,workers=8,horizon=10000,uniform_links=True,dynamic_fraction=0)
 for cost in [0,1,10,100,1000,5000,20000]:
  entries.append(dict(name='dispatch_'+str(cost),scenario=base,profile='standard',dispatch_ms=float(cost),control_kb=64.,seeds=list(range(6300,6500)),kind='sweep'))
 # Independent injected delay, useful-radio continuous weighting, and
 # compute-heavy availability/prefetch activation. These are synthetic cells.
 entries += [
  dict(name='independent_rtt',scenario=dict(name='independent_rtt',tasks=240,workers=8,horizon=4000,uniform_links=True,dynamic_fraction=0,extra_rtt_ms=80),profile='standard',dispatch_ms=100.,control_kb=64.,seeds=list(range(6500,6800)),kind='activation'),
  dict(name='continuous_rssi',scenario=dict(name='continuous_rssi',tasks=240,workers=8,horizon=4000,uniform_links=True,dynamic_fraction=0),profile='continuous',dispatch_ms=100.,control_kb=64.,seeds=list(range(6500,6800)),kind='activation'),
  dict(name='prefetch_departure',scenario=dict(name='prefetch_departure',tasks=240,workers=8,horizon=4000,uniform_links=True,dynamic_fraction=.5,rho=.01,slowdown_probability=.5),profile='standard',dispatch_ms=100.,control_kb=64.,seeds=list(range(6500,6800)),kind='activation')]
 fixed=[replace(POLICIES['B2-F'],name=f'Fixed-{k}',fixed=k,cancel_expired_transfers=True) for k in [1,2,3,4,8,16,32]]
 calibration=[];selections={}
 with ProcessPoolExecutor(max_workers=4) as pool:
  for entry in entries:
   rows=[]
   for b in pool.map(job,[(entry,seed,fixed) for seed in range(5000,5020)]):rows.extend(b)
   means={p.fixed:float(np.mean([r['makespan'] for r in rows if r['algorithm']==p.name])) for p in fixed};k=min(means,key=lambda z:(means[z],z));selections[entry['name']]=k;calibration.extend(rows);print('Tuned',entry['name'],'size',k,flush=True)
 (out/'calibration.json').write_text(json.dumps(calibration,indent=2)+'\n')
 standard=[replace(POLICIES[n],cancel_expired_transfers=True) for n in ['Proposed','Compute-shrink','Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff']]
 evaluation=[]
 with ProcessPoolExecutor(max_workers=4) as pool:
  for entry in entries:
   tuned=replace(POLICIES['B2-F'],name='Tuned-fixed',fixed=selections[entry['name']],cancel_expired_transfers=True)
   policies=standard+[tuned] if entry['kind']!='sweep' else [standard[0],standard[1],tuned,replace(tuned,name='Fixed-one',fixed=1)]
   for i,b in enumerate(pool.map(job,[(entry,seed,policies) for seed in entry['seeds']])):
    evaluation.extend(b)
    if (i+1)%100==0:print(entry['name'],i+1,'/',len(entry['seeds']),'worlds',flush=True)
   (out/'checkpoint.json').write_text(json.dumps(dict(completed_entry=entry['name'],runs=len(evaluation))))
 (out/'raw.json').write_text(json.dumps(evaluation,indent=2)+'\n')
 (out/'protocol.json').write_text(json.dumps(dict(entries=entries,selected_sizes=selections,tuning_seeds=list(range(5000,5020)),grid=[1,2,3,4,8,16,32],selection_rule='Within-cell minimum mean restricted completion time; ties smaller size',statistical_plan='Paired relative mean effects; Student t confidence intervals and tests; joint Bonferroni difference and +/-1 percent TOST equivalence claims. CLT approximation, all paired seeds retained.',precision_plan='Core/activation 300 seeds: six times earlier 50 seeds, aiming to narrow Monte Carlo mean uncertainty by sqrt(6); sweep 200 paired worlds per cost; no significance-based stopping',source_sha256=hashlib.sha256((root/'hpcsim/model.py').read_bytes()).hexdigest(),scope='Unmeasured serialized coordinator service and bidirectional control volume, plus injected independent delay; probes/progress still instantaneous'),indent=2)+'\n')
 print('Saved',len(evaluation),'new fair-comparison runs',flush=True)
