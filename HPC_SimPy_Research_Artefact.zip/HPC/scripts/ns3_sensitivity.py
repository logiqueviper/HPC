"""Fresh stationary sensitivity to ns-3 training knots and unloaded echo RTT.

Fluid scheduler execution, not packet-level end-to-end scheduling. Restricted
to calibrated RSSI support; no mobile/churn or wall-loss extrapolation.
"""
import sys,json,csv,hashlib,argparse
from pathlib import Path
from dataclasses import replace,asdict
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario,generate_world,Simulation,POLICIES,Policy
root=Path(__file__).resolve().parents[1];parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(root/'results/ns3_sensitivity'));args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
if (out/'raw.json').exists():raise SystemExit('Refuse to overwrite retained data')
radio=list(csv.DictReader((root/'results/ns3/raw.csv').open()));knots=[]
for distance in [25,20,15,10,5,2]:
    a=[r for r in radio if float(r['traffic'])==0 and float(r['seed'])<=3 and float(r['distance_m'])==distance]
    if any(float(r['echo_received'])!=100 for r in a):raise ValueError('Incomplete training echoes')
    knots.append([np.mean([float(r['rssi_dbm']) for r in a]),np.mean([float(r['rtt_ms']) for r in a])])
selection=json.loads((root/'results/calibration/selection.json').read_text())['selected']['fixed'];fixed=replace(Policy(**selection),name='Tuned-fixed')
rows=[];settings=[]
for name,q in [('ns3_stationary_strong',0.),('ns3_stationary_mixed',.5)]:
    s=Scenario(name=name,tasks=240,workers=8,horizon=4000,uniform_links=True,dynamic_fraction=0,weak_fraction=q,shadow_sd=0)
    settings.append(asdict(s))
    for seed in range(2600,2620):
        w=generate_world(s,seed);rtt=np.interp(w.rssi,*np.array(knots).T);rtt.setflags(write=False);w=replace(w,rtt_ms=rtt)
        for n in ['Proposed','Compute-shrink','Tuned-fixed','HEFT-independent','Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-noCutoff']:
            rows.append(Simulation(w,fixed if n=='Tuned-fixed' else POLICIES[n],model='ns3_calibrated').run())
    print(name,'done',flush=True)
(out/'raw.json').write_text(json.dumps(rows,indent=2)+'\n');(out/'config.json').write_text(json.dumps(settings,indent=2)+'\n')
(out/'provenance.json').write_text(json.dumps(dict(training_rtt_knots=knots,ns3_report_sha256=hashlib.sha256((root/'results/ns3/report.json').read_bytes()).hexdigest(),seeds=list(range(2600,2620)),scope='stationary SimPy sensitivity to independent ns-3 single-station training goodput and unloaded echo; equal-airtime generalization only'),indent=2)+'\n')
