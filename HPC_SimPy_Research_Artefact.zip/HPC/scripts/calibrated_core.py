"""Calibrate strong fixed-size comparators and rerun every core scenario.

Uses an ns-3-derived stationary goodput/conditional-echo lookup projected onto
the existing signal traces. No physical or coupled mobile validation claimed.
"""
import sys,json,csv,yaml,hashlib,argparse
from pathlib import Path
from dataclasses import replace,asdict
from concurrent.futures import ProcessPoolExecutor
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from hpcsim.model import Scenario,POLICIES,Simulation,generate_world,extended_ns3_knots
from hpcsim.analysis import summarize
def world(s,seed):
 w=generate_world(s,seed);k=extended_ns3_knots();x=np.array([a['rssi'] for a in k])
 if w.rssi.min()<x.min() or w.rssi.max()>x.max():raise ValueError('Unsupported signal range')
 rtt=np.interp(w.rssi,x,[a['rtt_ms'] for a in k]);rate=np.interp(w.rssi,x,[a['goodput'] for a in k]);delivery=np.interp(w.rssi,x,[a['echo_delivery'] for a in k]);reach=w.reachable&(rate>0)&(delivery>0)
 rtt.setflags(write=False);reach.setflags(write=False)
 return replace(w,rtt_ms=rtt,reachable=reach)
def run_job(job):
 s,seed,policies=job;w=world(s,seed)
 return [Simulation(w,p,'ns3_extended').run() for p in policies]
if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(root/'results/calibrated_core'));args=parser.parse_args();out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
 if (out/'raw.json').exists():raise SystemExit('Refuse overwrite')
 scenarios=[Scenario(**e) for e in yaml.safe_load((root/'configs/core.yaml').read_text())['scenarios']]
 fixed=[replace(POLICIES['B2-F'],name=f'Fixed-{k}',fixed=k,cancel_expired_transfers=True) for k in [1,2,3,4,8,16,32]]
 calibration=[]
 with ProcessPoolExecutor(max_workers=3) as pool:
  for i,b in enumerate(pool.map(run_job,[(s,seed,fixed) for s in scenarios for seed in range(4000,4010)])):
   calibration.extend(b)
   if (i+1)%10==0:print('Calibration',i+1,'/40 worlds',flush=True)
 means={p.name:{s.name:np.mean([r['makespan'] for r in calibration if r['algorithm']==p.name and r['scenario']==s.name]) for s in scenarios} for p in fixed}
 best={s.name:min(means[p.name][s.name] for p in fixed) for s in scenarios}
 score={name:max(v[cell]/best[cell]-1 for cell in v) for name,v in means.items()}
 selected=min(fixed,key=lambda p:(score[p.name],np.mean(list(means[p.name].values())),p.fixed))
 policies=[replace(POLICIES[n],cancel_expired_transfers=True) for n in ['Proposed','Compute-shrink','Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff']]
 policies += [replace(selected,name='Tuned-fixed'),replace(POLICIES['Proposed'],name='Proposed-retainExpired'),replace(POLICIES['Compute-shrink'],name='Compute-retainExpired')]
 evaluation=[]
 with ProcessPoolExecutor(max_workers=3) as pool:
  for i,b in enumerate(pool.map(run_job,[(s,seed,policies) for s in scenarios for seed in range(4800,4850)])):
   evaluation.extend(b)
   if (i+1)%25==0:print('Evaluation',i+1,'/200 worlds',flush=True)
 (out/'calibration.json').write_text(json.dumps(calibration,indent=2)+'\n');(out/'raw.json').write_text(json.dumps(evaluation,indent=2)+'\n')
 (out/'analysis.json').write_text(json.dumps(summarize(evaluation),indent=2)+'\n')
 (out/'protocol.json').write_text(json.dumps(dict(scenarios=[asdict(s) for s in scenarios],policies=[asdict(p) for p in policies],grid=[p.fixed for p in fixed],selected_fixed=selected.fixed,selection_rule='Minimum worst-cell relative regret, ties mean then smaller integer chunk',scores=score,calibration_seeds=list(range(4000,4010)),evaluation_seeds=list(range(4800,4850)),minimum_chunk_note='One indivisible task is the feasible lower boundary; fractional chunks are invalid',ns3_report_sha256=hashlib.sha256((root/'results/ns3_extended/report.json').read_bytes()).hexdigest(),source_sha256=hashlib.sha256((root/'hpcsim/model.py').read_bytes()).hexdigest(),scope='Stationary calibrated lookup with assumed shared airtime, instantaneous probes and progress, conditional unloaded echo, and synthetic availability; not fully calibrated networking'),indent=2)+'\n');print('Saved complete calibrated core',flush=True)
