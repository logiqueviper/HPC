#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 scripts/build_ieee.py
cd paper
pdflatex -interaction=nonstopmode -halt-on-error manuscript_ieee.tex > ieee-pass1.log
bibtex manuscript_ieee > ieee-bibliography.log
pdflatex -interaction=nonstopmode -halt-on-error manuscript_ieee.tex > ieee-pass2.log
pdflatex -interaction=nonstopmode -halt-on-error manuscript_ieee.tex > ieee-pass3.log
