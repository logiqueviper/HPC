#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m unittest discover -s tests
python3 scripts/render_overhead.py
python3 scripts/check_overhead.py
bash scripts/build_ieee.sh
cd paper
pdflatex -interaction=nonstopmode -halt-on-error overhead_supplement.tex > overhead-supplement1.log
pdflatex -interaction=nonstopmode -halt-on-error overhead_supplement.tex > overhead-supplement2.log
