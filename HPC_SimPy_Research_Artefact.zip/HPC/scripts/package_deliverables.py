"""Package source, retained publication data, plots and final PDFs with hashes."""
from pathlib import Path
import hashlib,json,shutil,zipfile
root=Path(__file__).resolve().parents[1];out=root.parent/'outputs';out.mkdir(exist_ok=True)
excluded={'.git','.venv','__pycache__','build','ns3-unfiltered-diagnostic','ns3-integer-rtt-diagnostic'}
def keep(p):
    rel=p.relative_to(root)
    return p.is_file() and not any(x in excluded for x in rel.parts) and not any(x.startswith('reproduction-') for x in rel.parts) and p.suffix not in {'.pyc','.aux','.log','.out','.toc','.blg'} and p.name!='ARTIFACT_MANIFEST.json'
files=sorted(p for p in root.rglob('*') if keep(p))
manifest={'status':'exploratory reconstruction; IEEE-format research draft, not a submission or acceptance','primary_scheduler_runs':22400,'primary_tuning_runs':1960,'historical_scheduler_runs':5480,'ns3_radio_runs':190,'validation_tests':46,'files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}}
(root/'ARTIFACT_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
copies={'IEEE_Journal_Manuscript.pdf':'manuscript_ieee.pdf','Participation_Aware_Scheduling_Supplement.pdf':'overhead_supplement.pdf'}
for destination,source in copies.items():shutil.copyfile(root/'paper'/source,out/destination)
archive=out/'HPC_SimPy_Research_Artefact.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[root/'ARTIFACT_MANIFEST.json']:z.write(p,'HPC/'+str(p.relative_to(root)))
    for name in copies:z.write(out/name,name)
    z.writestr('READ_ME_FIRST.txt','Start with IEEE_Journal_Manuscript.pdf. The current supplement is also included. Historical PDFs inside HPC/paper are provenance and are superseded by this primary paper. HPC/ contains source, raw data, figures, LaTeX, tests and reproduction scripts. HPC/PUBLICATION_REVISION.md records what remains before submission. The primary study uses 22400 paired scheduler runs, 1960 tuning runs and 190 ns-3 radio runs. It is a mechanism study, not a scheduler superiority claim. No hardware measurements, faithful mobile-framework reproduction, confirmed author declarations or Zenodo DOI are claimed.\n')
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for name,digest in manifest['files'].items():assert hashlib.sha256(z.read('HPC/'+name)).hexdigest()==digest
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'source_files':len(files),'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2))
