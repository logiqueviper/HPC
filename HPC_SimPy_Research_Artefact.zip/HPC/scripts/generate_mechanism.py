"""Primary tables and dense figures from the recalibrated core only."""
import sys,json,unittest
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from hpcsim.analysis import summarize,paired_statistics,holm
p=root/'paper';raw=json.loads((root/'results/calibrated_core/raw.json').read_text());protocol=json.loads((root/'results/calibrated_core/protocol.json').read_text());radio=json.loads((root/'results/ns3_extended/report.json').read_text());a=summarize(raw);df=pd.DataFrame(raw);rng=np.random.default_rng(57103);cells=['uniform','weak_links','churn','combined']
for cell in cells:
 x=df[(df.scenario==cell)&(df.algorithm=='Compute-shrink')].sort_values('seed');y=df[(df.scenario==cell)&(df.algorithm=='Compute-retainExpired')].sort_values('seed')
 assert list(x.seed)==list(y.seed)
 a['comparisons'].append(dict(scenario=cell,model='ns3_extended',candidate='Compute-shrink',comparator='Compute-retainExpired',**paired_statistics(x.makespan,y.makespan,rng)))
for r,q in zip(a['comparisons'],holm([r['p_raw'] for r in a['comparisons']])):
 r['p_holm_global']=float(q);r['practical_win']=bool(q<.05 and r['improvement_pct']>=1)
a['family_count']=len(a['comparisons']);a['multiplicity_family']='All recalibrated core full-policy contrasts plus four matched compute recovery interventions'
(p/'mechanism_analysis.json').write_text(json.dumps(a,indent=2)+'\n')
values={'CoreRunCount':str(len(raw)),'RadioRunCount':str(radio['radio_runs_total']),'TuningRunCount':str(len(json.loads((root/'results/calibrated_core/calibration.json').read_text()))),'TuningSeedCount':str(len(protocol['calibration_seeds'])),'EvaluationSeedCount':str(len(protocol['evaluation_seeds'])),'SelectedChunk':str(protocol['selected_fixed']),'TestCount':str(unittest.defaultTestLoader.discover(str(root/'tests')).countTestCases()),'ComparisonCount':str(a['family_count']),'ExtendedMAE':f"{radio['holdout_goodput_mae_mbps']:.3f}"}
def tag(j):return chr(65+j//26)+chr(65+j%26)
for j,r in enumerate(a['comparisons']):
 for key,suffix,fmt in [('improvement_pct','Gain','.2f'),('difference_s','Difference','.2f'),('ci_low','Low','.2f'),('ci_high','High','.2f'),('p_holm_global','P','.4f'),('p_raw','RawP','.5f')]:values['M'+tag(j)+suffix]=format(r[key],fmt)
for j,r in enumerate(a['summary']):
 for key,suffix,fmt in [('completion_rate','Complete','.2f'),('restricted_mean_s','Time','.2f'),('transferred_mb','Data','.1f'),('wasted_compute_cost','Waste','.1f')]:values['N'+tag(j)+suffix]=format(r[key],fmt)
 values['N'+tag(j)+'Requeues']=format(df[(df.scenario==r['scenario'])&(df.algorithm==r['algorithm'])].requeues.mean(),'.1f')
def claim(cell,base,candidate='Proposed'):
 j,r=next((j,r) for j,r in enumerate(a['comparisons']) if r['scenario']==cell and r['comparator']==base and r['candidate']==candidate);return 'M'+tag(j),r
def esc(s):return s.replace('_',r'\_')
def table(caption,baselines,candidate='Proposed'):
 lines=[r'\begin{table*}[!t]\centering\caption{'+caption+r'}\small',r'\begin{tabular}{llrrrr}\toprule Scenario & Comparator & Gain (\%) & Difference (s) & Pointwise 95\% CI (s) & Holm $p$\\\midrule']
 for cell in cells:
  for b in baselines:
   t,r=claim(cell,b,candidate);lines.append(esc(cell)+' & '+esc(b)+f' & \\{t}Gain & \\{t}Difference & [\\{t}Low, \\{t}High] & \\{t}P'+r'\\')
 lines += [r'\bottomrule\end{tabular}\end{table*}'];return '\n'.join(lines)
fixed=[claim(c,'Tuned-fixed')[1] for c in cells];wins=[r['scenario'] for r in fixed if r['practical_win']];completion=min(r['completion_rate'] for r in a['summary']);values['MinimumComplete']=f'{completion:.2f}'
abstract=r'The tuned comparator selects \SelectedChunk{} task(s) per allocation. '
abstract+=('The full policy meets the adjusted statistical and practical thresholds against that comparator in '+', '.join(c.replace('_',' ') for c in wins)+'. ') if wins else 'The full policy meets the joint statistical and practical win rule against that comparator in none of the core scenarios. '
t,_=claim('combined','Tuned-fixed');u,_=claim('combined','Compute-shrink');v,_=claim('combined','Compute-retainExpired','Compute-shrink')
abstract+=f'In the combined scenario, its signed gain is \\{t}Gain\\% relative to fixed dispatch and \\{u}Gain\\% relative to compute-only shrinking. Canceling expired transfers improves compute-only scheduling by \\{v}Gain\\%. '
abstract+=r'The minimum completion fraction across policy--scenario cells is \MinimumComplete{}. Prefetch and recovery interventions are reported with signed effects and matched comparisons rather than credited to the complete policy.'
(p/'mechanism_abstract.tex').write_text(abstract+'\n')
results=[r'\subsection{Primary Comparators}',table('Full policy versus separately tuned fixed-size and matched compute-only scheduling. Positive values favor the full policy.',['Tuned-fixed','Compute-shrink']),abstract,r'The completion table in the supplement retains every policy and scenario. A favorable contrast against compute-only scheduling does not establish improvement over the stronger tuned comparator.',r'\subsection{Prefetch and Link-Factor Ablations}',table('Mechanism contrasts against the full policy. Negative gains favor removing or relaxing the indicated mechanism.',['Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff'])]
for base in ['Proposed-noRSSI','Proposed-noRTT','Proposed-allPrefetch','Proposed-noCutoff']:
 rs=[claim(c,base)[1] for c in cells];ties=[r['scenario'] for r in rs if abs(r['difference_s'])<1e-9];loss=[r['scenario'] for r in rs if r['improvement_pct']<0];benefit=[r['scenario'] for r in rs if r['practical_win']]
 results.append(esc(base)+': '+('identical completion times in '+', '.join(c.replace('_',' ') for c in ties)+'. ' if ties else '')+('signed losses in '+', '.join(c.replace('_',' ') for c in loss)+'. ' if loss else '')+('full-policy practical wins in '+', '.join(c.replace('_',' ') for c in benefit)+'.' if benefit else 'No full-policy practical win under the adjusted rule.'))
results += [r'\subsection{Recovery Intervention}',table('Matched compute-only recovery intervention: candidate cancels expired transfers; comparator retains them.',['Compute-retainExpired'],candidate='Compute-shrink'),r'The full-policy retained-transfer contrast and all resource counters appear in the supplement. All primary chunking comparisons use cancellation consistently. Requeued IDs, transmitted bytes, and unaccepted computation diagnose simulated overhead, not measured energy or physical failure.']
(p/'mechanism_results.tex').write_text('\n\n'.join(results)+'\n')
(p/'mechanism_calibration.tex').write_text(r'The expanded single-receiver holdout goodput MAE is \ExtendedMAE{} Mbps. Small error at identical stationary training positions reflects limited stochastic variation and does not validate moving or heterogeneous contending stations.'+'\n')
lines=[r'\small\begin{longtable}{lllrrrr}\toprule Cell & Candidate & Comparator & Gain (\%) & CI (s) & Raw $p$ & Holm $p$\\\midrule\endhead']
for j,r in enumerate(a['comparisons']):
 t='M'+tag(j);lines.append(' & '.join(esc(r[k]) for k in ['scenario','candidate','comparator'])+f' & \\{t}Gain & [\\{t}Low, \\{t}High] & \\{t}RawP & \\{t}P'+r'\\')
lines += [r'\bottomrule\end{longtable}\normalsize'];(p/'mechanism_all_comparisons.tex').write_text('\n'.join(lines)+'\n')
lines=[r'\small\begin{longtable}{llrrrrr}\toprule Cell & Policy & Complete & Restricted time & Data (MB) & Unaccepted cost & Requeued IDs\\\midrule\endhead']
for j,r in enumerate(a['summary']):
 t='N'+tag(j);lines.append(esc(r['scenario'])+' & '+esc(r['algorithm'])+f' & \\{t}Complete & \\{t}Time & \\{t}Data & \\{t}Waste & \\{t}Requeues'+r'\\')
lines += [r'\bottomrule\end{longtable}\normalsize'];(p/'mechanism_completion.tex').write_text('\n'.join(lines)+'\n')
(p/'mechanism_numbers.tex').write_text(''.join('\\newcommand{\\'+k+'}{'+v+'}\n' for k,v in values.items()))
(p/'mechanism_numeric_sources.json').write_text(json.dumps(dict(macros=values,analysis='paper/mechanism_analysis.json',raw='results/calibrated_core/raw.json',radio='results/ns3_extended/report.json'),indent=2)+'\n')
lines=[r'\subsection{Scenario Settings}',r'\begin{longtable}{llr}\toprule Scenario & Parameter & Value\\\midrule\endhead']
for s in protocol['scenarios']:
 for k,v in s.items():
  if k!='name':lines.append(esc(s['name'])+' & '+esc(k)+' & '+esc(str(v))+r'\\')
lines += [r'\bottomrule\end{longtable}',r'\subsection{Policy Definitions}',r'\begin{longtable}{ll}\toprule Policy & Complete switches\\\midrule\endhead']
for policy in protocol['policies']:
 lines.append(esc(policy['name'])+' & '+r'\begin{minipage}{.70\textwidth}\small '+'; '.join(esc(k)+'='+esc(str(v)) for k,v in policy.items() if k!='name')+r'\end{minipage}\\[4pt]')
lines += [r'\bottomrule\end{longtable}',r'\subsection{Calibration Knots}',r'\begin{longtable}{rrrrr}\toprule Receive power & Goodput (Mbps) & Echo RTT/timeout (ms) & Delivery & Decoded data frames\\\midrule\endhead']
for k in radio['knots']:lines.append(' & '.join(format(k[x],'.4g') for x in ['rssi','goodput','rtt_ms','echo_delivery','decoded_data_frames'])+r'\\')
lines += [r'\bottomrule\end{longtable}',r'Zero decoded frames imply configured receive power, not observed RSSI. Zero echo delivery implies the 400 ms timeout convention, not a measured RTT.',r'\subsection{Fixed-Size Tuning}',r'\begin{longtable}{lr}\toprule Candidate & Worst-cell relative regret\\\midrule']
for name,score in protocol['scores'].items():lines.append(esc(name)+' & '+format(score,'.6f')+r'\\')
lines += [r'\bottomrule\end{longtable}',r'Calibration seeds: '+', '.join(map(str,protocol['calibration_seeds']))+'. Evaluation seeds: '+', '.join(map(str,protocol['evaluation_seeds']))+'.']
(p/'mechanism_protocol.tex').write_text('\n'.join(lines)+'\n')
plt.rcParams.update({'font.size':12,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
 for ext in ['pdf','svg']:fig.savefig(p/(name+'.'+ext))
 plt.close(fig)
fig,axes=plt.subplots(2,2,figsize=(10,6),layout='constrained')
for ax,c in zip(axes.flat,cells):
 rs=[claim(c,b)[1] for b in ['Tuned-fixed','Compute-shrink']];d=np.array([r['difference_s'] for r in rs]);lo=np.array([r['ci_low'] for r in rs]);hi=np.array([r['ci_high'] for r in rs]);ax.errorbar(d,[0,1],xerr=np.array([d-lo,hi-d]),fmt='o',capsize=4);ax.set_yticks([0,1],['Tuned fixed','Compute shrinking']);ax.axvline(0,color='gray',lw=1);ax.set_title(c.replace('_',' '));ax.set_xlabel('Comparator minus full time (s)')
save(fig,'mechanism_baselines')
variants=['Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff'];heat=np.array([[claim(c,b)[1]['improvement_pct'] for c in cells] for b in variants]);fig,ax=plt.subplots(figsize=(10,5),layout='constrained');limit=max(1,np.abs(heat).max());im=ax.imshow(heat,cmap='RdBu',vmin=-limit,vmax=limit,aspect='auto');ax.set_xticks(range(4),[c.replace('_',' ') for c in cells]);ax.set_yticks(range(5),['No RSSI','No RTT','No prefetch','All-worker prefetch','No cutoff'])
for i in range(5):
 for j in range(4):ax.text(j,i,f'{heat[i,j]:.2f}',ha='center',va='center')
fig.colorbar(im,ax=ax,label='Full policy signed gain (%)');save(fig,'mechanism_ablations')
fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained');kn=radio['knots'];axes[0].plot([r['rssi'] for r in kn],[r['goodput'] for r in kn],'o-');axes[0].set_ylabel('Application goodput (Mbps)');axes[0].set_xlabel('Receive-power coordinate (dBm)');axes[1].plot([r['rssi'] for r in kn],[r['echo_delivery'] for r in kn],'o-');axes[1].set_ylabel('Training echo delivery fraction');axes[1].set_xlabel('Receive-power coordinate (dBm)');save(fig,'mechanism_calibration')
fig,axes=plt.subplots(4,3,figsize=(10,9),layout='constrained')
for i,c in enumerate(cells):
 for j,(candidate,baseline,title) in enumerate([('Proposed','Tuned-fixed','Tuned fixed minus full'),('Proposed','Proposed-noCutoff','No cutoff minus full'),('Compute-shrink','Compute-retainExpired','Retained minus canceled (compute)')]):
  x=df[(df.scenario==c)&(df.algorithm==candidate)].sort_values('seed');y=df[(df.scenario==c)&(df.algorithm==baseline)].sort_values('seed');delta=np.sort(y.makespan.to_numpy()-x.makespan.to_numpy());ax=axes[i,j];ax.step(delta,np.arange(1,51)/50,where='post');ax.axvline(0,color='gray',lw=.8);ax.set_ylim(0,1.02);ax.set_title(c.replace('_',' ')+'\n'+title,fontsize=11);ax.set_xlabel('Paired difference (s)',fontsize=10)
  if j==0:ax.set_ylabel('Empirical fraction')
save(fig,'mechanism_paired_distributions')
fig,axes=plt.subplots(1,3,figsize=(10,5),layout='constrained');names=['Proposed','Compute-shrink','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff']
for ax,metric,title in zip(axes,['transferred_mb','wasted_compute_cost','compute_utilization'],['Data transmitted','Unaccepted compute','CPU utilization']):
 heat=np.empty((5,4))
 for i,name in enumerate(names):
  for j,c in enumerate(cells):
   x=df[(df.scenario==c)&(df.algorithm==name)].sort_values('seed')[metric].to_numpy();b=df[(df.scenario==c)&(df.algorithm=='Tuned-fixed')].sort_values('seed')[metric].to_numpy();heat[i,j]=np.median(x-b)
 bound=max(1e-6,np.abs(heat).max());im=ax.imshow(heat,cmap='RdBu',vmin=-bound,vmax=bound,aspect='auto');ax.set_title(title);ax.set_xticks(range(4),['Uniform','Weak','Churn','Combined'],rotation=60);ax.set_yticks(range(5),names if ax is axes[0] else ['']*5)
 for i in range(5):
  for j in range(4):ax.text(j,i,f'{heat[i,j]:.2f}',ha='center',va='center',fontsize=9)
 fig.colorbar(im,ax=ax,location='bottom',label={'transferred_mb':'Median paired MB difference','wasted_compute_cost':'Median paired cost difference','compute_utilization':'Median paired fraction difference'}[metric],shrink=.9)
save(fig,'mechanism_resources')
print(json.dumps({'runs':len(raw),'family':a['family_count'],'fixed':protocol['selected_fixed'],'minimum_completion':completion,'tuned_fixed_practical_wins':wins},indent=2))
