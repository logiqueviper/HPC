#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
python3 -m unittest discover -s tests
python3 scripts/generate_mechanism.py
python3 scripts/check_mechanism.py
cp paper/mechanism_study_ieee.tex paper/manuscript_ieee.tex
cd paper
pdflatex -interaction=nonstopmode -halt-on-error manuscript_ieee.tex > mechanism-pass1.log
bibtex manuscript_ieee > mechanism-bibliography.log
pdflatex -interaction=nonstopmode -halt-on-error manuscript_ieee.tex > mechanism-pass2.log
pdflatex -interaction=nonstopmode -halt-on-error manuscript_ieee.tex > mechanism-pass3.log
pdflatex -interaction=nonstopmode -halt-on-error mechanism_supplement.tex > mechanism-supplement1.log
pdflatex -interaction=nonstopmode -halt-on-error mechanism_supplement.tex > mechanism-supplement2.log
