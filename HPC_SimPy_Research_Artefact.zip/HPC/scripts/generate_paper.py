"""Regenerate a draft manuscript and vector figures from completed raw runs."""
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import json
import re
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from hpcsim.analysis import macro_values, latex_macros
from hpcsim.paper_analysis import joint_analysis
from hpcsim.model import POLICIES, Policy

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'paper'

def tag(j):
    return chr(65+j//26)+chr(65+j%26)

def escape(s):
    return str(s).replace('_', r'\_').replace('%', r'\%').replace('&', r'\&')

def km(ax, runs, label):
    # All censoring is administrative at a common horizon within each cell.
    times = np.asarray(runs.makespan)
    events = np.asarray(runs.completed)
    unique = sorted(set(times[events]))
    xs, ys, survival = [0], [1.], 1.
    for t in unique:
        at_risk = np.count_nonzero(times>=t)
        deaths = np.count_nonzero((times==t)&events)
        survival *= 1-deaths/at_risk
        xs.append(t);ys.append(survival)
    xs.append(float(runs.horizon.iloc[0]));ys.append(survival)
    ax.step(xs, ys, where='post', label=label)
    ax.scatter(times[~events], [survival]*np.count_nonzero(~events), marker='+', s=18)

def build():
    raw = []
    for name in ['core', 'sensitivity']:
        raw.extend(json.loads((ROOT/'results'/name/'raw.json').read_text()))
    raw.extend(json.loads((ROOT/'results/calibration/evaluation.json').read_text()))
    raw.extend(json.loads((ROOT/'results/horizon/raw.json').read_text()))
    definitions=dict(POLICIES)
    from dataclasses import replace
    selection=json.loads((ROOT/'results/calibration/selection.json').read_text())['selected']
    definitions['Tuned-fixed']=replace(Policy(**selection['fixed']),name='Tuned-fixed')
    definitions['Tuned-weighted']=replace(Policy(**selection['weighted']),name='Tuned-weighted')
    analysis = joint_analysis(raw)
    OUT.mkdir(exist_ok=True)
    (OUT/'analysis.json').write_text(json.dumps(analysis, indent=2, allow_nan=False)+'\n')
    (OUT/'raw-combined.json').write_text(json.dumps(raw, indent=2, allow_nan=False)+'\n')
    values = macro_values(analysis, raw)
    values['FamilyCount']=str(analysis['family_count'])
    values['SelectedFixedSize']=str(selection['fixed']['fixed'])
    values['SelectedWeightedShare']=format(selection['weighted']['sigma'],'.3g')
    values.update(CalibrationRunCount=str(len(json.loads((ROOT/'results/calibration/raw.json').read_text()))),
                  CalibrationSeedCount=str(len(json.loads((ROOT/'results/calibration/selection.json').read_text())['calibration_seeds'])),
                  TunedSeedCount=str(len(set(r['seed'] for r in raw if r['scenario'].startswith('tuned_')))),
                  HorizonSeedCount=str(len(set(r['seed'] for r in raw if r['scenario'].startswith('horizon_')))))
    import unittest
    count = unittest.defaultTestLoader.discover(str(ROOT/'tests')).countTestCases()
    values.update(ValidationCount=str(count), SimulationValidationCount=str(count-2),
                  MainSeedCount=str(len(set(r['seed'] for r in raw if r['scenario'] in ['uniform','weak_links','churn','combined']))),
                  RobustSeedCount=str(len(set(r['seed'] for r in raw if r['scenario'] in ['model_weak','heavy_independent','high_rtt']))))
    ledger = []
    for j,row in enumerate(analysis['comparisons']):
        ident = tag(j)
        values['C'+ident+'D'] = 'NA' if row['paired_d'] is None else f"{row['paired_d']:.3f}"
        values['C'+ident+'N'] = str(row['n'])
        values['C'+ident+'RawP'] = f"{row['p_raw']:.5f}"
        values['C'+ident+'Floor'] = str(row['permutation_count'])
        values['C'+ident+'CompleteN'] = str(row['completed_pairs_sensitivity']['n'])
        delta = row['difference_s']
        # Approximate unadjusted two-sided 80% power detectable paired difference.
        df = pd.DataFrame(raw)
        cell = df[(df.scenario==row['scenario'])&(df.model==row['model'])]
        a = cell[cell.algorithm==row['candidate']].set_index('seed').sort_index()
        b = cell[cell.algorithm==row['comparator']].set_index('seed').sort_index()
        sd = (b.makespan-a.makespan).std(ddof=1)
        values['C'+ident+'MDE'] = f'{(1.95996398454+.84162123357)*sd/np.sqrt(row["n"]):.2f}'
        ledger.append(dict(claim=f"{row['candidate']} versus {row['comparator']} in {row['scenario']}, {row['model']}",
                           macro_prefix='C'+ident, source='paper/analysis.json:comparisons['+str(j)+']',
                           estimand='baseline minus candidate, common-horizon restricted mean',
                           practical_win=row['practical_win'], externally_validated=False))
    for j,row in enumerate(analysis['summary']):
        for field,suffix in [('transferred_mb','Bytes'),('compute_utilization','Util'),
                             ('prefetch_chunks','Prefetch'),('wasted_compute_cost','Waste'),
                             ('tail_idle_worker_seconds','Tail'),('duplicate_compute','DupCompute')]:
            value = row[field]
            values['S'+tag(j)+suffix] = 'NA' if value is None else f'{value:.2f}'

    import yaml
    from hpcsim.model import Scenario
    from dataclasses import asdict
    settings=[]
    for batch in ['core','sensitivity']:
        config=yaml.safe_load((ROOT/'results'/batch/'config.yaml').read_text())
        settings.extend(asdict(Scenario(**entry)) for entry in config['scenarios'])
    settings.extend(json.loads((ROOT/'results/calibration/config.json').read_text()))
    for setting in settings[-4:]:setting['name']='tuned_'+setting['name']
    settings.extend(json.loads((ROOT/'results/horizon/config.json').read_text()))
    lines=[r'\small',r'\begin{longtable}{lrrrrrrrrr}',r'\toprule Cell & Tasks & Workers & Horizon & Speed ratio & Cost CV & Transfer ratio & Dynamic & Weak & Extra RTT\\\midrule\endhead']
    for j,setting in enumerate(settings):
        prefix='Param'+tag(j)
        columns=[]
        for field,suffix in [('tasks','Tasks'),('workers','Workers'),('horizon','Horizon'),('heterogeneity','H'),('cost_cv','CV'),('rho','Rho'),('dynamic_fraction','Dynamic'),('weak_fraction','Weak'),('extra_rtt_ms','RTT')]:
            values[prefix+suffix]=format(setting[field], '.3g')
            columns.append(chr(92)+prefix+suffix)
        lines.append(escape(setting['name'])+' & '+' & '.join(columns)+r'\\')
    lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'scenario_settings.tex').write_text('\n'.join(lines)+'\n')
    (OUT/'scenario_settings.json').write_text(json.dumps(settings,indent=2)+'\n')
    (OUT/'numbers.tex').write_text(latex_macros(values))
    (OUT/'CLAIM_SOURCES.json').write_text(json.dumps(ledger, indent=2)+'\n')
    summary = pd.DataFrame(analysis['summary'])
    comparisons = pd.DataFrame(analysis['comparisons'])
    summary.to_csv(OUT/'summary.csv', index=False)
    comparisons.drop(columns=['completed_pairs_sensitivity']).to_csv(OUT/'comparisons.csv', index=False)
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'pdf.fonttype':42,'svg.fonttype':'none'})
    core_cells = ['uniform','weak_links','churn','combined']
    main = comparisons[comparisons.scenario.isin(core_cells)]
    baseline_names = ['B1','B2','B3','B4-F','Compute-shrink','Speculative']
    fig, axes = plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for ax,cell in zip(axes.ravel(),core_cells):
        rows = main[(main.scenario==cell)&main.comparator.isin(baseline_names)].set_index('comparator').reindex(baseline_names)
        y = np.arange(len(rows))
        ax.errorbar(rows.difference_s,y,xerr=np.vstack([rows.difference_s-rows.ci_low,rows.ci_high-rows.difference_s]),fmt='o',capsize=3)
        ax.axvline(0,color='grey',lw=1);ax.set_yticks(y,baseline_names);ax.set_title(cell.replace('_',' '))
        ax.set_xlabel('Baseline − proposed restricted time (s)');ax.invert_yaxis()
    save(fig,'paired_baselines')
    fig,axes = plt.subplots(1,2,figsize=(12,5),layout='constrained')
    names = ['B2','Compute-shrink','Proposed','Proposed-noPrefetch','Proposed-noCutoff']
    for algorithm in names:
        rows=summary[(summary.scenario.isin(core_cells))&(summary.algorithm==algorithm)].set_index('scenario').reindex(core_cells)
        axes[0].plot(range(4),rows.completion_rate,marker='o',label=algorithm)
        axes[1].plot(range(4),rows.tail_idle_worker_seconds,marker='o',label=algorithm)
    for ax in axes:ax.set_xticks(range(4),core_cells,rotation=15)
    axes[0].set_ylim(-.03,1.03);axes[0].set_ylabel('Completed fraction');axes[1].set_ylabel('Tail idle (CPU worker-seconds)')
    axes[1].legend(fontsize=8);save(fig,'completion_tail')
    mechanisms=['Proposed-noCompute','Proposed-noRSSI','Proposed-noRTT','Proposed-noShrink','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff']
    heat=main[main.comparator.isin(mechanisms)].pivot(index='comparator',columns='scenario',values='improvement_pct').reindex(index=mechanisms,columns=core_cells)
    fig,ax=plt.subplots(figsize=(10,6),layout='constrained')
    bound=max(1,np.nanmax(np.abs(heat.values)))
    im=ax.imshow(heat.values,cmap='RdBu',vmin=-bound,vmax=bound,aspect='auto')
    ax.set_xticks(range(4),core_cells);ax.set_yticks(range(len(mechanisms)),mechanisms)
    for i in range(len(mechanisms)):
        for j in range(4):ax.text(j,i,f'{heat.values[i,j]:.2f}',ha='center',va='center',fontsize=9)
    fig.colorbar(im,ax=ax,label='Proposed improvement over comparator (%)');save(fig,'ablation_heatmap')
    fig,axes=plt.subplots(2,2,figsize=(12,8),layout='constrained')
    df=pd.DataFrame(raw)
    for ax,cell in zip(axes.ravel(),core_cells):
        for name in ['B2','Compute-shrink','Proposed']:
            km(ax,df[(df.scenario==cell)&(df.algorithm==name)],name)
        ax.set_title(cell);ax.set_ylabel('Fraction not yet complete');ax.set_xlabel('Simulated time (s)');ax.legend(fontsize=8)
    save(fig,'completion_survival')
    robustness=comparisons[comparisons.scenario=='model_weak']
    fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for name in ['B2','Compute-shrink','Proposed-noLink','Proposed-noPrefetch','Proposed-noCutoff']:
        rows=robustness[robustness.comparator==name].set_index('model').reindex(['legacy','throughput_fair','efficiency'])
        axes[0].plot(range(3),rows.improvement_pct,marker='o',label=name)
    axes[0].axhline(0,color='grey');axes[0].set_xticks(range(3),['equal airtime','throughput fair','overhead/loss'],rotation=15)
    axes[0].set_ylabel('Proposed improvement (%)');axes[0].legend(fontsize=8)
    for name in ['B2','Compute-shrink','Proposed']:
        rows=summary[(summary.scenario=='model_weak')&(summary.algorithm==name)].set_index('model').reindex(['legacy','throughput_fair','efficiency'])
        axes[1].plot(range(3),rows.completion_rate,marker='o',label=name)
    axes[1].set_xticks(range(3),['equal airtime','throughput fair','overhead/loss'],rotation=15);axes[1].set_ylim(-.03,1.03);axes[1].set_ylabel('Completed fraction');save(fig,'contention_robustness')
    fig,axes=plt.subplots(1,2,figsize=(12,5),layout='constrained')
    for name in ['B2','Compute-shrink','Proposed','Proposed-allPrefetch','Speculative']:
        rows=summary[(summary.scenario.isin(core_cells))&(summary.algorithm==name)].set_index('scenario').reindex(core_cells)
        axes[0].plot(range(4),rows.transferred_mb,marker='o',label=name)
        axes[1].plot(range(4),rows.wasted_compute_cost,marker='o',label=name)
    for ax in axes:ax.set_xticks(range(4),core_cells,rotation=15)
    axes[0].set_ylabel('Data actually transferred (MB)');axes[1].set_ylabel('Unaccepted compute (reference-cost seconds)');axes[1].legend(fontsize=8);save(fig,'resource_costs')
    tables=[]
    for cell in core_cells:
        lines=[r'\subsection{'+escape(cell)+r'}',r'\begin{longtable}{lrrrrr}',r'\toprule Comparator & Gain (\%) & Difference (s) & 95\% CI (s) & Holm $p$ & Paired $d$\\\midrule']
        for j,row in enumerate(analysis['comparisons']):
            if row['scenario']!=cell:continue
            t='C'+tag(j)
            lines.append(escape(row['comparator'])+f' & \\{t}Percent & \\{t}Delta & [\\{t}Low, \\{t}High] & \\{t}P & \\{t}D'+r'\\')
        lines += [r'\bottomrule\end{longtable}']
        tables+=lines
    (OUT/'comparison_tables.tex').write_text('\n'.join(tables)+'\n')
    lines=[r'\small',r'\begin{longtable}{lllrrrr}',r'\toprule Cell & Model & Policy & RM time (s) & Complete & Dup. accept & Prefetch \\\midrule\endhead']
    for j,row in enumerate(analysis['summary']):
        t='S'+tag(j)
        lines.append(' & '.join(escape(row[k]) for k in ['scenario','model','algorithm'])+f' & \\{t}Mean & \\{t}Completion & \\{t}Duplicates & \\{t}Prefetch'+r'\\')
    lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'completion_table.tex').write_text('\n'.join(lines)+'\n')
    lines=[r'\small',r'\begin{longtable}{lllrrrr}',r'\toprule Cell & Model & Policy & Data (MB) & Waste & CPU util. & Tail idle \\\midrule\endhead']
    for j,row in enumerate(analysis['summary']):
        t='S'+tag(j)
        lines.append(' & '.join(escape(row[k]) for k in ['scenario','model','algorithm'])+f' & \\{t}Bytes & \\{t}Waste & \\{t}Util & \\{t}Tail'+r'\\')
    lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'overhead_table.tex').write_text('\n'.join(lines)+'\n')
    lines=[r'\small',r'\begin{longtable}{llllrrrr}',r'\toprule Cell & Model & Comparator & Method & Raw $p$ & Perm. & Complete pairs & MDE (s)\\\midrule\endhead']
    for j,row in enumerate(analysis['comparisons']):
        t='C'+tag(j)
        method='exact' if row['n']<=16 else 'MC'
        lines.append(' & '.join(escape(row[k]) for k in ['scenario','model','comparator'])+' & '+method+f' & \\{t}RawP & \\{t}Floor & \\{t}CompleteN & \\{t}MDE'+r'\\')
    lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'inference_table.tex').write_text('\n'.join(lines)+'\n')
    lines=[r'\small',r'\begin{longtable}{lllrrrr}',r'\toprule Cell & Model & Comparator & Gain (\%) & CI (s) & Holm $p$ & Paired $d$\\\midrule\endhead']
    for j,row in enumerate(analysis['comparisons']):
        if row['scenario'] in core_cells:continue
        t='C'+tag(j)
        lines.append(' & '.join(escape(row[k]) for k in ['scenario','model','comparator'])+f' & \\{t}Percent & [\\{t}Low, \\{t}High] & \\{t}P & \\{t}D'+r'\\')
    lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'robustness_tables.tex').write_text('\n'.join(lines)+'\n')
    policy_lines=[r'\small',r'\begin{longtable}{lllllllrr}',r'\toprule Policy & Chunk & Link factors & Compute & Prefetch & Recovery & Detector & Share & Cutoff\\\midrule\endhead']
    for j,name in enumerate(sorted(set(r['algorithm'] for r in raw))):
        p=definitions[name]
        values['Policy'+tag(j)+'Share']=format(p.sigma,'.3g')
        values['Policy'+tag(j)+'Cutoff']=format(p.prefetch_cutoff,'.3g')
        link='both' if p.link and p.rssi_weight and p.rtt_weight else ('RSSI' if p.link and p.rssi_weight else ('RTT' if p.link and p.rtt_weight else 'none'))
        policy_lines.append(' & '.join(map(escape,[name,p.chunk,link,('not used' if p.chunk in ['static','fixed','guided'] else ('EWMA' if p.compute_weight else 'equal')),p.prefetch,p.recovery,p.detector]))+f' & \\Policy{tag(j)}Share & \\Policy{tag(j)}Cutoff'+r'\\')
    policy_lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'policy_table.tex').write_text('\n'.join(policy_lines)+'\n')
    (OUT/'numbers.tex').write_text(latex_macros(values))
    combined=[(j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']=='combined' and r['comparator']=='Compute-shrink']
    j,r=combined[0];t='C'+tag(j)
    abstract=f'In the combined cell, improvement over the matched compute-only scheduler is \\{t}Percent\\% (paired restricted-time difference \\{t}Delta~s, interval [\\{t}Low, \\{t}High]~s, global Holm $p=\\{t}P$). '
    j,r=next((j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']=='combined' and r['comparator']=='Proposed-noCutoff')
    t='C'+tag(j)
    abstract+=f'The cutoff does not improve that cell: signed improvement relative to continued prefetch is \\{t}Percent\\% (difference interval [\\{t}Low, \\{t}High]~s, global Holm $p=\\{t}P$). '
    for name in ['Proposed','Compute-shrink']:
        j,row=next((j,r) for j,r in enumerate(analysis['summary']) if r['scenario']=='combined' and r['algorithm']==name)
        if name=='Proposed':a_macro='S'+tag(j)+'Completion'
        else:b_macro='S'+tag(j)+'Completion'
    abstract+=f'Completion fractions are \\{a_macro} and \\{b_macro}, respectively; the gain is restricted to the common horizon. '
    (OUT/'abstract_findings.tex').write_text(abstract+'\n')
    # Mechanism-switch and parameter provenance stays machine-readable as well.
    from dataclasses import asdict
    (OUT/'policies.json').write_text(json.dumps({name:asdict(definitions[name]) for name in sorted(set(r['algorithm'] for r in raw))},indent=2)+'\n')


    paragraphs=[]
    for cell in ['tuned_uniform','tuned_weak_links','tuned_churn','tuned_combined']:
        for comparator in ['Tuned-fixed','Tuned-weighted']:
            j,row=next((j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']==cell and r['comparator']==comparator)
            t='C'+tag(j)
            verdict='meets' if row['practical_win'] else 'does not meet'
            paragraphs.append(escape(cell.replace('tuned_','').replace('_',' ').capitalize())+' versus '+escape(comparator)+f': improvement \\{t}Percent\\% (difference interval [\\{t}Low, \\{t}High]~s; global Holm $p=\\{t}P$), which '+verdict+' the stated win rule.')
    (OUT/'tuned_findings.tex').write_text('\n\n'.join(paragraphs)+'\n')
    fig,axes=plt.subplots(2,2,figsize=(12,6),layout='constrained')
    for ax,cell in zip(axes.ravel(),['tuned_uniform','tuned_weak_links','tuned_churn','tuned_combined']):
        rows=comparisons[comparisons.scenario==cell].set_index('comparator').reindex(['Tuned-fixed','Tuned-weighted'])
        ax.errorbar(rows.difference_s,[0,1],xerr=np.vstack([rows.difference_s-rows.ci_low,rows.ci_high-rows.difference_s]),fmt='o',capsize=3)
        ax.axvline(0,color='grey');ax.set_yticks([0,1],rows.index);ax.set_title(cell.replace('tuned_','').replace('_',' '));ax.set_xlabel('Baseline − proposed restricted time (s)')
    save(fig,'tuned_baselines')
    # The calibrated headline is reported even if it weakens the original nominated comparison.
    j,row=next((j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']=='tuned_combined' and r['comparator']=='Tuned-fixed')
    t='C'+tag(j)
    extra=f'Against the calibration-selected fixed-size baseline on fresh seeds, combined-cell improvement is \\{t}Percent\\% (difference interval [\\{t}Low, \\{t}High]~s; global Holm $p=\\{t}P$). '
    j,row=next((j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']=='combined' and r['comparator']=='Proposed-noCutoff')
    t='C'+tag(j)
    extra+=f'The nominal combined-cell ablation does not support the cutoff: signed improvement over continued prefetch is \\{t}Percent\\% (difference interval [\\{t}Low, \\{t}High]~s; global Holm $p=\\{t}P$). '
    j,row=next((j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']=='combined' and r['comparator']=='Proposed-allPrefetch')
    t='C'+tag(j)
    extra+=f'Stationary-only prefetch also loses to unrestricted prefetch in that nominal cell: signed improvement \\{t}Percent\\% (difference interval [\\{t}Low, \\{t}High]~s; global Holm $p=\\{t}P$). '
    (OUT/'abstract_findings.tex').write_text(extra+'\n')
    (OUT/'calibration_selection.json').write_text(json.dumps(json.loads((ROOT/'results/calibration/selection.json').read_text()),indent=2)+'\n')

    interaction_lines=[r'\small',r'\begin{longtable}{llrrrr}',r'\toprule Cell & Model & Interaction (s) & CI (s) & Holm $p$ & Paired $d$\\\midrule\endhead']
    for j,row in enumerate(analysis['interactions']):
        t='Interaction'+tag(j)
        for field,suffix,fmt in [('difference_s','Delta','.2f'),('ci_low','Low','.2f'),('ci_high','High','.2f'),('p_holm_global','P','.4f')]:
            values[t+suffix]=format(row[field],fmt)
        values[t+'D']='NA' if row['paired_d'] is None else f"{row['paired_d']:.3f}"
        interaction_lines.append(escape(row['scenario'])+' & '+escape(row['model'])+f' & \\{t}Delta & [\\{t}Low, \\{t}High] & \\{t}P & \\{t}D'+r'\\')
        ledger.append(dict(claim=row['label']+' in '+row['scenario']+', '+row['model'],macro_prefix=t,source='paper/analysis.json:interactions['+str(j)+']',externally_validated=False))
    interaction_lines += [r'\bottomrule\end{longtable}\normalsize']
    (OUT/'interaction_table.tex').write_text('\n'.join(interaction_lines)+'\n')
    (OUT/'numbers.tex').write_text(latex_macros(values))
    (OUT/'CLAIM_SOURCES.json').write_text(json.dumps(ledger,indent=2)+'\n')
    # Generate a neutral findings paragraph, without choosing a favorable subset.
    paragraphs=[]
    for cell in core_cells:
        selected=[(j,r) for j,r in enumerate(analysis['comparisons']) if r['scenario']==cell and r['comparator']=='Compute-shrink']
        for j,r in selected:
            t='C'+tag(j)
            verdict='meets the stated statistical and practical win rule' if r['practical_win'] else 'does not meet the stated statistical and practical win rule'
            paragraphs.append(escape(cell)+f': relative to the matched compute-only scheduler, the policy changes restricted makespan by \\{t}Percent\\% (baseline minus candidate \\{t}Delta~s; paired interval [\\{t}Low, \\{t}High]~s; global Holm $p=\\{t}P$), and '+verdict+'.')
    (OUT/'findings.tex').write_text('\n\n'.join(paragraphs)+'\n')
    (OUT/'summary.md').write_text('# Exploratory simulation results\n\n'+'```\n'+summary.to_string(index=False)+'\n```'+'\n')
    print('Generated figures, all summary tables, joint inference and claim ledger')

def save(fig,name):
    fig.savefig(OUT/(name+'.pdf'),bbox_inches='tight')
    fig.savefig(OUT/(name+'.svg'),bbox_inches='tight')
    plt.close(fig)

if __name__=='__main__':build()
