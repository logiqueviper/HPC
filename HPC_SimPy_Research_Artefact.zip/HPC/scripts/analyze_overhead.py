"""One inference framework, paired seed effects, simultaneous intervals/TOST."""
import sys,json
from pathlib import Path
import pandas as pd
import numpy as np
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from hpcsim.coherent_inference import paired_relative
def analyze(raw):
 df=pd.DataFrame(raw)
 if df.duplicated(['scenario','seed','algorithm']).any():raise ValueError('Duplicate runs')
 pairs=[]
 for cell,g in df.groupby('scenario',sort=True):
  if not all(x.world_hash.nunique()==1 for _,x in g.groupby('seed')):raise ValueError('Unpaired worlds')
  a=g[g.algorithm=='Proposed'].sort_values('seed')
  for name,b in g[g.algorithm!='Proposed'].groupby('algorithm',sort=True):
   b=b.sort_values('seed')
   if list(a.seed)!=list(b.seed):raise ValueError('Missing paired seeds')
   pairs.append((cell,name,a,b))
 # Direct amortization contrast: retuned fixed chunks versus single-task dispatch.
 for cell,g in df[df.scenario.str.startswith('dispatch_')].groupby('scenario',sort=True):
  a=g[g.algorithm=='Tuned-fixed'].sort_values('seed');b=g[g.algorithm=='Fixed-one'].sort_values('seed')
  assert list(a.seed)==list(b.seed)
  pairs.append((cell,'Fixed-one',a,b))
 results=[]
 for cell,name,a,b in pairs:
  stats=paired_relative(a.makespan,b.makespan,len(pairs))
  results.append(dict(scenario=cell,comparator=name,candidate=str(a.algorithm.iloc[0]),candidate_completion=float(a.completed.mean()),baseline_completion=float(b.completed.mean()),**stats))
 summary=[]
 for (cell,name),g in df.groupby(['scenario','algorithm'],sort=True):
  summary.append(dict(scenario=cell,algorithm=name,n=len(g),completion=float(g.completed.mean()),mean_time=float(g.makespan.mean()),prefetch_mean=float(g.prefetch_chunks.mean()),dynamic_prefetch_mean=float(g.dynamic_prefetch_chunks.mean()),dispatch_mean=float(g.dispatch_requests.mean()),service_seconds_mean=float(g.dispatch_service_seconds.mean()),coordinator_occupancy_mean=float((g.dispatch_service_seconds/g.makespan).mean()),control_requested_mb_mean=float(g.control_requested_mb.mean()),data_mean=float(g.transferred_mb.mean()),waste_mean=float(g.wasted_compute_cost.mean()),rtt_active_samples_mean=float(g.rtt_factor_active_samples.mean())))
 activation=[]
 for cell,g in df.groupby('scenario'):
  if cell.startswith('dispatch_'):continue
  a=g[g.algorithm=='Proposed'].set_index('seed').sort_index()
  row=dict(scenario=cell,eligible_rtt_active_samples=int(a.rtt_factor_active_samples.iloc[0]),proposed_prefetch_mean=float(a.prefetch_chunks.mean()),proposed_dynamic_prefetch_mean=float(a.dynamic_prefetch_chunks.mean()))
  for name,key in [('Proposed-noRSSI','rssi_allocation_changes'),('Proposed-noRTT','rtt_allocation_changes'),('Proposed-allPrefetch','allprefetch_allocation_changes')]:
   b=g[g.algorithm==name].set_index('seed').sort_index();row[key]=int((a.allocation_hash!=b.allocation_hash).sum())
   if name=='Proposed-allPrefetch':row['allworker_dynamic_prefetch_mean']=float(b.dynamic_prefetch_chunks.mean())
  activation.append(row)
 return dict(comparisons=results,summary=summary,activation=activation,contrast_count=len(pairs),joint_hypothesis_count=2*len(pairs),family='All mean-relative difference and +/-1 percentage-point equivalence hypotheses',method='Paired seed-level Student t approximation; joint Bonferroni correction; simultaneous difference intervals and adjusted TOST')
if __name__=='__main__':
 out=root/'results/overhead_study';a=analyze(json.loads((out/'raw.json').read_text()));(out/'analysis.json').write_text(json.dumps(a,indent=2)+'\n');print('Analyzed',a['contrast_count'],'contrasts and',a['joint_hypothesis_count'],'joint hypotheses')
