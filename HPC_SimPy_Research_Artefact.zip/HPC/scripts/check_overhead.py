import sys,json,re,hashlib
from pathlib import Path
import pandas as pd
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from scripts.analyze_overhead import analyze
p=root/'paper';out=root/'results/overhead_study';raw=json.loads((out/'raw.json').read_text());a=json.loads((out/'analysis.json').read_text());assert a==analyze(raw)
df=pd.DataFrame(raw);protocol=json.loads((out/'protocol.json').read_text())
assert protocol['source_sha256']==hashlib.sha256((root/'hpcsim/model.py').read_bytes()).hexdigest()
assert not set(protocol['tuning_seeds'])&set(df.seed)
for r in a['comparisons']:
 assert r['difference_significant']==(r['simultaneous_ci_low']>0 or r['simultaneous_ci_high']<0)
 assert r['equivalent']==(r['tost_p_adjusted']<.05)
assert (df.duplicate_acceptances==0).all()
full=df[df.algorithm=='Proposed'];assert (full.dynamic_prefetch_chunks==0).all()
assert (full.max_prefetch_completion<.75).all()
# Mechanism interventions actually exercise their intended inputs.
activation={r['scenario']:r for r in a['activation']}
assert activation['independent_rtt']['eligible_rtt_active_samples']>0
assert activation['independent_rtt']['rtt_allocation_changes']>0
assert activation['continuous_rssi']['rssi_allocation_changes']>0
assert activation['prefetch_departure']['allworker_dynamic_prefetch_mean']>0
# Cost sweeps reuse the same physical world and account for explicit cost.
for _,g in df[df.scenario.str.startswith('dispatch_')].groupby('seed'):assert g.world_hash.nunique()==1
assert (df.dispatch_service_seconds>=0).all()
for _,g in df[df.dispatch_ms==0].groupby('scenario'):assert (g.dispatch_service_seconds==0).all()
macros=dict(re.findall(r'\\newcommand\{\\([A-Za-z]+)\}\{([^}]+)\}',(p/'overhead_numbers.tex').read_text()))
for j,r in enumerate(a['comparisons']):
 tag=chr(65+j//26)+chr(65+j%26)
 for key,suffix in [('gain_pct','Gain'),('simultaneous_ci_low','Low'),('simultaneous_ci_high','High'),('p_adjusted','P'),('tost_p_adjusted','EqP')]:
  expected=(r'$<0.0001$' if r[key]<.0001 else f'{r[key]:.4f}') if suffix in ['P','EqP'] else f'{r[key]:.2f}'
  assert macros['O'+tag+suffix]==expected
text=(p/'mechanism_study_ieee.tex').read_text()
for phrase in ['earlier assumed-channel results','task(s)','supplied synopsis','journal acceptance','prespecified']:
 assert phrase not in text
print('PASS:',len(raw),'runs;',a['contrast_count'],'coherent contrasts; activation, cost accounting, pairing and claim macros')
