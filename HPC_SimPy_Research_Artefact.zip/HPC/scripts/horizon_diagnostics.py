"""Fresh paired weak-link diagnostics across identical-world horizon extensions."""
import sys,json,subprocess,time
from pathlib import Path
from dataclasses import replace,asdict
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario,POLICIES,generate_world,Simulation
from hpcsim.analysis import summarize
subprocess.run([sys.executable,'-m','unittest','discover','-s','tests'],check=True)
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--output',default='results/horizon')
args=parser.parse_args()
out=Path(args.output)
if (out/'raw.json').exists():raise SystemExit('Preserve existing horizon diagnostics')
out.mkdir(parents=True,exist_ok=True)
rows=[];settings=[];start=__import__('time').monotonic()
for q in [.5,.75]:
 base=Scenario(name=f'horizon_q{int(q*100)}',tasks=120,workers=6,horizon=4000,uniform_links=True,weak_fraction=q,dynamic_fraction=.5)
 for horizon in [4000,8000,16000]:
  s=replace(base,horizon=horizon)
  settings.append(asdict(s)|{'name':s.name+f'_h{horizon}'})
  for seed in range(2500,2510):
   w=generate_world(s,seed)
   for name in ['Compute-shrink','Proposed','Proposed-hysteresis']:
    r=Simulation(w,POLICIES[name]).run()
    r['scenario']=s.name+f'_h{horizon}'
    rows.append(r)
  print(q,horizon,len(rows),'runs',round(__import__('time').monotonic()-start,1),'s',flush=True)
(out/'raw.json').write_text(json.dumps(rows,indent=2)+'\n')
(out/'analysis.json').write_text(json.dumps(summarize(rows),indent=2)+'\n')
(out/'config.json').write_text(json.dumps(settings,indent=2)+'\n')
print('Saved administrative horizon diagnostics',flush=True)
