"""Audit primary manuscript claims against retained run records."""
import sys,json,re
from pathlib import Path
import numpy as np
import pandas as pd
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from hpcsim.analysis import summarize,paired_statistics,holm
p=root/'paper';raw=json.loads((root/'results/calibrated_core/raw.json').read_text());stored=json.loads((p/'mechanism_analysis.json').read_text());expected=summarize(raw);df=pd.DataFrame(raw);rng=np.random.default_rng(57103)
for cell in ['uniform','weak_links','churn','combined']:
 a=df[(df.scenario==cell)&(df.algorithm=='Compute-shrink')].sort_values('seed');b=df[(df.scenario==cell)&(df.algorithm=='Compute-retainExpired')].sort_values('seed')
 expected['comparisons'].append(dict(scenario=cell,model='ns3_extended',candidate='Compute-shrink',comparator='Compute-retainExpired',**paired_statistics(a.makespan,b.makespan,rng)))
for r,q in zip(expected['comparisons'],holm([r['p_raw'] for r in expected['comparisons']])):
 r['p_holm_global']=float(q);r['practical_win']=bool(q<.05 and r['improvement_pct']>=1)
expected['family_count']=len(expected['comparisons']);expected['multiplicity_family']='All recalibrated core full-policy contrasts plus four matched compute recovery interventions'
assert expected==stored,'Analysis differs from raw records'
macros=dict(re.findall(r'\\newcommand\{\\([A-Za-z]+)\}\{([^}]+)\}',(p/'mechanism_numbers.tex').read_text()))
ledger=json.loads((p/'mechanism_numeric_sources.json').read_text())['macros'];assert macros==ledger
for j,r in enumerate(stored['comparisons']):
 tag=chr(65+j//26)+chr(65+j%26)
 for k,suffix,fmt in [('improvement_pct','Gain','.2f'),('difference_s','Difference','.2f'),('ci_low','Low','.2f'),('ci_high','High','.2f'),('p_holm_global','P','.4f')]:assert macros['M'+tag+suffix]==format(r[k],fmt)
assert not df.duplicated(['scenario','seed','algorithm','model']).any()
assert all(g.world_hash.nunique()==1 for _,g in df.groupby(['scenario','seed']))
protocol=json.loads((root/'results/calibrated_core/protocol.json').read_text());assert not set(protocol['calibration_seeds'])&set(protocol['evaluation_seeds'])
for policy in protocol['policies']:
 if policy['name'] not in ['Proposed-retainExpired','Compute-retainExpired']:assert policy['recovery']=='fenced' and policy['cancel_expired_transfers']
proposed=df[df.algorithm=='Proposed'];assert (proposed.dynamic_prefetch_chunks==0).all();assert (proposed.max_prefetch_completion<.75).all();assert (df.duplicate_acceptances==0).all()
text=(p/'mechanism_study_ieee.tex').read_text()
for phrase in ['supplied synopsis','requested participation','journal acceptance','local HPC','prespecified','preregistered threshold']:assert phrase not in text.lower()
for filename in ['mechanism_abstract.tex','mechanism_results.tex','mechanism_calibration.tex','mechanism_all_comparisons.tex','mechanism_completion.tex']:
 for m in re.findall(r'\\((?:M|N)[A-Z]{2}[A-Za-z]+)',(p/filename).read_text()):assert m in macros
print(f'PASS: {len(raw)} primary runs, {len(stored["comparisons"])} joint comparisons, common worlds/recovery, all generated claim macros')
