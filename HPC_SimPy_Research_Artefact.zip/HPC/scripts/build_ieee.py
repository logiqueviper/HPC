"""Render the same audited study using standard IEEEtran journal layout."""
from pathlib import Path
import re
root=Path(__file__).resolve().parents[1];p=root/'paper'
s=(p/'manuscript.tex').read_text()
s=s.replace(r'\input{revision_diagnostics.tex}',(p/'revision_diagnostics.tex').read_text())
s=s.replace(r'\documentclass[11pt]{article}',r'\documentclass[journal]{IEEEtran}')
abstract=r'''\begin{abstract}
We evaluate shrinking compute- and link-aware chunks, stationary-only prefetch, a completion cutoff, and fenced task recovery in heterogeneous wireless clusters. A reproducible SimPy reconstruction combines paired benchmarks, mechanism ablations, calibrated simple comparators, a restricted HEFT comparator, and censoring diagnostics. An independent ns-3 radio diagnostic supplies a bounded alternative mapping. \input{revision_abstract.tex} The results support a study of conditional benefits and mechanism failures. Physical mobile scheduling, faithful close mobile-framework comparison, and full-text novelty verification remain outstanding.
\end{abstract}'''
s=re.sub(r'\\begin\{abstract\}.*?\\end\{abstract\}',lambda _:abstract,s,flags=re.S)
s=s.replace(r'\usepackage[margin=25mm]{geometry}','')
s=s.replace(r'\usepackage{lmodern}','')
s=s.replace(r'\author{Anand Kanade\\Department of Computer Science and Engineering\\Walchand College of Engineering, Sangli, India}',r'\author{Anand Kanade\thanks{Author identity and affiliation are reproduced from the supplied synopsis. Corresponding-author details, coauthors, consent, funding and conflict declarations require confirmation before submission.}\thanks{Department of Computer Science and Engineering, Walchand College of Engineering, Sangli, India.}}')
s=s.replace(r'\date{Research draft: evidence and venue checks remain outstanding}','')
s=s.replace(r'\noindent\textbf{Keywords:}',r'\begin{IEEEkeywords}')
s=s.replace('reproducible simulation.','reproducible simulation.\n'+r'\end{IEEEkeywords}',1)
s=s.replace(r'width=\linewidth',r'width=\textwidth')
s=s.replace(r'width=\textwidth',r'width=\textwidth,height=.43\textheight,keepaspectratio')
s=s.replace(r'\operatorname{RSSI}_i(t)=P_0-10n\log_{10}\!\left(\frac{d_i(t)}{d_0}\right)-L_{\rm wall}\mathbf{1}_{\rm wall}+\eta_i(t)-\Delta_i(t).',r'\begin{aligned}\operatorname{RSSI}_i(t)={}&P_0-10n\log_{10}\!\left(\frac{d_i(t)}{d_0}\right)\\&-L_{\rm wall}\mathbf{1}_{\rm wall}+\eta_i(t)-\Delta_i(t).\end{aligned}')
s=s.replace(r'\begin{figure}[htbp]',r'\begin{figure*}[!t]').replace(r'\end{figure}',r'\end{figure*}')

s=s.replace(r'\clearpage'+ '\n'+r'\input{comparison_tables.tex}',r'Complete comparison tables appear in the supplementary material; all original comparisons, including negative results, are retained.')
s=s.replace(r'\bibliographystyle{plain}',r'\bibliographystyle{IEEEtran}')
(p/'manuscript_ieee.tex').write_text(s)
print('Generated IEEEtran journal source')
