"""Current paper: coherent tables, crossover and mechanism activation graphics."""
import sys,json,unittest
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
root=Path(__file__).resolve().parents[1];sys.path.insert(0,str(root))
from scripts.analyze_overhead import analyze
p=root/'paper';out=root/'results/overhead_study';raw=json.loads((out/'raw.json').read_text());a=analyze(raw);(out/'analysis.json').write_text(json.dumps(a,indent=2)+'\n');protocol=json.loads((out/'protocol.json').read_text());df=pd.DataFrame(raw)
radio=json.loads((root/'results/ns3_extended/report.json').read_text())
values={'RadioRunCount':str(radio['radio_runs_total']),'ExtendedMAE':f"{radio['holdout_goodput_mae_mbps']:.3f}",'CurrentRuns':str(len(raw)),'CurrentTuningRuns':str(len(json.loads((out/'calibration.json').read_text()))),'CurrentSeeds':'300','SweepSeeds':'200','CurrentContrastCount':str(a['contrast_count']),'CurrentHypotheses':str(a['joint_hypothesis_count']),'CurrentTests':str(unittest.defaultTestLoader.discover(str(root/'tests')).countTestCases())}
def tag(j):return chr(65+j//26)+chr(65+j%26)
def escape(s):return s.replace('_',r'\_')
def display(s):return s.replace('core_','').replace('_',' ').replace('rtt','RTT').replace('rssi','RSSI')
def claim(cell,base,candidate='Proposed'):
 j,r=next((j,r) for j,r in enumerate(a['comparisons']) if r['scenario']==cell and r['comparator']==base and r['candidate']==candidate);return 'O'+tag(j),r
for j,r in enumerate(a['comparisons']):
 for key,suffix in [('gain_pct','Gain'),('simultaneous_ci_low','Low'),('simultaneous_ci_high','High'),('p_adjusted','P'),('tost_p_adjusted','EqP')]:values['O'+tag(j)+suffix]=(r'$<0.0001$' if r[key]<.0001 else f'{r[key]:.4f}') if suffix in ['P','EqP'] else f'{r[key]:.2f}'
for j,r in enumerate(a['summary']):
 values['Q'+tag(j)+'Completion']=f"{r['completion']:.3f}"
values['CurrentMinCompletion']=f"{min(r['completion'] for r in a['summary']):.3f}"
core=['core_uniform','core_weak_links','core_churn','core_combined'];active=['independent_rtt','continuous_rssi','prefetch_departure'];sweeps=[f'dispatch_{c}' for c in [0,1,10,100,1000,5000,20000]]
lines=[r'\begin{table*}[!t]\centering\caption{Primary contrasts against a calibration-selected fixed-size comparator. Gain is mean paired relative improvement; intervals are simultaneous. Equivalence uses adjusted TOST with a $\pm1\%$ margin.}\small',r'\begin{tabular}{llrrrrr}\toprule Scenario & Fixed tasks & Gain (\%) & Simultaneous CI (\%) & Difference $p$ & Equivalence $p$ & Complete\\\midrule']
for c in core+active:
 t,r=claim(c,'Tuned-fixed');lines.append(display(c)+f" & {protocol['selected_sizes'][c]} & \\{t}Gain & [\\{t}Low, \\{t}High] & \\{t}P & \\{t}EqP & {r['candidate_completion']:.3f}/{r['baseline_completion']:.3f}"+r'\\')
lines += [r'\bottomrule\end{tabular}\end{table*}']
lines += [r'\subsection{Strong-Comparator Results}',r'All \CurrentRuns{} evaluation runs complete, including the highest dispatch-cost setting. The current comparisons therefore do not derive their effects from horizon censoring.',r'Table I leads with the separately tuned comparator. Compute-only contrasts are retained in the supplement; an advantage over compute-only shrinking does not establish an advantage over single-task or retuned fixed-size dispatch.']
for group,label in [(core,'Core'),(active,'Activation')]:
 winners=[display(c) for c in group if claim(c,'Tuned-fixed')[1]['practical_win']]
 losses=[display(c) for c in group if claim(c,'Tuned-fixed')[1]['p_adjusted']<.05 and claim(c,'Tuned-fixed')[1]['gain_pct']<0]
 equival=[display(c) for c in group if claim(c,'Tuned-fixed')[1]['equivalent']]
 lines.append(label+' scenarios: '+('the full policy meets the practical-win rule in '+', '.join(winners)+'. ' if winners else 'the full policy has no practical win over the tuned comparator. ')+('It is slower in '+', '.join(losses)+'. ' if losses else '')+('Equivalence within the stated margin is supported in '+', '.join(equival)+'.' if equival else 'No equivalence conclusion follows without an adjusted TOST rejection.'))
lines += [r'\subsection{Dispatch-Cost Crossover}',r'Fixed-size calibration is repeated independently at every service cost. Table II and Fig.~\ref{fig:crossover} separate a comparison with single-task dispatch from the stronger retuned comparator. The crossover refers to the tested grid; it is not an interpolated universal threshold.',r'\begin{table*}[!t]\centering\caption{Cost sweep. The control budget is fixed at 64 kB per allocation. Service costs are unmeasured assumptions.}\small',r'\begin{tabular}{rrrrrr}\toprule Service (ms) & Selected tasks & Full versus single (\%) & Simultaneous CI (\%) & Full versus tuned (\%) & Tuned versus single (\%)\\\midrule']
for c in sweeps:
 t,r=claim(c,'Fixed-one');u,_=claim(c,'Tuned-fixed');v,_=claim(c,'Fixed-one','Tuned-fixed');lines.append(c.split('_')[1]+f" & {protocol['selected_sizes'][c]} & \\{t}Gain & [\\{t}Low, \\{t}High] & \\{u}Gain & \\{v}Gain"+r'\\')
lines += [r'\bottomrule\end{tabular}\end{table*}']
win_cost=[int(c.split('_')[1]) for c in sweeps if claim(c,'Fixed-one')[1]['practical_win']]
if win_cost:
 first=min(win_cost);previous=max([v for v in [0,1,10,100,1000,5000,20000] if v<first],default=0)
 lines.append(f'The first tested cost with an adjusted practical win over single-task dispatch is {first} ms; the preceding grid point is {previous} ms. This brackets an observed transition on the chosen workload, not a physical deployment threshold.')
else:lines.append('No tested service cost establishes an adjusted practical win of the full policy over single-task dispatch. Larger tuned chunks may still amortize service cost.')
batch_win_cost=[int(c.split('_')[1]) for c in sweeps if claim(c,'Fixed-one','Tuned-fixed')[1]['practical_win']]
if batch_win_cost:
 first=min(batch_win_cost);previous=max([v for v in [0,1,10,100,1000,5000,20000] if v<first],default=0)
 lines.append(f'The retuned fixed policy first meets the adjusted practical-win criterion over single-task dispatch at {first} ms, following {previous} ms on the tested grid. This direct contrast tests amortization without crediting the full policy with its effect.')
t,r=claim('dispatch_5000','Tuned-fixed');u,z=claim('dispatch_20000','Tuned-fixed')
lines.append(f'At 5000 ms, the full policy improves over retuned fixed chunks by \\{t}Gain\\% (simultaneous interval [\\{t}Low, \\{t}High]\\%). At 20000 ms its signed gain against retuned chunks is \\{u}Gain\\%. A large advantage over single-task dispatch at that point is therefore an amortization result, not superiority over tuned batching.')
lines += [r'\subsection{Mechanism Activation}',r'\input{overhead_activation_table.tex}',r'Exact sampled identities, active allocation changes, equivalence, and inconclusive effects are distinct. A mechanism may alter allocation without changing the critical completion path; a non-significant difference alone is not evidence of equivalence.']
t,r=claim('independent_rtt','Proposed-noRTT')
lines.append(f'The independent-delay intervention changes allocations in all 300 worlds, yet the full-versus-no-RTT gain is \\{t}Gain\\% (simultaneous interval [\\{t}Low, \\{t}High]\\%). Equivalence within the declared margin is supported. Activation of the clipped scaling regime does not establish useful delay-based ranking.')
t,r=claim('continuous_rssi','Proposed-noRSSI')
lines.append(f'Continuous eligible-link variation changes allocations in all 300 worlds without eligibility crossings. Its full-versus-no-RSSI gain is \\{t}Gain\\%, with equivalence supported. This separates an active continuous factor from a practically demonstrated benefit. Exact RTT and all-worker identities in this stationary cell reflect their inactive conditions.')
t,r=claim('prefetch_departure','Proposed-noPrefetch');u,_=claim('prefetch_departure','Proposed-noCutoff');v,z=claim('prefetch_departure','Proposed-allPrefetch')
lines.append(f'In the compute-heavy departure cell, prefetch has signed gain \\{t}Gain\\% against no prefetch, while the cutoff gains \\{u}Gain\\% against no cutoff. Thus prefetch hurts overall despite a useful cutoff in this cell. The stationary restriction changes allocations in all 300 worlds and suppresses dynamic prefetch, but its gain of \\{v}Gain\\% has simultaneous interval [\\{v}Low, \\{v}High]\\%; neither a practical win nor equivalence is established. All mechanism contrasts, including no-prefetch, remain visible in Fig.~\\ref{{fig:mechanisms}} and the supplement.')
(p/'overhead_results.tex').write_text('\n\n'.join(lines)+'\n')
actlines=[r'\begin{table*}[!t]\centering\caption{Activation audit over 300 worlds per cell. Allocation changes compare full-policy assignment hashes with ablations. Dynamic-prefetch counts directly exercise the stationary restriction.}\small',r'\begin{tabular}{lrrrr}\toprule Scenario & No-RSSI changed worlds & No-RTT changed worlds & Full dynamic prefetch & All-worker dynamic prefetch\\\midrule']
for r in a['activation']:
 actlines.append(display(r['scenario'])+f" & {r['rssi_allocation_changes']} & {r['rtt_allocation_changes']} & {r['proposed_dynamic_prefetch_mean']:.2f} & {r['allworker_dynamic_prefetch_mean']:.2f}"+r'\\')
actlines += [r'\bottomrule\end{tabular}\end{table*}'];(p/'overhead_activation_table.tex').write_text('\n'.join(actlines)+'\n')
# Abstract focuses on strong comparator and cost dependence; no weak headline.
first_core=claim('core_combined','Tuned-fixed')[0];values['CoreCombinedGain']=f"{claim('core_combined','Tuned-fixed')[1]['gain_pct']:.2f}"
abstract=r'All scenarios use a calibrated stationary radio lookup and common corrected recovery. In the combined zero-service-cost scenario, the full policy has signed gain \CoreCombinedGain{}\% against separately tuned fixed-size dispatch. '
abstract+=('The first tested service cost with a practical win over single-task dispatch is '+str(min(win_cost))+' ms. ') if win_cost else 'No tested cost establishes a practical win of the full policy over single-task dispatch. '
t,_=claim('dispatch_5000','Tuned-fixed');u,_=claim('dispatch_20000','Tuned-fixed')
abstract+=f"Against retuned fixed chunks, signed gains are \\{t}Gain\\% at 5000 ms and \\{u}Gain\\% at 20000 ms. "
abstract+='Comparisons with a retuned comparator, independent-delay and useful-link activation cells, and equivalence tests limit the interpretation of these effects.'
(p/'overhead_abstract.tex').write_text(abstract+'\n')
(p/'overhead_numbers.tex').write_text(''.join('\\newcommand{\\'+k+'}{'+v+'}\n' for k,v in values.items()))
full=[r'\small\begin{longtable}{lllrrrr}\toprule Cell & Candidate & Comparator & Mean gain (\%) & Simultaneous CI (\%) & Difference $p$ & TOST $p$\\\midrule\endhead']
for j,r in enumerate(a['comparisons']):
 t='O'+tag(j);full.append(display(r['scenario'])+' & '+escape(r['candidate'])+' & '+escape(r['comparator'])+f' & \\{t}Gain & [\\{t}Low, \\{t}High] & \\{t}P & \\{t}EqP'+r'\\')
full += [r'\bottomrule\end{longtable}\normalsize'];(p/'overhead_all_comparisons.tex').write_text('\n'.join(full)+'\n')
settings=[r'\begin{longtable}{llrrr}\toprule Cell & Type & Seeds & Service (ms) & Control (kB)\\\midrule\endhead']
for e in protocol['entries']:settings.append(display(e['name'])+' & '+e['kind']+f" & {len(e['seeds'])} & {e['dispatch_ms']} & {e['control_kb']}"+r'\\')
settings += [r'\bottomrule\end{longtable}',r'Per-cell fixed-size candidates: 1,2,3,4,8,16,32. Calibration seeds: 5000--5019. All evaluation seeds are disjoint from calibration. The full machine-readable protocol and per-run counters are in results/overhead\_study/protocol.json and raw.json.']
(p/'overhead_settings.tex').write_text('\n'.join(settings)+'\n')
resources=[r'\small\begin{longtable}{llrrrrr}\toprule Cell & Policy & Dispatches & Prefetch & Dynamic PF & Data (MB) & Wasted compute\\\midrule\endhead']
for r in a['summary']:
 resources.append(display(r['scenario'])+' & '+escape(r['algorithm'])+f" & {r['dispatch_mean']:.1f} & {r['prefetch_mean']:.1f} & {r['dynamic_prefetch_mean']:.1f} & {r['data_mean']:.1f} & {r['waste_mean']:.1f}"+r'\\')
resources += [r'\bottomrule\end{longtable}\normalsize']
(p/'overhead_resources.tex').write_text('\n'.join(resources)+'\n')
plt.rcParams.update({'font.size':12,'pdf.fonttype':42,'svg.fonttype':'none','axes.spines.top':False,'axes.spines.right':False})
def save(fig,name):
 for ext in ['pdf','svg']:fig.savefig(p/(name+'.'+ext))
 plt.close(fig)
# Primary figure: cost amortization and retuning, not a duplicate zero-cost forest.
fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
for name,label in [('Fixed-one','Single task'),('Tuned-fixed','Retuned fixed'),('Proposed','Full policy'),('Compute-shrink','Compute shrinking')]:
 ys=[df[(df.scenario==c)&(df.algorithm==name)].makespan.mean() for c in sweeps];axes[0].plot([0,1,10,100,1000,5000,20000],ys,'o-',label=label)
axes[0].set_xscale('symlog',linthresh=1);axes[0].set_xlabel('Serialized service per dispatch (ms)');axes[0].set_ylabel('Mean completion time (s)');axes[0].legend(fontsize=9)
for name,label in [('Fixed-one','versus single task'),('Tuned-fixed','versus retuned fixed')]:
 rs=[claim(c,name)[1] for c in sweeps];d=np.array([r['gain_pct'] for r in rs]);lo=np.array([r['simultaneous_ci_low'] for r in rs]);hi=np.array([r['simultaneous_ci_high'] for r in rs]);axes[1].errorbar([0,1,10,100,1000,5000,20000],d,yerr=[d-lo,hi-d],fmt='o-',capsize=3,label=label)
axes[1].set_xscale('symlog',linthresh=1);axes[1].axhline(0,color='gray',lw=1);axes[1].set_xlabel('Serialized service per dispatch (ms)');axes[1].set_ylabel('Full mean paired gain (%)');axes[1].legend(fontsize=9);save(fig,'overhead_crossover')
variants=['Proposed-noRSSI','Proposed-noRTT','Proposed-noPrefetch','Proposed-allPrefetch','Proposed-noCutoff'];cells=core+active;heat=np.array([[claim(c,b)[1]['gain_pct'] for c in cells] for b in variants]);fig,ax=plt.subplots(figsize=(10,5),layout='constrained');bound=max(1,np.abs(heat).max());im=ax.imshow(heat,cmap='RdBu',vmin=-bound,vmax=bound,aspect='auto');ax.set_xticks(range(len(cells)),[display(c) for c in cells],rotation=30,ha='right');ax.set_yticks(range(5),['No RSSI','No RTT','No prefetch','All-worker prefetch','No cutoff'])
for i in range(5):
 for j in range(len(cells)):ax.text(j,i,f'{heat[i,j]:.2f}',ha='center',va='center',fontsize=10)
fig.colorbar(im,ax=ax,label='Full mean paired gain (%)');save(fig,'overhead_mechanisms')
# Calibration grid is descriptive and independent from evaluation.
cal=pd.DataFrame(json.loads((out/'calibration.json').read_text()))
grid=[1,2,3,4,8,16,32];means=np.array([[cal[(cal.scenario==c)&(cal.algorithm==f'Fixed-{k}')].makespan.mean() for k in grid] for c in sweeps]);regret=100*(means/means.min(axis=1)[:,None]-1)
fig,ax=plt.subplots(figsize=(9,4),layout='constrained');im=ax.imshow(regret,cmap='viridis',aspect='auto');ax.set_xticks(range(7),grid);ax.set_yticks(range(7),[c.split('_')[1] for c in sweeps]);ax.set_xlabel('Fixed tasks per chunk');ax.set_ylabel('Service per dispatch (ms)')
for i in range(7):
 for j in range(7):ax.text(j,i,f'{regret[i,j]:.1f}',ha='center',va='center',fontsize=9,color='white' if regret[i,j]<regret.max()/2 else 'black')
fig.colorbar(im,ax=ax,label='Calibration mean excess over grid minimum (%)');save(fig,'overhead_tuning_grid')
# Explain amortization through allocation count and coordinator occupancy.
fig,axes=plt.subplots(1,2,figsize=(10,4),layout='constrained')
for name,label in [('Fixed-one','Single task'),('Tuned-fixed','Retuned fixed'),('Proposed','Full policy'),('Compute-shrink','Compute shrinking')]:
 groups=[df[(df.scenario==c)&(df.algorithm==name)] for c in sweeps]
 axes[0].plot([0,1,10,100,1000,5000,20000],[g.dispatch_requests.mean() for g in groups],'o-',label=label)
 axes[1].plot([0,1,10,100,1000,5000,20000],[100*(g.dispatch_service_seconds/g.makespan).mean() for g in groups],'o-',label=label)
for ax in axes:ax.set_xscale('symlog',linthresh=1);ax.set_xlabel('Serialized service per dispatch (ms)')
axes[0].set_ylabel('Mean allocation requests');axes[1].set_ylabel('Mean coordinator occupancy (%)');axes[0].legend(fontsize=9)
save(fig,'overhead_service_audit')
# Dense distributions belong to supplementary material.
fig,axes=plt.subplots(3,3,figsize=(10,8),layout='constrained')
for i,c in enumerate(active):
 for j,b in enumerate(['Tuned-fixed','Proposed-noRTT','Proposed-allPrefetch']):
  x=df[(df.scenario==c)&(df.algorithm=='Proposed')].sort_values('seed');y=df[(df.scenario==c)&(df.algorithm==b)].sort_values('seed');d=np.sort(100*(y.makespan.to_numpy()-x.makespan.to_numpy())/y.makespan.to_numpy());ax=axes[i,j];ax.step(d,np.arange(1,len(d)+1)/len(d),where='post');ax.axvline(0,color='gray',lw=1);ax.axvspan(-1,1,color='gray',alpha=.1);ax.set_title(display(c)+'\n'+b,fontsize=10);ax.set_xlabel('Paired relative gain (%)',fontsize=10)
  if j==0:ax.set_ylabel('Empirical fraction')
save(fig,'overhead_supplement_ecdf')
print(json.dumps({'runs':len(raw),'contrasts':a['contrast_count'],'hypotheses':a['joint_hypothesis_count'],'first_tested_win_cost_ms':min(win_cost) if win_cost else None,'minimum_completion':values['CurrentMinCompletion']},indent=2))
