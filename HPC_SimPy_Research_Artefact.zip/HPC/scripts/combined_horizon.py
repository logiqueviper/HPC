"""Post-hoc horizon sensitivity on original combined worlds; not new evidence seeds."""
import sys,json,hashlib,argparse
from pathlib import Path
from dataclasses import replace,asdict
from concurrent.futures import ProcessPoolExecutor
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario,POLICIES,generate_world,Simulation
from hpcsim.analysis import paired_statistics,holm
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
def execute(seed):
    s=Scenario(name='combined',tasks=240,workers=8,horizon=16000,uniform_links=True,weak_fraction=.5,dynamic_fraction=.5,slowdown_probability=.5,dip_seconds=40)
    w=generate_world(s,seed)
    return [Simulation(w,POLICIES[n]).run() for n in ['B2','B4-F','Compute-shrink','Proposed','Proposed-noRSSI','Proposed-noRTT','Proposed-allPrefetch','Proposed-noCutoff']]
if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(ROOT/'results/combined_horizon'));args=parser.parse_args()
    out=Path(args.output);out.mkdir(parents=True,exist_ok=True)
    if (out/'raw.json').exists():raise SystemExit('Refuse to overwrite retained data')
    rows=[]
    with ProcessPoolExecutor(max_workers=3) as p:
        for i,batch in enumerate(p.map(execute,range(2000,2050))):
            rows.extend(batch)
            if (i+1)%10==0:print(i+1,'/50 worlds',flush=True)
    (out/'raw.json').write_text(json.dumps(rows,indent=2)+'\n')
    original=json.loads((ROOT/'results/core/raw.json').read_text()); comparisons=[];rng=np.random.default_rng(20261003)
    for h,data in [(4000,[r for r in original if r['scenario']=='combined']),(16000,rows)]:
        a=sorted([r for r in data if r['algorithm']=='Proposed'],key=lambda r:r['seed'])
        for name in ['B2','B4-F','Compute-shrink','Proposed-noRSSI','Proposed-noRTT','Proposed-allPrefetch','Proposed-noCutoff']:
            b=sorted([r for r in data if r['algorithm']==name],key=lambda r:r['seed'])
            comparisons.append(dict(horizon=h,baseline=name,proposed_completion=sum(r['completed'] for r in a)/50,baseline_completion=sum(r['completed'] for r in b)/50,**paired_statistics([r['makespan'] for r in a],[r['makespan'] for r in b],rng)))
    for r,p in zip(comparisons,holm([r['p_raw'] for r in comparisons])):r['p_holm_diagnostic_family']=float(p)
    (out/'analysis.json').write_text(json.dumps(dict(status='post-hoc repeated original seeds; 14-comparison diagnostic family, separate from original claims',comparisons=comparisons),indent=2)+'\n')
    (out/'provenance.json').write_text(json.dumps(dict(seeds=list(range(2000,2050)),source_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),horizons=[4000,16000],note='Horizon excluded from physical RNG identity; retains same scenario name and every seed'),indent=2)+'\n')
