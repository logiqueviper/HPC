"""Exploratory calibration only on 1000--1019, fresh evaluation on 2400--2449."""
import json,sys,subprocess,time,hashlib
from pathlib import Path
from dataclasses import replace,asdict
import numpy as np
import pandas as pd
import yaml
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario,Simulation,generate_world,POLICIES
from hpcsim.analysis import summarize,macro_values,latex_macros
subprocess.run([sys.executable,'-m','unittest','discover','-s','tests'],check=True)
import argparse
parser=argparse.ArgumentParser()
parser.add_argument('--output',default='results/calibration')
args=parser.parse_args()
out=Path(args.output)
if (out/'evaluation.json').exists():raise SystemExit('Existing calibration/evaluation retained; choose another run directory')
out.mkdir(parents=True,exist_ok=True)
entries=yaml.safe_load(Path('configs/core.yaml').read_text())['scenarios']
scenarios=[Scenario(**e) for e in entries]
fixed=[replace(POLICIES['B2'],name=f'Fixed-{k}',fixed=k) for k in [1,2,4,8,16]]
weighted=[replace(POLICIES['B4-F'],name=f'Weighted-{share}',sigma=share) for share in [.1,.2,.3,.5,.7]]
rows=[];start=time.monotonic()
for s in scenarios:
 for seed in range(1000,1020):
  w=generate_world(s,seed)
  for p in fixed+weighted:rows.append(Simulation(w,p).run())
 print('Calibrated',s.name,len(rows),'runs',round(time.monotonic()-start,1),'s',flush=True)
df=pd.DataFrame(rows)
selected={}
regrets=[]
for family,candidates in [('fixed',fixed),('weighted',weighted)]:
 names=[p.name for p in candidates]
 means=df[df.algorithm.isin(names)].groupby(['scenario','algorithm']).makespan.mean().unstack()
 relative=means.div(means.min(axis=1),axis=0)-1
 scores=relative.max(axis=0)
 choice=min(names,key=lambda name:(scores[name],means[name].mean(),name))
 selected[family]=next(p for p in candidates if p.name==choice)
 for name in names:regrets.append(dict(family=family,algorithm=name,worst_mean_relative_regret=float(scores[name]),cell_mean=means[name].to_dict()))
 print('Selected',family,choice,'worst regret',float(scores[choice]),flush=True)
Path(out/'raw.json').write_text(json.dumps(rows,indent=2)+'\n')
Path(out/'selection.json').write_text(json.dumps(dict(rule='Within-family minimum worst cell mean relative regret; ties by overall mean, then name',selected={k:asdict(p) for k,p in selected.items()},grid=regrets,calibration_seeds=list(range(1000,1020)),evaluation_seeds=list(range(2400,2450)),label='post-hoc / exploratory (v2)'),indent=2)+'\n')
evaluation=[]
for original in scenarios:
 s=replace(original,name='tuned_'+original.name)
 for seed in range(2400,2450):
  w=generate_world(s,seed)
  for p in [POLICIES['Proposed'],replace(selected['fixed'],name='Tuned-fixed'),replace(selected['weighted'],name='Tuned-weighted')]:
   evaluation.append(Simulation(w,p).run())
 print('Evaluated',s.name,len(evaluation),'runs',round(time.monotonic()-start,1),'s',flush=True)
analysis=summarize(evaluation)
(out/'evaluation.json').write_text(json.dumps(evaluation,indent=2)+'\n')
(out/'analysis.json').write_text(json.dumps(analysis,indent=2)+'\n')
(out/'config.json').write_text(json.dumps([asdict(s) for s in scenarios],indent=2)+'\n')
print('Completed calibration and untouched-seed evaluation',flush=True)
