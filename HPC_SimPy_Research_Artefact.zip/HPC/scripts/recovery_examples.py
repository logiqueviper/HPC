"""Constructed late-result diagnostics, not a measured hardware experiment."""
import json
import subprocess
import sys
from pathlib import Path
from dataclasses import replace
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario, Policy, Simulation, generate_world
subprocess.run([sys.executable,'-m','unittest','discover','-s','tests'],check=True)
s=Scenario(name='constructed-late-return',tasks=60,workers=2,horizon=1200,uniform_links=True,dynamic_fraction=0)
rows=[]
for return_time in [20,40,80]:
    base=generate_world(s,2200)
    reach=np.ones_like(base.reachable);reach[5:return_time,0]=False
    w=replace(base,costs=np.full(60,10.),inputs_mb=np.full(60,.01),speed=np.ones_like(base.speed),base_speed=np.ones(2),reachable=reach)
    p=Policy('Naive-timeout',chunk='fixed',fixed=10,link=False,prefetch='none',recovery='timeout',timeout=8,dedup=False,detector='none')
    for policy in [p,replace(p,name='Idempotent-timeout',dedup=True),replace(p,name='Fenced-immediate',recovery='fenced',grace=0,dedup=True),replace(p,name='Fenced-grace',recovery='fenced',grace=20,dedup=True)]:
        r=Simulation(w,policy).run();r['return_time']=return_time;rows.append(r)
Path('results/recovery_examples.json').write_text(json.dumps(rows,indent=2)+'\n')
for r in rows:print(r['return_time'],r['algorithm'],'accepted duplicates',r['duplicate_acceptances'],'rejected',r['rejected_results'],'compute repeated',r['duplicate_compute'])
