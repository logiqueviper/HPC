#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [[ "${1:-}" != "--legacy" ]]; then
  if [[ "${1:-}" == "--fresh" ]]; then
    echo "Use scripts/overhead_study.py --output with a new directory for a primary simulation rerun; default rebuild uses retained data." >&2
    exit 2
  fi
  exec bash scripts/reproduce_overhead.sh
fi
shift
python3 -m unittest discover -s tests -v
if [[ "${1:-}" == "--fresh" ]]; then
  run_dir="results/reproduction-$(date -u +%Y%m%dT%H%M%S)"
  mkdir -p "$run_dir"
  python3 -m hpcsim.run --config configs/core.yaml --output "$run_dir/core"
  python3 -m hpcsim.run --config configs/sensitivity.yaml --output "$run_dir/sensitivity"
  python3 scripts/calibrate_baselines.py --output "$run_dir/calibration"
  python3 scripts/horizon_diagnostics.py --output "$run_dir/horizon"
  python3 scripts/heft_benchmark.py --output "$run_dir/heft"
  python3 scripts/combined_horizon.py --output "$run_dir/combined_horizon"
  python3 scripts/ns3_sensitivity.py --output "$run_dir/ns3_sensitivity"
  python3 - "$run_dir" <<'PY'
import json,sys
from pathlib import Path
base=Path(sys.argv[1])
for name in ['core','sensitivity']:
    original=json.loads((Path('results')/name/'raw.json').read_text())
    fresh=json.loads((base/name/'raw.json').read_text())
    if original != fresh: raise SystemExit('Fresh run differs: '+name)
for name,filename in [('calibration','evaluation.json'),('horizon','raw.json')]:
    original=json.loads((Path('results')/name/filename).read_text())
    fresh=json.loads((base/name/filename).read_text())
    if original != fresh: raise SystemExit('Fresh supplemental run differs: '+name)
for filename in ['raw.json','selection.json']:
    original=json.loads((Path('results/calibration')/filename).read_text())
    fresh=json.loads((base/'calibration'/filename).read_text())
    if original != fresh: raise SystemExit('Fresh calibration differs: '+filename)
for name in ['heft','combined_horizon','ns3_sensitivity']:
    original=json.loads((Path('results')/name/'raw.json').read_text())
    fresh=json.loads((base/name/'raw.json').read_text())
    if original != fresh: raise SystemExit('Fresh revision batch differs: '+name)
print('Fresh raw simulations and calibration exactly match the retained batches')
PY
fi
python3 scripts/generate_paper.py
python3 scripts/generate_revision.py
python3 paper/check_numbers.py
bash scripts/build_ieee.sh
cd paper
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex > build-pass1.log
bibtex manuscript > build-bibliography.log
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex > build-pass2.log
pdflatex -interaction=nonstopmode -halt-on-error manuscript.tex > build-pass3.log
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex > supplement-pass1.log 2>&1
pdflatex -interaction=nonstopmode -halt-on-error supplement.tex > supplement-pass2.log 2>&1
printf '%s\n' 'Generated paper/manuscript.pdf and paper/supplement.pdf'
