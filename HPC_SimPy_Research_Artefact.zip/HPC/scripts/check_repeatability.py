"""Repeat one Proposed run per physical scenario/model, including horizon diagnostics."""
import json,sys
from pathlib import Path
from dataclasses import replace
import yaml
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario,POLICIES,generate_world,Simulation
root=Path(__file__).resolve().parents[1]
settings={}
for batch in ['core','sensitivity']:
 cfg=yaml.safe_load((root/'results'/batch/'config.yaml').read_text())
 for entry in cfg['scenarios']:
  s=Scenario(**entry);settings[s.name]=s
for entry in json.loads((root/'results/calibration/config.json').read_text()):
 s=Scenario(**entry);s=replace(s,name='tuned_'+s.name);settings[s.name]=s
for entry in json.loads((root/'results/horizon/config.json').read_text()):
 label=entry['name'];entry=dict(entry);entry['name']=label.rsplit('_h',1)[0]
 settings[label]=Scenario(**entry)
raw=json.loads((root/'paper/raw-combined.json').read_text())
seen=set();count=0
for row in raw:
 key=(row['scenario'],row['model'])
 if row['algorithm']!='Proposed' or key in seen:continue
 seen.add(key)
 fresh=Simulation(generate_world(settings[row['scenario']],row['seed']),POLICIES['Proposed'],row['model']).run()
 fresh['scenario']=row['scenario']
 if fresh!=row:
  bad=[k for k in row if fresh.get(k)!=row[k]]
  raise SystemExit(f'Repeatability mismatch in {key}: {bad}')
 count+=1
 print('Exact repeatability',key,flush=True)
(root/'paper/repeatability.json').write_text(json.dumps(dict(checked_runs=count,scope='one Proposed run per scenario/model; not a full repeat of all evaluation runs',exact_match=True),indent=2)+'\n')
