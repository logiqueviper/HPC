"""Post-hoc stationary-world comparator; original seeds, separate Holm family."""
import sys,json,yaml,argparse
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hpcsim.model import Scenario,generate_world,Simulation,POLICIES
from hpcsim.analysis import paired_statistics,holm
import numpy as np
root=Path(__file__).resolve().parents[1];parser=argparse.ArgumentParser();parser.add_argument('--output',default=str(root/'results/heft'));args=parser.parse_args();out=Path(args.output)
out.mkdir(parents=True,exist_ok=True)
if (out/'raw.json').exists():raise SystemExit('Refuse to overwrite retained data')
raw=[];comparisons=[];original=json.loads((root/'results/core/raw.json').read_text());rng=np.random.default_rng(30303)
for name,q in [('uniform',0),('weak_links',.5)]:
    rows=[]
    for seed in range(2000,2050):
        s=Scenario(**next(e for e in yaml.safe_load((root/'results/core/config.yaml').read_text())['scenarios'] if e['name']==name))
        rows.append(Simulation(generate_world(s,seed),POLICIES['HEFT-independent']).run())
    a=sorted([r for r in original if r['scenario']==name and r['algorithm']=='Proposed'],key=lambda r:r['seed'])
    if any(x['world_hash']!=y['world_hash'] for x,y in zip(a,rows)):raise ValueError('Comparator worlds differ')
    comparisons.append(dict(scenario=name,baseline='HEFT-independent',proposed_completion=sum(r['completed'] for r in a)/50,baseline_completion=sum(r['completed'] for r in rows)/50,**paired_statistics([r['makespan'] for r in a],[r['makespan'] for r in rows],rng)))
    raw.extend(rows);print(name,'done',flush=True)
for c,p in zip(comparisons,holm([c['p_raw'] for c in comparisons])):c['p_holm_diagnostic_family']=float(p)
(out/'raw.json').write_text(json.dumps(raw,indent=2)+'\n');(out/'analysis.json').write_text(json.dumps(dict(scope='HEFT independent-DAG CPU ranking/EFT core, oracle nominal initial speeds; fluid-radio execution adaptation; no mobile-system reproduction; two-comparison post-hoc family',comparisons=comparisons),indent=2)+'\n')
