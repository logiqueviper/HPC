# Current revision status

PUBLICATION_REVISION.md supersedes the checklist below where ns-3 diagnostics,
reference metadata, IEEE formatting and GitHub delivery have since been added.
Physical validation, a faithful mobile competitor, full-text novelty assessment,
author declarations and Zenodo deposition remain outstanding.

# Outstanding requirements before submission

## External requirements

1. **External validity:** obtain a small measured wireless trace or ns-3 comparison, then a repeated small scheduler testbed if possible. There is no physical device fleet in this cloud workspace. The SimPy gate is not external validation.
2. **Prior-art and references:** verify MAESTRO, CROWDio, Honeybee, Forseti and scheduling references against authoritative metadata and review the actual papers. Network requests to Crossref, CTAN and the journal site returned proxy 403. Necessary domain additions were saved as an environment draft; draft saving does not activate runtime access. Use environment settings to apply the network changes before retrying. No bibliography verification is claimed.
3. **Venue formatting:** the current manuscript uses standard article layout. The official Elsevier/JPDC template is not installed and CTAN/journal downloads were denied. No unverified page limit is assumed. Template transfer is outstanding.
4. **Authors and archive:** confirm author list, affiliations, corresponding-author contact, consent, declarations and code/data license. The synopsis identifies Anand Kanade but does not establish coauthorship. A public code/data archive and DOI have not been created; no deposition or submission is authorized implicitly by this local manuscript work.
5. **Original study reproduction:** supply the original simulator, frozen config, hypotheses, raw results and LaTeX if the original 15-hypothesis study must be corrected. Its original claims cannot be validated by this new reconstruction.

## Scientific strengthening still needed

- Wider calibration/parameter sweeps if stronger optimality claims are made. The artefact now includes a calibration-only grid and fresh tuned-baseline evaluation; no global optimum is asserted.
- Faithfully reproduce at least one close published wireless/crowd-aware policy or justify the exclusion from inspected methods. The adapted speculative policy is not LATE or Dolly.
- Broader longer-horizon coverage if claims extend to other channel models or cells. The reconstruction now includes matched-world 1x/2x/4x horizon diagnostics for two weak-link fractions; it does not establish infinite livelock or diagnose the missing original study.
- Full interactions beyond the tested link-by-prefetch factorial; additional worker scaling and mobility models if claimed as general results. A paired two-mechanism add-one-in/interaction analysis is included.
- Cutoff sensitivity must use a recorded calibration protocol. The requested 75% setting is not claimed optimal and may worsen outcomes.
- Station-level MAC coupling, measured retransmission/backoff, realistic probe and session overhead, and dry-run initialization for a physical prototype.
- Detector effectiveness is deliberately outside the new main contribution. The ADWIN code and synthetic diagnostic do not establish an end-to-end detector gain.

The current paper is an honest simulation research draft, not a completed revision of every original A–E requirement and not a submission-ready journal paper. No result or wording can eliminate the possibility of journal rejection.
