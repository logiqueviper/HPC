# Benchmark design and reviewer expectations

This is a new exploratory SimPy study of the user's mechanism combination. It does not reproduce the original paper or establish a unique invention. The target venue is provisionally Journal of Parallel and Distributed Computing; current author instructions and reference metadata require verification.

## Proposed policy

A single wired coordinator tracks independent task IDs and accepts each task once. Physically stationary workers may hold one active chunk and one prefetched chunk. Mobile workers receive no prefetch. New prefetch stops when accepted unique tasks / total tasks reaches 0.75; existing reservations finish normally. Completed tasks, rather than assigned tasks, determine this cutoff.

Chunk size is the ceiling of sigma times unassigned task count times measured compute-speed share times clipped RSSI and RTT factors, with a minimum of one task. Compute speed is learned only from compute duration, excluding transfer and CPU-queue wait. The coordinator starts from equal estimates; a real implementation should use a separate dry-run sample and account for its overhead. A task is indivisible: shrinking chunks cannot split a single very long tail task.

Three consecutive unhealthy probes enter grace. Valid work remains reserved until bounded grace expires. Expiry invalidates the session, requeues only unaccepted IDs, and rejects stale-session results. A low RSSI is an unhealthy observation, not proof a worker has walked out; dips, interference and departure must be distinguished operationally through the recovery policy. RTT and RSSI are correlated in the default model; an independent-delay scenario and separate ablations test whether both terms add information.

## Minimum useful competitors

| Competitor | Why compare | Implementation status |
| --- | --- | --- |
| Static equal allocation | Demonstrates heterogeneity and tail imbalance | Implemented B1 |
| Fixed-size dynamic pull | Strong simple baseline; avoids overselling a sophisticated policy | Nominal B2 plus calibration-selected Tuned-fixed on untouched evaluation seeds |
| Guided self-scheduling | Existing remaining-work shrinking concept | Implemented B3 |
| Compute-weighted shrinking | Existing heterogeneous chunking concept | Implemented B4-F and matched Compute-shrink |
| Matched compute-only baseline | Isolates link weighting and prefetch with the same sigma and recovery | Implemented Compute-shrink |
| RSSI-only / RTT-only ablations | Tests redundancy and marginal information | Implemented Proposed-noRTT / Proposed-noRSSI |
| Constant-share ablation | Isolates decreasing remaining work | Implemented Proposed-noShrink |
| No prefetch / unrestricted prefetch | Isolates overlap and stationary-only eligibility | Implemented Proposed-noPrefetch / Proposed-allPrefetch |
| No cutoff | Tests the user's 75% cutoff directly | Implemented Proposed-noCutoff |
| Speculative copy | Tests the cost of redundancy on a shared channel | Implemented adapted whole-chunk copy; not a faithful LATE implementation |
| MAESTRO, CROWDio, Honeybee-Tx/DR | Close systems-level prior work and novelty context | No faithful reimplementation; papers/artefacts required |
| Adaptive work stealing; LB4OMP / MPI self-scheduling | Additional scheduling families | Related-work context; centralized adaptations cannot be labelled their original implementations |

Do not benchmark against Spark, Kubernetes or BOINC merely because they are familiar: their orchestration and workload assumptions confound this small independent-task system. Do not call the nominal simulated chunk rules complete implementations of their original runtimes.

## Scenario logic

- Uniform strong links, no mobility: detect gratuitous complexity, and measure whether prefetch helps without claiming wireless-aware gains.
- Weak-link heterogeneity without departures: isolate conditional link weighting and admission flapping.
- Churn with strong links: isolate recovery and the cost of prefetch to mobile nodes.
- Combined heterogeneity, weak links, churn and slowdown: measure interactions; do not report this alone.
- Alternative contention rules: determine whether conclusions depend on equal-airtime allocation, throughput-fair anomaly behaviour, or explicit overhead/loss assumptions.
- Heavy-tailed costs with independent input sizes and larger results: test whether proportional input-cost assumptions drive the findings.
- Added RTT independent of RSSI: test whether the RTT factor adds information beyond signal strength.

Use calibration-only seeds for any later parameter selection. The nominal configs are fixed exploratory settings, not a timestamped preregistration. A separate baseline calibration and untouched-seed evaluation are now included. The main and robustness seed families are disjoint. No evaluation result should be used to optimize the cutoff.

## Metrics and plots

Primary: common-horizon mean min(completion time, horizon), paired improvement, paired bootstrap CI, and family-adjusted two-sided sign-flip p. Completion rate must appear beside every restricted-time result. Restricted means do not estimate full completion time beyond the horizon. Retain completed-pair analysis only as a sensitivity.

Secondary: CPU utilization; tail CPU-idle worker-seconds after 75% unique acceptance (including disconnected workers); bytes actually transferred; repeated compute cost; duplicate input volume requested; rejected stale results; accepted duplicate outputs; recovery requeues; actual prefetch count and eligibility. Duplicate input requested is not a measurement of duplicate airtime. Active transfer busy time is a fluid-channel metric, not measured Wi-Fi airtime.

Figures: paired difference forest plot against all main baselines; completion-rate panel; mechanism-effect heatmap with an explicit improvement sign; tail-idle and transfer-cost panels; completion-time survival curves including censored runs; robustness plot across contention models. Use vector PDF/SVG and readable labels. Show negative and practically negligible effects.

## Least-effort route to stronger evidence

1. Reproduce the SimPy gate, fixed exploratory experiment configs, analysis and PDF with one command.
2. Calibrate the throughput/RSSI mapping and RTT from a few laptops on one access point using iperf3 and ping. These measurements test the radio model, not the scheduler itself.
3. Run a small real scheduler harness on four heterogeneous computers. Use deterministic independent CPU jobs or Blender frames, the three strongest observed simulated policies, repeated identical job lists, per-task logs and monotonic clocks. Repeat batches and report uncertainty, rather than assuming that successful simulation predicts physical Wi-Fi.
4. If hardware is unavailable, validate against ns-3 or a properly licensed measured trace. Explicitly state the absence of measured scheduler validation as a main limitation.
5. Compare novelty against the actual close systems papers, verify citations and venue guidance, then finalize the manuscript and public artefact archive.

No cloud simulation can manufacture a physical testbed, an archival DOI, author approval, or guaranteed journal acceptance. These are remaining requirements, not hidden completed steps.
