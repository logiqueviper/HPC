"""Exploratory SimPy reconstruction. Not the original paper artefact."""
from dataclasses import dataclass, asdict, replace
import hashlib
import json
import math
from functools import lru_cache
from pathlib import Path
import numpy as np
import simpy
from river.drift import ADWIN
from hpcsim.heft import independent_heft


@dataclass(frozen=True)
class Scenario:
    name: str = 'mixed'
    tasks: int = 800
    workers: int = 12
    heterogeneity: float = 4.0
    rho: float = 0.3
    cost_cv: float = 0.3
    result_ratio: float = 0.1
    dynamic_fraction: float = 0.5
    weak_fraction: float = 0.0
    uniform_links: bool = False
    slowdown_probability: float = 0.0
    path_loss_exponent: float = 3.0
    reference_dbm: float = -40.0
    reference_distance_m: float = 1.0
    wall_loss_db: float = 12.0
    shadow_sd: float = 3.0
    horizon: float = 6000.0
    workload: str = 'lognormal'
    independent_inputs: bool = False
    mobility: str = 'walk'
    dip_seconds: float = 20.0
    extra_rtt_ms: float = 0.0


def table_rate(rssi):
    # Intermediate knots are reconstruction assumptions, not recovered data.
    return np.interp(rssi, [-85, -80, -70, -60, -50], [0, 2, 10, 25, 40])


def round_trip_ms(rssi):
    return 3.0 + 2.0 * np.exp(np.clip((-np.asarray(rssi)-55)/6, -30, 30))

@lru_cache(maxsize=1)
def ns3_knots():
    return np.array(json.loads((Path(__file__).resolve().parents[1]/'results/ns3/report.json').read_text())['knots'])

def calibrated_ns3_rate(rssi):
    knots=ns3_knots()
    if np.any(np.asarray(rssi)<knots[0,0]) or np.any(np.asarray(rssi)>knots[-1,0]):
        raise ValueError('RSSI outside ns-3 calibration range; no extrapolation permitted')
    return np.interp(rssi,*knots.T)


def channel_rates(link_rates, model):
    """Rates in Mbps per ACTIVE TRANSFER (not station).

    legacy is equal airtime among transfers; throughput_fair gives each transfer
    1/sum(1/T). efficiency adds explicit, uncalibrated overhead/loss assumptions.
    """
    t = np.asarray(link_rates, dtype=float)
    if len(t) == 0:
        return t
    positive = t > 0
    if not np.all(positive):
        result = np.zeros_like(t)
        result[positive] = channel_rates(t[positive], model)
        return result
    if model == 'legacy':
        return t / len(t)
    if model == 'throughput_fair':
        return np.full(len(t), 1/np.sum(1/t))
    if model == 'efficiency':
        efficiency = 1/(1+0.08*(len(t)-1))
        # RSSI-dependent retries are approximated using the monotone rate proxy.
        delivery = np.clip(t/10, 0.1, 1)
        return t/len(t) * efficiency * delivery
    raise ValueError(model)


@dataclass(frozen=True)
class World:
    scenario: Scenario
    seed: int
    costs: np.ndarray
    inputs_mb: np.ndarray
    base_speed: np.ndarray
    rssi: np.ndarray
    speed: np.ndarray
    reachable: np.ndarray
    permanent: np.ndarray
    positions: np.ndarray
    rtt_ms: np.ndarray

    @property
    def fingerprint(self):
        h = hashlib.sha256(json.dumps(asdict(self.scenario), sort_keys=True).encode())
        h.update(str(self.seed).encode())
        for x in (self.costs, self.inputs_mb, self.base_speed, self.rssi,
                  self.speed, self.reachable, self.permanent, self.positions, self.rtt_ms):
            h.update(x.tobytes())
        return h.hexdigest()


def generate_world(s: Scenario, seed: int):
    if s.tasks < 1 or s.workers < 1 or s.horizon <= 0:
        raise ValueError('Positive task count, worker count and horizon required')
    if s.heterogeneity < 1 or s.cost_cv < 0 or s.rho < 0:
        raise ValueError('Invalid workload parameters')
    for fraction in (s.dynamic_fraction, s.weak_fraction, s.slowdown_probability):
        if not 0 <= fraction <= 1:
            raise ValueError('Fractions must lie in [0,1]')
    physical_identity = asdict(s)
    physical_identity.pop('horizon')  # administrative censoring cannot change the world
    identity = hashlib.sha256(json.dumps(physical_identity, sort_keys=True).encode()).digest()
    rng = np.random.default_rng(np.random.SeedSequence([seed, *np.frombuffer(identity, dtype='<u4')]))
    n, nt = s.workers, math.ceil(s.horizon)+2
    if s.workload == 'lognormal':
        sd = math.sqrt(math.log1p(s.cost_cv**2))
        costs = rng.lognormal(math.log(10)-sd**2/2, sd, s.tasks)
    elif s.workload == 'bimodal':
        costs = rng.choice([2.0, 42.0], s.tasks, p=[0.8, 0.2])
    elif s.workload == 'pareto':
        costs = (rng.pareto(2.5, s.tasks)+1)*6
    else:
        raise ValueError(s.workload)
    inputs = s.rho*5*(rng.lognormal(math.log(10)-0.5, 1, s.tasks)
                       if s.independent_inputs else costs)
    base = np.exp(rng.uniform(0, math.log(s.heterogeneity), n))
    base *= n/base.sum()
    pos = rng.uniform([1, 1], [19, 11], (n, 2))
    rssi = np.empty((nt, n))
    shadow = rng.normal(0, s.shadow_sd, n)
    weak = rng.permutation(n)[:round(n*s.weak_fraction)]
    dynamic = rng.permutation(n)[:round(n*s.dynamic_fraction)]
    permanent = np.ones(n, dtype=bool)
    permanent[dynamic] = False
    initial_pos = pos.copy()
    positions = np.empty((nt, n, 2))
    reachable = np.ones((nt, n), dtype=bool)
    speed = np.broadcast_to(base, (nt, n)).copy()
    dip = np.zeros((nt, n))
    fluid = costs.sum()/n
    for i in dynamic:
        start = int(rng.uniform(0.2, 0.7)*fluid)
        mode = rng.integers(0, 4)
        if mode == 1:
            dip[start:min(nt, start+int(s.dip_seconds)), i] = rng.uniform(15, 25)
        elif mode == 2:
            reachable[start:, i] = False
        elif mode == 3:
            reachable[start:min(nt, start+int(rng.uniform(60, 200))), i] = False
    for i in range(n):
        if rng.random() < s.slowdown_probability:
            start = int(rng.uniform(0, 0.6)*fluid)
            end = min(nt, start+int(rng.uniform(100, 400)))
            speed[start:end, i] *= rng.uniform(0.3, 0.6)
    # Stationary shadowing followed by a reflected bounded random walk.
    for t in range(nt):
        if t:
            shadow = .9*shadow + rng.normal(0, s.shadow_sd*math.sqrt(1-.9**2), n)
            if s.mobility == 'walk':
                theta = rng.uniform(0, 2*math.pi, n)
                pos += .6*np.column_stack([np.cos(theta), np.sin(theta)])
                for axis, limit in ((0, 20), (1, 12)):
                    pos[:, axis] = limit-np.abs((pos[:, axis] % (2*limit))-limit)
            elif s.mobility != 'static':
                raise ValueError(s.mobility)
        pos[permanent] = initial_pos[permanent]
        positions[t] = pos
        distance = np.maximum(np.linalg.norm(pos-[0, 6], axis=1), s.reference_distance_m)
        rssi[t] = (s.reference_dbm-10*s.path_loss_exponent*np.log10(distance/s.reference_distance_m)
                   -s.wall_loss_db*(pos[:, 0]>8)+shadow-dip[t])
        if s.uniform_links:
            rssi[t] = -50-dip[t]
        if len(weak):
            rssi[t, weak] = -79+shadow[weak]-dip[t, weak]
    rtt_ms = round_trip_ms(rssi)+s.extra_rtt_ms
    arrays = (costs, inputs, base, rssi, speed, reachable, permanent, positions, rtt_ms)
    for array in arrays:
        array.setflags(write=False)
    return World(s, seed, *arrays)


@dataclass(frozen=True)
class Policy:
    name: str
    chunk: str = 'shrink'
    sigma: float = .3
    fixed: int = 8
    link: bool = True
    prefetch: str = 'permanent'
    recovery: str = 'fenced'
    grace: float = 20
    timeout: float = 30
    dedup: bool = True
    detector: str = 'adwin'
    hysteresis: bool = False
    healthy_probes: int = 3
    margin_db: float = 3
    hybrid_threshold: float = .25
    prefetch_cutoff: float = .75
    speculative: bool = False
    rssi_weight: bool = True
    rtt_weight: bool = True
    compute_weight: bool = True


FULL = Policy('P-full')
POLICIES = {
    'HEFT-independent': Policy('HEFT-independent', chunk='heft', link=False, prefetch='none', detector='none'),
    'B1': Policy('B1', chunk='static', sigma=.5, link=False, prefetch='none', recovery='timeout', detector='none'),
    'B2': Policy('B2', chunk='fixed', sigma=.5, link=False, prefetch='none', recovery='timeout', detector='none'),
    'B3': Policy('B3', chunk='guided', sigma=.5, link=False, prefetch='none', recovery='timeout', detector='none'),
    'B4': Policy('B4', sigma=.5, link=False, prefetch='none', recovery='timeout', dedup=False, detector='none'),
    'B4-D': Policy('B4-D', sigma=.5, link=False, prefetch='none', recovery='timeout', detector='none'),
    'B4-F': Policy('B4-F', sigma=.5, link=False, prefetch='none', detector='none'),
    'B2-F': Policy('B2-F', chunk='fixed', sigma=.5, link=False, prefetch='none', detector='none'),
    'P-full': FULL,
    'P-noShrink': replace(FULL, name='P-noShrink', chunk='constant'),
    'P-noLink': replace(FULL, name='P-noLink', link=False),
    'P-noPF': replace(FULL, name='P-noPF', prefetch='none'),
    'P-allPF': replace(FULL, name='P-allPF', prefetch='all'),
    'P-noGrace': replace(FULL, name='P-noGrace', grace=0),
    'P-TO': replace(FULL, name='P-TO', recovery='timeout', dedup=False),
    'P-TO-D': replace(FULL, name='P-TO-D', recovery='timeout'),
    'P-noADWIN': replace(FULL, name='P-noADWIN', detector='none'),
    'P-lite': replace(FULL, name='P-lite', detector='none', grace=0),
    'P-hysteresis': replace(FULL, name='P-hysteresis', hysteresis=True, detector='none'),
    'P-hybrid': replace(FULL, name='P-hybrid', chunk='hybrid', detector='none'),
    'Proposed': replace(FULL, name='Proposed', detector='none'),
    'Compute-shrink': replace(FULL, name='Compute-shrink', link=False, prefetch='none', detector='none'),
    'Proposed-noLink': replace(FULL, name='Proposed-noLink', link=False, detector='none'),
    'Proposed-noShrink': replace(FULL, name='Proposed-noShrink', chunk='constant', detector='none'),
    'Proposed-noPrefetch': replace(FULL, name='Proposed-noPrefetch', prefetch='none', detector='none'),
    'Proposed-allPrefetch': replace(FULL, name='Proposed-allPrefetch', prefetch='all', detector='none'),
    'Proposed-noCutoff': replace(FULL, name='Proposed-noCutoff', prefetch_cutoff=1., detector='none'),
    'Proposed-noGrace': replace(FULL, name='Proposed-noGrace', grace=0, detector='none'),
    'Proposed-hysteresis': replace(FULL, name='Proposed-hysteresis', hysteresis=True, detector='none'),
    'Speculative': replace(FULL, name='Speculative', link=False, prefetch='none', speculative=True, detector='none'),
    'Proposed-noRSSI': replace(FULL, name='Proposed-noRSSI', rssi_weight=False, detector='none'),
    'Proposed-noRTT': replace(FULL, name='Proposed-noRTT', rtt_weight=False, detector='none'),
    'Proposed-noCompute': replace(FULL, name='Proposed-noCompute', compute_weight=False, detector='none'),
}


@dataclass
class Transfer:
    worker: int
    remaining: float
    event: object
    rate: float = 0


class Radio:
    def __init__(self, env, world, model):
        self.env, self.world, self.model = env, world, model
        self.active = []
        self.updated = 0.0
        self.changed = env.event()
        self.mb = 0.0
        self.busy_seconds = 0.0
        env.process(self.run())

    def nominal_rate(self, rssi):
        return calibrated_ns3_rate(rssi) if self.model=='ns3_calibrated' else table_rate(rssi)

    def advance(self):
        dt = self.env.now-self.updated
        if any(x.rate>0 for x in self.active):
            self.busy_seconds += dt
        for x in list(self.active):
            sent = min(x.remaining, dt*x.rate/8)
            self.mb += sent
            x.remaining -= sent
            if x.remaining <= 1e-8:
                self.active.remove(x)
                if not x.event.triggered:
                    x.event.succeed()
        self.updated = self.env.now

    def rates(self):
        t = min(int(self.env.now), len(self.world.rssi)-1)
        links = [float(self.nominal_rate(self.world.rssi[t, x.worker]))
                 if self.world.reachable[t, x.worker] else 0 for x in self.active]
        for x, rate in zip(self.active, channel_rates(links, 'legacy' if self.model=='ns3_calibrated' else self.model)):
            x.rate = rate

    def submit(self, worker, mb):
        self.advance()
        event = self.env.event()
        if mb <= 0:
            event.succeed()
            return event
        self.active.append(Transfer(worker, mb, event))
        self.rates()
        if not self.changed.triggered:
            self.changed.succeed()
        return event

    def run(self):
        while True:
            self.advance()
            self.rates()
            self.changed = self.env.event()
            dt = math.floor(self.env.now+1+1e-9)-self.env.now
            for x in self.active:
                if x.rate > 0:
                    dt = min(dt, 8*x.remaining/x.rate)
            yield self.env.any_of([self.env.timeout(max(dt, 1e-8)), self.changed])


class Simulation:
    def __init__(self, world, policy, model='legacy'):
        self.world, self.p, self.model = world, policy, model
        self.env = simpy.Environment()
        self.radio = Radio(self.env, world, model)
        n = world.scenario.workers
        self.pending = set(range(world.scenario.tasks))
        if policy.chunk == 'heft':
            if not np.all(world.permanent):
                raise ValueError('Offline HEFT comparator is restricted to stationary workers')
            self.heft_assignment,self.heft_order,_=independent_heft(world.costs,world.base_speed)
        self.accepted = set()
        self.assignments = {}
        self.next_id = 0
        self.epoch = np.zeros(n, dtype=int)
        self.healthy = np.zeros(n, dtype=bool)
        self.bad = np.zeros(n, dtype=int)
        self.good = np.zeros(n, dtype=int)
        self.grace_start = np.full(n, np.inf)
        self.last_reply = np.zeros(n)
        self.blocked_until = np.zeros(n)
        self.flaps = np.zeros(n, dtype=int)
        self.estimate = np.ones(n)
        self.link_observation = np.full(n, -100.)
        self.rtt_observation = np.full(n, 1000.)
        self.factor = np.ones(n)
        self.cpu = [simpy.Resource(self.env, capacity=1) for _ in range(n)]
        self.progress_remaining = np.zeros(n)
        self.samples = [[] for _ in range(n)]
        self.detectors = [ADWIN(delta=.002) for _ in range(n)]
        self.residuals = [[] for _ in range(n)]
        self.recovery_samples = np.zeros(n, dtype=int)
        self.start_counts = np.zeros(world.scenario.tasks, dtype=int)
        self.input_counts = np.zeros(world.scenario.tasks, dtype=int)
        self.speculated = set()
        self.prefetch_records = []
        self.compute_busy = np.zeros(n)
        self.last_accept_time = 0.
        self.first_tail_time = None
        self.tail_compute_busy_at_start = 0.
        self.counters = dict(duplicate_acceptances=0, duplicate_compute=0., duplicate_input_mb=0.,
                             rejected_results=0, requeues=0, fences=0, detector_triggers=0,
                             compute_cost_executed=0., probes=0, result_mb_sent=0.)
        self.done = self.env.event()
        self.env.process(self.probes())
        self.env.process(self.dispatch())

    def outstanding(self, worker):
        return [a for a in self.assignments.values() if a['worker']==worker and
                not a['finished'] and not a['released']]

    def fence(self, worker):
        current = self.outstanding(worker)
        self.epoch[worker] += 1
        self.flaps[worker] += 1
        if self.p.recovery == 'fenced':
            self.counters['fences'] += 1
        for a in current:
            a['released'] = True
            tasks = set(a['tasks'])-self.accepted
            self.pending.update(tasks)
            self.counters['requeues'] += len(tasks)
        self.healthy[worker] = False
        self.good[worker] = 0
        self.grace_start[worker] = np.inf
        self.bad[worker] = 0
        if self.p.hysteresis:
            self.blocked_until[worker] = self.env.now+min(128, 4*2**min(int(self.flaps[worker]), 5))

    def probes(self):
        while True:
            t = int(self.env.now)
            for i in range(self.world.scenario.workers):
                self.counters['probes'] += 2
                r = self.world.rssi[t, i]
                self.link_observation[i] = r
                self.rtt_observation[i] = self.world.rtt_ms[t, i]
                margin = self.p.margin_db if self.p.hysteresis and self.flaps[i] else 0
                healthy = bool(self.world.reachable[t, i] and r >= -80+margin and self.rtt_observation[i] <= 150)
                # Probe replies are instantaneous observations in this reconstruction.
                if healthy:
                    self.last_reply[i] = self.env.now
                    self.good[i] += 1
                    self.bad[i] = 0
                    if self.env.now >= self.blocked_until[i] and (not self.p.hysteresis or
                            not self.flaps[i] or self.good[i]>=self.p.healthy_probes):
                        self.healthy[i] = True
                        self.grace_start[i] = np.inf
                else:
                    self.good[i] = 0
                    self.bad[i] += 1
                    self.healthy[i] = False
                    if self.p.recovery == 'fenced' and self.bad[i]>=3 and math.isinf(self.grace_start[i]):
                        self.grace_start[i] = self.env.now
                if self.p.recovery == 'timeout':
                    if self.outstanding(i) and self.env.now-self.last_reply[i]>=self.p.timeout:
                        self.fence(i)
                        self.last_reply[i] = self.env.now
                elif self.env.now-self.grace_start[i]>=self.p.grace:
                    self.fence(i)
            yield self.env.timeout(4)

    def chunk_size(self, i):
        r, n = len(self.pending), self.world.scenario.tasks
        if self.p.chunk == 'heft':
            k = 1
        elif self.p.chunk == 'fixed':
            k = self.p.fixed
        elif self.p.chunk == 'static':
            k = math.ceil(n/self.world.scenario.workers)
        elif self.p.chunk == 'guided':
            k = math.ceil(r/max(1, int(self.healthy.sum())))
        else:
            base = n if self.p.chunk=='constant' or (self.p.chunk=='hybrid' and r>self.p.hybrid_threshold*n) else r
            k = self.p.sigma*base*self.estimate[i]/max(1e-9, self.estimate[self.healthy].sum())
            if self.p.link:
                rss = self.link_observation[i]
                if self.p.rssi_weight:
                    k *= np.clip((rss+85)/25, .25, 1)
                if self.p.rtt_weight:
                    k *= np.clip(20/self.rtt_observation[i], .25, 1)
            k *= self.factor[i]
            if self.p.hysteresis:
                k /= 1+self.flaps[i]
        return min(r, max(1, math.ceil(k)))

    def dispatch(self):
        while True:
            eligible = []
            for i in range(self.world.scenario.workers):
                if not self.healthy[i] or not math.isinf(self.grace_start[i]):
                    continue
                outstanding = self.outstanding(i)
                if not outstanding:
                    eligible.append(i)
                elif len(outstanding)==1 and outstanding[0]['phase']=='compute':
                    enabled = self.p.prefetch=='all' or (self.p.prefetch=='permanent' and self.world.permanent[i])
                    enabled = enabled and len(self.accepted)/self.world.scenario.tasks < self.p.prefetch_cutoff
                    k = self.chunk_size(i)
                    volume = sum(self.world.inputs_mb[j] for j in sorted(self.pending)[:k])
                    transfer_time = volume*8/max(.01, float(self.radio.nominal_rate(self.link_observation[i])))
                    if enabled and self.progress_remaining[i]/max(.01, self.estimate[i])>transfer_time+1:
                        eligible.append(i)
            eligible.sort(key=lambda i: (bool(self.outstanding(i)), -self.chunk_size(i), i))
            for i in eligible:
                if self.p.chunk == 'heft':
                    available=[t for t in self.heft_order if t in self.pending and self.heft_assignment[t]==i]
                    if not available:
                        continue
                if not self.pending:
                    if self.p.speculative and not self.outstanding(i):
                        candidates = [a for a in self.assignments.values() if not a['finished'] and
                            not a['released'] and a['worker']!=i and a['phase']=='compute' and
                            a['id'] not in self.speculated and
                            self.env.now-a.get('compute_start', self.env.now) > 1.5*a.get('expected_compute', np.inf)]
                        if candidates:
                            source = min(candidates, key=lambda a: a['compute_start'])
                            tasks = sorted(set(source['tasks'])-self.accepted)
                            self.speculated.add(source['id'])
                            if tasks:
                                a = dict(id=self.next_id, worker=i, tasks=tasks, epoch=int(self.epoch[i]),
                                         finished=False, released=False, phase='input')
                                self.next_id += 1
                                self.assignments[a['id']] = a
                                self.env.process(self.execute(a))
                    break
                tasks = available[:1] if self.p.chunk=='heft' else sorted(self.pending)[:self.chunk_size(i)]
                if self.outstanding(i):
                    self.prefetch_records.append((i, len(self.accepted)/self.world.scenario.tasks))
                self.pending.difference_update(tasks)
                aid = self.next_id
                self.next_id += 1
                a = dict(id=aid, worker=i, tasks=tasks, epoch=int(self.epoch[i]),
                         finished=False, released=False, phase='input')
                self.assignments[aid] = a
                self.env.process(self.execute(a))
            yield self.env.timeout(1)

    def observe_task(self, worker, task, elapsed):
        speed = self.world.costs[task]/max(1e-9, elapsed)
        if self.p.compute_weight:
            self.estimate[worker] = .7*self.estimate[worker]+.3*speed
        if len(self.samples[worker]) < 5:
            self.samples[worker].append(speed)
            return
        if self.p.detector == 'none':
            return
        reference = float(np.median(self.samples[worker]))
        expected = self.world.costs[task]/reference
        residual = float(np.clip((elapsed-expected)/expected, 0, 1))
        history = self.residuals[worker]
        prior_mean = np.mean(history) if history else 0
        history.append(residual)
        self.detectors[worker].update(residual)
        if self.detectors[worker].drift_detected and np.mean(history[-5:])>prior_mean+.1:
            self.factor[worker] = max(.25, self.factor[worker]/2)
            self.counters['detector_triggers'] += 1
            self.residuals[worker] = []
        self.recovery_samples[worker] = self.recovery_samples[worker]+1 if residual<.1 else 0
        if self.recovery_samples[worker]>=3:
            self.factor[worker] = min(1, self.factor[worker]*2)
            self.recovery_samples[worker] = 0

    def accept_result(self, a):
        if self.p.recovery=='fenced' and a['epoch'] != self.epoch[a['worker']]:
            self.counters['rejected_results'] += len(a['tasks'])
            return
        for task in a['tasks']:
            if task in self.accepted:
                if not self.p.dedup:
                    self.counters['duplicate_acceptances'] += 1
            else:
                self.accepted.add(task)
                self.pending.discard(task)
                self.last_accept_time = self.env.now
                if self.first_tail_time is None and len(self.accepted)>=.75*self.world.scenario.tasks:
                    self.first_tail_time = self.env.now
                    self.tail_compute_busy_at_start = self.compute_busy.sum()
        self.last_reply[a['worker']] = self.env.now
        self.grace_start[a['worker']] = np.inf
        if len(self.accepted)==self.world.scenario.tasks and not self.done.triggered:
            self.done.succeed()

    def execute(self, a):
        i = a['worker']
        for task in a['tasks']:
            if self.input_counts[task]:
                self.counters['duplicate_input_mb'] += self.world.inputs_mb[task]
            self.input_counts[task] += 1
        yield self.env.timeout(float(self.world.rtt_ms[int(self.env.now), i])/1000)
        yield self.radio.submit(i, sum(self.world.inputs_mb[a['tasks']]))
        with self.cpu[i].request() as request:
            yield request
            a['phase'] = 'compute'
            a['compute_start'] = self.env.now
            a['expected_compute'] = sum(self.world.costs[a['tasks']])/max(.01, self.estimate[i])
            self.progress_remaining[i] = sum(self.world.costs[a['tasks']])
            for task in a['tasks']:
                duplicate = self.start_counts[task]>0
                self.start_counts[task] += 1
                remaining = float(self.world.costs[task])
                start = self.env.now
                while remaining>1e-9:
                    t = int(self.env.now)
                    speed = self.world.speed[t, i]
                    dt = min(math.floor(self.env.now+1+1e-9)-self.env.now, remaining/speed)
                    yield self.env.timeout(max(dt, 1e-9))
                    self.compute_busy[i] += dt
                    completed = min(remaining, speed*dt)
                    remaining -= completed
                    self.progress_remaining[i] -= completed
                    self.counters['compute_cost_executed'] += completed
                    if duplicate:
                        self.counters['duplicate_compute'] += completed
                self.observe_task(i, task, self.env.now-start)
        a['phase'] = 'output'
        volume = sum(self.world.inputs_mb[a['tasks']])*self.world.scenario.result_ratio
        yield self.radio.submit(i, volume)
        self.counters['result_mb_sent'] += volume
        self.accept_result(a)
        a['finished'] = True

    def run(self):
        horizon = self.world.scenario.horizon
        self.env.run(until=self.env.any_of([self.done, self.env.timeout(horizon)]))
        self.radio.advance()
        return dict(scenario=self.world.scenario.name, seed=self.world.seed, algorithm=self.p.name,
                    model=self.model, world_hash=self.world.fingerprint,
                    makespan=float(self.env.now), horizon=horizon, completed=self.done.triggered,
                    accepted=len(self.accepted), tasks=self.world.scenario.tasks,
                    prefetch_chunks=len(self.prefetch_records),
                    dynamic_prefetch_chunks=sum(not self.world.permanent[i] for i, _ in self.prefetch_records),
                    max_prefetch_completion=max((p for _,p in self.prefetch_records), default=0.),
                    compute_utilization=float(self.compute_busy.sum()/(self.world.scenario.workers*max(1e-9,self.env.now))),
                    tail_idle_worker_seconds=(max(0., self.world.scenario.workers*(self.env.now-self.first_tail_time)
                        -(self.compute_busy.sum()-self.tail_compute_busy_at_start)) if self.first_tail_time is not None else None),
                    wasted_compute_cost=max(0., self.counters['compute_cost_executed']-float(self.world.costs[list(self.accepted)].sum())),
                    transferred_mb=self.radio.mb, airtime_busy_seconds=self.radio.busy_seconds,
                    **{k: float(v) for k, v in self.counters.items()})
