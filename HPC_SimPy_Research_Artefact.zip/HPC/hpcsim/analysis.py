"""Paired, horizon-restricted analysis for the reconstruction pilot."""
import itertools
import math
import numpy as np
import pandas as pd


def holm(pvalues):
    p = np.asarray(pvalues, dtype=float)
    order = np.argsort(p, kind='stable')
    adjusted = np.empty(len(p))
    prior = 0.
    for j, index in enumerate(order):
        prior = max(prior, (len(p)-j)*p[index])
        adjusted[index] = min(1, prior)
    return adjusted


def paired_statistics(a, b, rng):
    """Improvement A vs B = 100*(mean(B)-mean(A))/mean(B)."""
    a, b = np.asarray(a), np.asarray(b)
    delta = b-a
    n = len(delta)
    if not n:
        return dict(n=0, improvement_pct=None, difference_s=None, ci_low=None,
                    ci_high=None, paired_d=None, p_raw=None, permutation_count=0,
                    test_method='unavailable')
    bootstrap = delta[rng.integers(0, n, (5000, n))].mean(axis=1)
    lo, hi = np.quantile(bootstrap, [.025, .975])
    if n<=16:
        signs = np.array(list(itertools.product([-1., 1.], repeat=n)))
        distribution = (signs@delta)/n
        p = float(np.mean(np.abs(distribution)>=abs(delta.mean())-1e-10))
        method = 'exact two-sided paired sign-flip'
        count = len(distribution)
    else:
        count = 10000
        distribution = (rng.choice([-1., 1.], (count, n))*delta).mean(axis=1)
        p = float((1+np.count_nonzero(np.abs(distribution)>=abs(delta.mean())-1e-10))/(count+1))
        method = 'Monte Carlo paired sign-flip with plus-one correction'
    sd = delta.std(ddof=1) if n>1 else 0
    return dict(n=n, improvement_pct=float(100*delta.mean()/b.mean()),
                difference_s=float(delta.mean()), ci_low=float(lo), ci_high=float(hi),
                paired_d=float(delta.mean()/sd) if sd>1e-12 else None,
                p_raw=p, permutation_count=count, test_method=method)


def summarize(raw):
    df = pd.DataFrame(raw)
    keys = ['scenario', 'seed', 'model', 'algorithm']
    if df.duplicated(keys).any():
        raise ValueError('Duplicate run keys')
    for _, group in df.groupby(['scenario', 'seed']):
        if group.world_hash.nunique()!=1:
            raise ValueError('Unpaired worlds')
    if not ((df.makespan<=df.horizon+1e-7).all() and
            (df.completed==(df.accepted==df.tasks)).all()):
        raise ValueError('Invalid completion/horizon accounting')
    summaries, comparisons = [], []
    rng = np.random.default_rng(73021)  # analysis-only randomness
    for (scenario, model), cell in df.groupby(['scenario', 'model'], sort=True):
        if cell.horizon.nunique()!=1:
            raise ValueError('Common truncation horizon required within cell')
        for algorithm, runs in cell.groupby('algorithm', sort=True):
            summaries.append(dict(scenario=scenario, model=model, algorithm=algorithm,
                n=len(runs), completion_rate=float(runs.completed.mean()),
                restricted_mean_s=float(runs.makespan.mean()),
                sd_s=float(runs.makespan.std(ddof=1)),
                duplicate_acceptances=float(runs.duplicate_acceptances.mean()),
                duplicate_compute=float(runs.duplicate_compute.mean()),
                duplicate_input_mb=float(runs.duplicate_input_mb.mean()),
                detector_triggers=float(runs.detector_triggers.mean()),
                requeues=float(runs.requeues.mean()), transferred_mb=float(runs.transferred_mb.mean()),
                prefetch_chunks=float(runs.prefetch_chunks.mean()),
                dynamic_prefetch_chunks=float(runs.dynamic_prefetch_chunks.mean()),
                compute_utilization=float(runs.compute_utilization.mean()),
                tail_idle_worker_seconds=(float(runs.tail_idle_worker_seconds.mean())
                    if runs.tail_idle_worker_seconds.notna().any() else None),
                tail_measured_runs=int(runs.tail_idle_worker_seconds.notna().sum()),
                wasted_compute_cost=float(runs.wasted_compute_cost.mean())))
        target = 'Proposed' if 'Proposed' in set(cell.algorithm) else 'P-full'
        candidate = cell[cell.algorithm==target].set_index('seed').sort_index()
        if candidate.empty:
            continue
        # Comparator family fixed before running; no data-selected strongest baseline.
        for comparator in sorted(set(cell.algorithm)-{target}):
            base = cell[cell.algorithm==comparator].set_index('seed').sort_index()
            if not candidate.index.equals(base.index):
                raise ValueError('Missing paired evaluation seeds')
            stats = paired_statistics(candidate.makespan.values, base.makespan.values, rng)
            complete = candidate.completed & base.completed
            sensitivity = paired_statistics(candidate.loc[complete, 'makespan'].values,
                                             base.loc[complete, 'makespan'].values, rng)
            comparisons.append(dict(scenario=scenario, model=model, candidate=target,
                comparator=comparator, **stats, completed_pairs_sensitivity=sensitivity))
    # One Holm family covering every P-full comparison in the pilot.
    adjusted = holm([row['p_raw'] for row in comparisons])
    for row, p in zip(comparisons, adjusted):
        row['p_holm_global'] = float(p)
        row['practical_win'] = bool(p<.05 and row['improvement_pct']>=1)
    return dict(summary=summaries, comparisons=comparisons,
                multiplicity_family='All candidate comparisons across all configured cells and models',
                bootstrap_resamples=5000, analysis_seed=73021)


def macro_values(analysis, raw):
    values = {'RunCount': str(len(raw)), 'SeedCount': str(len(set(r['seed'] for r in raw))),
              'CellCount': str(len(set(r['scenario'] for r in raw))),
              'ModelCount': str(len(set(r['model'] for r in raw))),
              'PolicyCount': str(len(set(r['algorithm'] for r in raw))),
              'FamilyCount': str(len(analysis['comparisons'])),
              'BootstrapCount': str(analysis['bootstrap_resamples'])}
    letters = lambda j: chr(65+j//26)+chr(65+j%26)
    for j, row in enumerate(analysis['summary']):
        tag = letters(j)
        for field, suffix, fmt in [('restricted_mean_s','Mean','.2f'), ('completion_rate','Completion','.3f'),
                                   ('duplicate_acceptances','Duplicates','.2f'),('detector_triggers','Triggers','.2f')]:
            values['S'+tag+suffix] = format(row[field], fmt)
    for j, row in enumerate(analysis['comparisons']):
        tag = letters(j)
        for field, suffix, fmt in [('improvement_pct','Percent','.2f'),('difference_s','Delta','.2f'),
                                 ('ci_low','Low','.2f'),('ci_high','High','.2f'),
                                 ('p_holm_global','P','.4f')]:
            values['C'+tag+suffix] = format(row[field], fmt)
    return values


def latex_macros(values):
    return ''.join('\\newcommand{\\'+key+'}{'+value+'}\n' for key, value in values.items())
