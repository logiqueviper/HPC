"""Paired relative Student inference and explicit equivalence margins.

The normal approximation concerns independent seed-level paired effects, not
individual tasks. Difference and TOST hypotheses share one Bonferroni family.
"""
import numpy as np
from scipy.stats import t
def paired_relative(candidate,baseline,claim_count,margin=1.):
 a=np.asarray(candidate,dtype=float);b=np.asarray(baseline,dtype=float)
 if a.shape!=b.shape or a.ndim!=1 or len(a)<2 or np.any(b<=0):raise ValueError('Positive paired baselines and at least two seeds required')
 d=100*(b-a)/b;n=len(d);mean=float(d.mean());se=float(d.std(ddof=1)/np.sqrt(n));family=2*claim_count
 if se<=1e-12:
  p=1. if abs(mean)<1e-12 else 0.;eq=0. if abs(mean)<margin else 1.;lo=hi=mean
 else:
  cutoff=t.ppf(1-.05/(2*family),n-1);lo=mean-cutoff*se;hi=mean+cutoff*se
  p=float(2*t.sf(abs(mean/se),n-1))
  eq=float(max(t.sf((mean+margin)/se,n-1),t.cdf((mean-margin)/se,n-1)))
 padj=min(1.,family*p);eadj=min(1.,family*eq)
 return dict(n=n,gain_pct=mean,mean_difference_s=float((b-a).mean()),standard_error_pct=se,simultaneous_ci_low=float(lo),simultaneous_ci_high=float(hi),p_raw=p,p_adjusted=padj,tost_p_raw=eq,tost_p_adjusted=eadj,equivalence_margin_pct=margin,equivalent=bool(eadj<.05),practical_win=bool(padj<.05 and mean>=margin),difference_significant=bool(padj<.05),exact_sample_identity=bool(np.array_equal(a,b)),family_hypotheses=family)
