"""HEFT's ranking/EFT core for independent tasks (zero DAG edges).

Topcuoglu, Hariri & Wu, IEEE TPDS 13(3), 2002,
doi:10.1109/71.993206. This is not a reproduction of a mobile framework.
Oracle nominal costs and initial CPU speeds favor this offline comparator.
The shared radio is subsequently simulated, not predicted by HEFT.
"""
import numpy as np
def independent_heft(costs, speeds):
    costs=np.asarray(costs,dtype=float);speeds=np.asarray(speeds,dtype=float)
    if costs.ndim!=1 or speeds.ndim!=1 or not len(speeds) or np.any(costs<=0) or np.any(speeds<=0):
        raise ValueError('Positive one-dimensional task costs and worker speeds required')
    ranks=costs*np.mean(1/speeds)
    order=sorted(range(len(costs)),key=lambda t:(-ranks[t],t))
    available=np.zeros(len(speeds));assignment={};finish={}
    for t in order:
        eft=available+costs[t]/speeds
        i=int(np.argmin(eft));assignment[t]=i;finish[t]=float(eft[i]);available[i]=eft[i]
    return assignment,order,finish
