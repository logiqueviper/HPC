"""Joint main/robustness family, including post-hoc link/prefetch interaction."""
import numpy as np
import pandas as pd
from .analysis import summarize, paired_statistics, holm


def interaction_contrast(base, link, prefetch, full):
    """Positive means the full time saving exceeds the sum of individual savings."""
    return np.asarray(link)+np.asarray(prefetch)-np.asarray(base)-np.asarray(full)


def joint_analysis(raw):
    result=summarize(raw)
    df=pd.DataFrame(raw)
    interactions=[]
    rng=np.random.default_rng(73022)
    policies=['Compute-shrink','Proposed-noPrefetch','Proposed-noLink','Proposed']
    for (scenario,model),cell in df.groupby(['scenario','model'],sort=True):
        if not set(policies)<=set(cell.algorithm):
            continue
        times=[cell[cell.algorithm==p].set_index('seed').sort_index().makespan for p in policies]
        if not all(times[0].index.equals(t.index) for t in times):
            raise ValueError('Unpaired interaction worlds')
        base,link,prefetch,full=[t.to_numpy() for t in times]
        stats=paired_statistics(base+full,link+prefetch,rng)
        stats['improvement_pct']=float(100*interaction_contrast(base,link,prefetch,full).mean()/base.mean())
        interactions.append(dict(scenario=scenario,model=model,label='post-hoc link × prefetch interaction',
                                 sign='positive: superadditive saving',**stats))
    claims=result['comparisons']+interactions
    adjusted=holm([r['p_raw'] for r in claims])
    for row,p in zip(claims,adjusted):
        row['p_holm_global']=float(p)
        if 'candidate' in row:
            row['practical_win']=bool(p<.05 and row['improvement_pct']>=1)
    result['interactions']=interactions
    result['family_count']=len(claims)
    result['multiplicity_family']='All candidate comparisons and link/prefetch interaction claims across every evaluation batch'
    return result
