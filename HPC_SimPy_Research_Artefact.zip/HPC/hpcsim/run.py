import argparse
import json
import hashlib
import importlib.metadata
import subprocess
import sys
import time
from pathlib import Path
import yaml
from .model import Scenario, generate_world, POLICIES, Simulation
from .analysis import summarize, macro_values, latex_macros


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', default='configs/exploratory.yaml')
    parser.add_argument('--output', default='results/pilot')
    args = parser.parse_args()
    # Every batch is gated. A failed gate aborts the run before results are made.
    subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', 'tests', '-v'], check=True)
    config_bytes = Path(args.config).read_bytes()
    config = yaml.safe_load(config_bytes)
    seeds = config.get('seeds') or list(range(config['seed_start'], config['seed_start']+config['seed_count']))
    if len(seeds)!=len(set(seeds)) or any(s in range(1000, 1020) for s in seeds):
        raise ValueError('Duplicate/calibration seeds cannot be used for evaluation')
    if any(s<2000 for s in seeds):
        raise ValueError('Reconstruction batches require fresh exploratory seeds >=2000')
    out = Path(args.output)
    if (out/'raw.json').exists():
        raise FileExistsError('Preserve prior results: choose another output directory')
    out.mkdir(parents=True, exist_ok=True)
    runs = []
    start = time.monotonic()
    for entry in config['scenarios']:
        scenario = Scenario(**entry)
        for seed in seeds:
            world = generate_world(scenario, seed)
            for model in config['models']:
                for name in config['algorithms']:
                    runs.append(Simulation(world, POLICIES[name], model).run())
            print(f'{scenario.name} seed {seed}: {len(runs)} runs; {time.monotonic()-start:.1f}s', flush=True)
    analysis = summarize(runs)
    (out/'raw.json').write_text(json.dumps(runs, indent=2, allow_nan=False)+'\n')
    (out/'analysis.json').write_text(json.dumps(analysis, indent=2, allow_nan=False)+'\n')
    (out/'numbers.tex').write_text(latex_macros(macro_values(analysis, runs)))
    (out/'config.yaml').write_bytes(config_bytes)
    files = list(Path('hpcsim').glob('*.py'))+list(Path('tests').glob('*.py'))
    metadata = dict(label='post-hoc / exploratory (v2); reconstructed artefact',
                    config_sha256=hashlib.sha256(config_bytes).hexdigest(),
                    source_sha256={str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files},
                    python=sys.version, versions={p: importlib.metadata.version(p) for p in
                    ['simpy','river','numpy','scipy','pandas','matplotlib','PyYAML']},
                    elapsed_seconds=time.monotonic()-start)
    (out/'provenance.json').write_text(json.dumps(metadata, indent=2)+'\n')
    import pandas as pd
    pd.DataFrame(runs).to_csv(out/'raw.csv', index=False)
    pd.DataFrame(analysis['summary']).to_csv(out/'summary.csv', index=False)
    pd.DataFrame([{k:v for k,v in r.items() if k!='completed_pairs_sensitivity'}
                  for r in analysis['comparisons']]).to_csv(out/'comparisons.csv', index=False)
    print(f'Saved {len(runs)} new exploratory runs to {out}')


if __name__=='__main__':
    main()
