# Archival deposit preparation

Publish the final HPC_SimPy_Research_Artefact.zip and the two accompanying PDFs
in an authenticated Zenodo deposit after confirming creators and a license.
Use the paper title: Dispatch Cost and Mechanism Activation in Wireless Chunk Scheduling.
Resource type: software/dataset with an accompanying simulation-methodology manuscript.
Description: SimPy implementation, independently tuned dispatch-cost comparisons,
22,400 paired evaluation records, 1,960 tuning records, 190 ns-3 stationary radio
trials, analysis, IEEEtran source, vector graphics, supplement and validation.
Related identifier: https://github.com/logiqueviper/HPC/tree/research-deliverables
Keywords: scheduling, wireless computing, SimPy, dispatch overhead, equivalence testing.

Creator names, affiliations, funding and license must be factual and approved
by the authors. No license is assumed for the authors' original materials.
Retain third-party notices. No deposit, reserved DOI or DOI publication has
been performed: this environment has no authenticated Zenodo access.
After the deposit is published, record the real DOI in the paper, regenerate
PDFs and the ZIP with a refreshed manifest, and update the deposit if necessary.
