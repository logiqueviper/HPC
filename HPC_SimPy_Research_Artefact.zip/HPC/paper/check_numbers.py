"""Check generated paper values against raw simulations; no original numbers claimed."""
import json
import re
import sys
from pathlib import Path
import numpy as np
import pandas as pd
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hpcsim.analysis import macro_values
from hpcsim.paper_analysis import joint_analysis

ROOT=Path(__file__).resolve().parent
raw=json.loads((ROOT/'raw-combined.json').read_text())
recomputed=joint_analysis(raw)
stored=json.loads((ROOT/'analysis.json').read_text())
assert stored==recomputed, 'Joint analysis is stale or hand-edited'
actual=dict(re.findall(r'\\newcommand\{\\([A-Za-z]+)\}\{([^}]+)\}',(ROOT/'numbers.tex').read_text()))
expected=macro_values(recomputed,raw)
expected['FamilyCount']=str(recomputed['family_count'])
for name,value in expected.items():
    assert actual.get(name)==value, f'Numeric macro mismatch: {name}'
df=pd.DataFrame(raw)
for j,row in enumerate(recomputed['comparisons']):
    tag=chr(65+j//26)+chr(65+j%26);prefix='C'+tag
    cell=df[(df.scenario==row['scenario'])&(df.model==row['model'])]
    a=cell[cell.algorithm==row['candidate']].set_index('seed').sort_index()
    b=cell[cell.algorithm==row['comparator']].set_index('seed').sort_index()
    mde=(1.95996398454+.84162123357)*(b.makespan-a.makespan).std(ddof=1)/np.sqrt(row['n'])
    extra={'D':'NA' if row['paired_d'] is None else f"{row['paired_d']:.3f}",
           'N':str(row['n']), 'RawP':f"{row['p_raw']:.5f}", 'Floor':str(row['permutation_count']),
           'CompleteN':str(row['completed_pairs_sensitivity']['n']), 'MDE':f'{mde:.2f}'}
    for suffix,value in extra.items():assert actual[prefix+suffix]==value, prefix+suffix
for j,row in enumerate(recomputed['summary']):
    tag=chr(65+j//26)+chr(65+j%26)
    for field,suffix in [('transferred_mb','Bytes'),('compute_utilization','Util'),('prefetch_chunks','Prefetch'),
                         ('wasted_compute_cost','Waste'),('tail_idle_worker_seconds','Tail'),('duplicate_compute','DupCompute')]:
        value='NA' if row[field] is None else f'{row[field]:.2f}'
        assert actual['S'+tag+suffix]==value
for file in ['interaction_table.tex','tuned_findings.tex','abstract_findings.tex','robustness_tables.tex','findings.tex','comparison_tables.tex','completion_table.tex','overhead_table.tex','inference_table.tex']:
    text=(ROOT/file).read_text()
    uses=re.findall(r'\\((?:S|C|Interaction)[A-Z]{2}[A-Za-z]+)', text)
    assert all(name in actual for name in uses), 'Undefined result macro in '+file
    # 95% is a methods label; no other numeric literal is permitted in result text/tables.
    text=text.replace('95\\%', '')
    text=re.sub(r'horizon\\_q[0-9]+\\_h[0-9]+', 'scenario', text)
    text=text.replace('combined\\_extended\\_h16000','scenario')
    assert not re.search(r'(?<![A-Za-z])\d+(?:\.\d+)?', text), 'Literal numeric result in '+file
# Protocol parameter macros are verified against actual saved batch settings.
import yaml
import unittest
from dataclasses import asdict
from hpcsim.model import Scenario, POLICIES, Policy
from dataclasses import replace
definitions=dict(POLICIES)
selection=json.loads((ROOT.parent/'results/calibration/selection.json').read_text())['selected']
definitions['Tuned-fixed']=replace(Policy(**selection['fixed']),name='Tuned-fixed')
definitions['Tuned-weighted']=replace(Policy(**selection['weighted']),name='Tuned-weighted')
assert actual['SelectedFixedSize']==str(selection['fixed']['fixed'])
assert actual['SelectedWeightedShare']==format(selection['weighted']['sigma'],'.3g')
settings=[]
for batch in ['core','sensitivity']:
    cfg=yaml.safe_load((ROOT.parent/'results'/batch/'config.yaml').read_text())
    settings.extend(asdict(Scenario(**entry)) for entry in cfg['scenarios'])
settings.extend(json.loads((ROOT.parent/'results/calibration/config.json').read_text()))
for setting in settings[-4:]:setting['name']='tuned_'+setting['name']
settings.extend(json.loads((ROOT.parent/'results/horizon/config.json').read_text()))
from dataclasses import asdict
from hpcsim.model import Scenario
extension=asdict(Scenario(**next(e for e in __import__('yaml').safe_load((ROOT.parent/'results/core/config.yaml').read_text())['scenarios'] if e['name']=='combined')))
extension.update(name='combined_extended_h16000',horizon=16000)
settings.append(extension)
settings.extend(json.loads((ROOT.parent/'results/ns3_sensitivity/config.json').read_text()))
for j,setting in enumerate(settings):
    tag=chr(65+j//26)+chr(65+j%26)
    for field,suffix in [('tasks','Tasks'),('workers','Workers'),('horizon','Horizon'),('heterogeneity','H'),('cost_cv','CV'),('rho','Rho'),('dynamic_fraction','Dynamic'),('weak_fraction','Weak'),('extra_rtt_ms','RTT')]:
        assert actual['Param'+tag+suffix]==format(setting[field],'.3g')
for j,name in enumerate(sorted(set(r['algorithm'] for r in raw))):
    tag=chr(65+j//26)+chr(65+j%26)
    assert actual['Policy'+tag+'Share']==format(definitions[name].sigma,'.3g')
    assert actual['Policy'+tag+'Cutoff']==format(definitions[name].prefetch_cutoff,'.3g')
assert actual['ValidationCount']==str(unittest.defaultTestLoader.discover(str(ROOT.parent/'tests')).countTestCases())
for j,row in enumerate(recomputed['interactions']):
    tag=chr(65+j//26)+chr(65+j%26)
    for field,suffix,fmt in [('difference_s','Delta','.2f'),('ci_low','Low','.2f'),('ci_high','High','.2f'),('p_holm_global','P','.4f')]:
        assert actual['Interaction'+tag+suffix]==format(row[field],fmt)
    assert actual['Interaction'+tag+'D']==('NA' if row['paired_d'] is None else f"{row['paired_d']:.3f}")
for _,group in df.groupby(['scenario','seed']):assert group.world_hash.nunique()==1
proposed=df[df.algorithm=='Proposed']
assert (proposed.dynamic_prefetch_chunks==0).all()
assert (proposed.max_prefetch_completion<.75).all()
assert (proposed.duplicate_acceptances==0).all()
print(f'PASS: {len(raw)} evaluation runs, {len(recomputed["comparisons"])} paired comparisons, {len(recomputed["interactions"])} interactions; generated macros agree')
