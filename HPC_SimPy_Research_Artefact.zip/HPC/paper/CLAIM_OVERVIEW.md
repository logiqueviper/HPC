# Claim provenance overview

Every quantitative candidate comparison and link/prefetch interaction has a generated macro prefix and an analysis-array location in CLAIM_SOURCES.json. Figures are generated from paper/raw-combined.json; all result tables and abstract figures use numbers.tex. check_numbers.py recomputes the joint analysis and verifies all generated numerical fields.

- Baseline-selection claims: results/calibration/selection.json and raw.json. The selection uses calibration seeds only; evaluation.json contains the untouched evaluation family.
- Common seeded worlds and deterministic policies: hpcsim/model.py, world fingerprints in every raw row, V01/V02/V10/V11, and paper/repeatability.json.
- Stationary-only prefetch: V22/V23, model Policy/dispatch, dynamic_prefetch_chunks and max_prefetch_completion in raw results. The 75% cutoff is a design parameter, not a demonstrated optimum.
- Recovery safety: V16–V18 and results/recovery_examples.json. This is a constructed end-to-end simulator case, not measured device safety.
- Censoring/horizon claims: accepted/tasks/completed fields and per-run horizon; results/horizon/raw.json and V25. Finite recovery with an extended horizon is not evidence about the unavailable original simulator.
- Positive improvement convention: hpcsim/analysis.py and sign tests in tests/test_analysis.py.
- Interaction interpretation: hpcsim/paper_analysis.py and tests/test_interactions.py. Only the link/prefetch factorial is evaluated; no five-way complementarity claim is made.
- Contention/model claims: model channel_rates and V06–V08. Allocation is per positive-rate transfer; throughput knots and the overhead rule are assumptions, not measured or externally calibrated facts.
- Unverified references/template access: evidence/references.json. A proxy 403 is evidence of denied requests, not verification of a citation.
- Absence of physical validation, public archive and submission: REMAINING_WORK.md. No hardware results, DOI, author consent or journal acceptance are represented as existing.
