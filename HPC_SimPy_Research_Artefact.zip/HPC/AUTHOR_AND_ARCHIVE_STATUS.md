# Author declarations and archival status

The current manuscript uses the author name/affiliation supplied in the research
materials. Its short biography contains only the stated research topics;
degrees, positions, awards and other credentials have not been invented.

Final author spelling/list, corresponding email, biography approval, actual
funding, conflicts, contribution roles and archival license require author
confirmation. A question requesting these facts remains pending.
No "no funding" or "no conflict" statement has been inferred from silence.

The artifact is downloadable from GitHub. GitHub is not a DOI-bearing archive.
No Zenodo credential or connector is available to this environment. No Zenodo
deposit, reserved DOI, published DOI or journal submission is claimed.
Once an authenticated deposit is available, use the final ZIP, retain all
third-party license notices, select the actual author-approved license,
publish the deposit, and replace the manuscript's data-availability URL with
the real DOI. Do not copy a placeholder DOI into the manuscript.

Direct publisher/DBLP requests for USENIX and recent IEEE/MDPI references are
blocked with proxy 403. Publisher-deposited Crossref records are retained for
the DOI-bearing references. The current manuscript omits the unconfirmed
2025/2026 entries. LATE and Dolly cite established original conference papers;
direct publisher verification remains explicitly incomplete in the audit.
