# Publication revision status

This remains a new exploratory reconstruction, not the missing original study.
The earlier original-reviewer response cannot establish a revision of that
unrecovered implementation. No paper has been submitted.

## Completed revision evidence

- Independent ns-3 3.44 C++ Wi-Fi diagnostic: 120 retained packet-level runs,
  training versus holdout RNG runs, goodput and unloaded-echo error reporting.
  AP data-frame RSSI filtering and fractional-millisecond RTT are used in the
  final results/ns3 dataset. Intermediate diagnostics are not publication data.
- 320 fresh stationary SimPy runs using the ns-3 training goodput and echo
  curves within their calibrated support. These are fluid-model sensitivity
  experiments, not end-to-end scheduling inside ns-3 or physical measurements.
- HEFT's independent-task ranking/EFT core: 100 stationary-world comparator
  runs, hand-calculated scheduling test, and explicit oracle-speed advantage.
  Radio execution is an adaptation; this does not reproduce a mobile framework.
- 400 matched-world combined-cell runs at a longer horizon, keeping original
  physical trace prefixes and every original seed. Prefixes explicitly verified
  for all 50 seeds. Remaining censoring is disclosed.
- All new scheduler comparisons join the expanded global Holm family. Separate
  diagnostic analyses retained in results/* are superseded for paper claims by
  paper/analysis.json. Comparisons are exploratory, not preregistered.
- Eleven references have Crossref-verified metadata, retained with audit JSON.
  This is metadata verification, not a completed full-text novelty review.
- Standard IEEEtran journal source, IEEE bibliography style and two-column PDF.
  Template mirrors, commits and hashes are documented. IEEE's author-center
  web page remains blocked; specific journal instructions need confirmation.
- Negative prefetch/cutoff results are retained and the abstract leads with
  tuned-baseline and calibrated-mapping comparisons, not the heavily censored
  nominated compute-only contrast.

## Revised scientific finding

In the ns-3-derived stationary mixed-link sensitivity, the tuned fixed-size
comparison fails the practical threshold and RSSI/RTT ablations tie. This weakens
the scheduler-superiority claim. The revised abstract and discussion expose this
result; external validation and a substantive novelty argument remain necessary.

## Still required before a credible submission

1. A measured testbed/trace or end-to-end packet-level scheduler evaluation with
   realistic mobility, transport, queueing, interference and control overhead.
   The ns-3 diagnostic uses stationary co-located downlink receivers without
   fading; small fitted errors cannot be generalized to physical networks.
2. A faithful close wireless/mobile framework baseline and full-text novelty
   assessment. HEFT addresses a published CPU-scheduling core, not this gap.
3. Evidence-driven mechanism selection. A fixed 75% cutoff and stationary-only
   restriction must not be advertised as proven superior; some ablations tie.
4. Confirm all authors, affiliations, corresponding email, funding, conflicts,
   contributions and consent. The current identity comes from the synopsis.
5. Choose a specific IEEE journal and check its current author instructions,
   page limits and declarations. IEEEtran formatting alone is not compliance.
6. Author-approved software/data license and archival deposition. GitHub ZIP
   delivery is available; no Zenodo DOI exists. Do not invent a DOI or author
   declarations. No Zenodo account/authorization is available in this workspace.

See validation/README.md for a minimum measured-trace/testbed protocol.
